Store source and translated key/value tables here.
