from __future__ import annotations
import os, sys, tempfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from fm2010_settings_tool import FMTool
import fm2010_release6_tools as r6

def walk(w):
    for c in w.winfo_children():
        yield c
        yield from walk(c)

def find_button(root,label):
    for w in walk(root):
        if isinstance(w,ttk.Button) and w.cget('text')==label:return w
    raise AssertionError(f'button not found: {label}')

def run():
    with tempfile.TemporaryDirectory() as td:
        os.environ['LOCALAPPDATA']=td
        game=Path(td)/'game';game.mkdir()
        (game/'fm.exe').write_bytes(b'MZ'+b'\0'*100)
        (game/'config.ini').write_text('[fm]\nlanguage=english\n',encoding='utf-8')
        ed=game/'data'/'editor data';ed.mkdir(parents=True)
        (ed/'config.xml').write_text('<record/>',encoding='utf-8')
        app=FMTool();app.install_dir=game;app.game_exe=game/'fm.exe'
        message_errors=[]
        r6.messagebox.showinfo=lambda *a,**k:None
        r6.messagebox.showwarning=lambda *a,**k:None
        r6.messagebox.showerror=lambda *a,**k:message_errors.append(str(a))
        app.open_global_workbench();app.update()
        tops=[w for w in app.winfo_children() if isinstance(w,tk.Toplevel)]
        assert tops,'global workbench failed to open'
        hub=tops[-1]
        nbs=[w for w in walk(hub) if isinstance(w,ttk.Notebook)]
        assert nbs and len(nbs[0].tabs())==7
        nb=nbs[0]; names=[nb.tab(t,'text') for t in nb.tabs()]
        assert 'GitHub / Git' in names and 'Справочник файлов' in names
        find_button(hub,'Сканировать все файлы').invoke();app.update()
        trees=[w for w in walk(hub) if isinstance(w,ttk.Treeview) and tuple(w['columns'])==('path','ext','role','signature','size','risk')]
        assert trees and any('config.xml' in str(trees[0].item(i,'values')) for i in trees[0].get_children())
        find_button(hub,'Проверить совместимость').invoke();app.update()
        textwidgets=[w for w in walk(hub) if isinstance(w,tk.Text)]
        assert any('fm.exe: OK' in w.get('1.0','end') for w in textwidgets)
        # Create a clean local Git workspace and use the generated ignore file.
        repo=Path(td)/'my_mod';repo.mkdir()
        entries=[w for w in walk(hub) if isinstance(w,ttk.Entry)]
        assert entries
        var=entries[0].cget('textvariable');hub.setvar(var,str(repo))
        find_button(hub,'Создать .gitignore').invoke();app.update()
        assert (repo/'.gitignore').is_file() and '*.exe' in (repo/'.gitignore').read_text(encoding='utf-8')
        # Verify the workspace selector is separate from the game installation.
        assert repo != game
        # The file encyclopedia can scan the separate Documents/user-data folder.
        user_data=Path(td)/'Documents'/'Sports Interactive'/'Football Manager 2010'/'editor data'
        user_data.mkdir(parents=True)
        (user_data/'custom_leagues.dbc').write_bytes(b'fake-dbc')
        catalog_entries=[w for w in walk(hub) if isinstance(w,ttk.Entry)]
        catalog_var=catalog_entries[1].cget('textvariable');hub.setvar(catalog_var,str(user_data))
        find_button(hub,'Сканировать все файлы').invoke();app.update()
        assert any('custom_leagues.dbc' in str(trees[0].item(i,'values')) for i in trees[0].get_children())
        # Creating a Git repository inside the actual game directory is blocked.
        repo_var=entries[0].cget('textvariable');hub.setvar(repo_var,str(game))
        find_button(hub,'Создать локальный репозиторий').invoke();app.update()
        assert not (game/'.git').exists()
        assert any('Не создавай Git-репозиторий внутри установленной игры' in x for x in message_errors)
        find_button(hub,'Создать .gitignore').invoke();app.update()
        assert not (game/'.gitignore').exists()
        # A pre-existing .git directory must not bypass the remote-repository guard.
        (game/'.git').mkdir(exist_ok=True)
        hub.setvar(repo_var,str(game))
        find_button(hub,'Создать PRIVATE repo').invoke();app.update()
        assert any('Нельзя создавать GitHub-репозиторий из папки игры' in x for x in message_errors)
        app.destroy()
    print('GLOBAL GUI: all 7 tabs open, install/user-data catalog and pre-flight report PASS')
    print('GITHUB WORKSPACE: isolated repo path, .gitignore and game-folder Git block PASS')

if __name__=='__main__':run()
