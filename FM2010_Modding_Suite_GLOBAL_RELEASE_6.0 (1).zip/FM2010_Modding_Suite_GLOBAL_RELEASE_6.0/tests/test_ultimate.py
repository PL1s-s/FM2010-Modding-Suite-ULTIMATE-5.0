from __future__ import annotations
import json, os, sqlite3, sys, tempfile, zipfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from fm2010_settings_tool import FMTool
import fm2010_advanced_tools as adv

def walk(w):
    for c in w.winfo_children():
        yield c
        yield from walk(c)

def button(parent, label):
    for w in walk(parent):
        if isinstance(w, ttk.Button) and w.cget('text') == label: return w
    raise AssertionError(f'button not found: {label}')

def set_entry(parent, index, value):
    entries = [w for w in walk(parent) if isinstance(w, ttk.Entry)]
    var = entries[index].cget('textvariable')
    parent.setvar(var, value)

def run():
    with tempfile.TemporaryDirectory() as td:
        os.environ['LOCALAPPDATA'] = td
        game = Path(td) / 'game'; game.mkdir()
        (game/'fm.exe').write_bytes(b'MZ' + b'\0'*128)
        (game/'config.ini').write_text('[game]\nmode=original\n', encoding='utf-8')
        app = FMTool(); app.install_dir = game; app.game_exe = game/'fm.exe'
        adv.messagebox.showinfo = lambda *a, **k: None
        adv.messagebox.showwarning = lambda *a, **k: None
        adv.messagebox.showerror = lambda *a, **k: (_ for _ in ()).throw(AssertionError(str(a)))
        adv.messagebox.askyesno = lambda *a, **k: True
        app.open_advanced_workbench(); app.update()
        tops = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
        assert tops, 'advanced window did not open'
        hub = tops[-1]
        nbs = [w for w in walk(hub) if isinstance(w, ttk.Notebook)]
        assert nbs and len(nbs[0].tabs()) == 12
        nb = nbs[0]
        names = [nb.tab(t, 'text') for t in nb.tabs()]
        required = ['Инспектор', 'Патчи и откат', 'Органайзер', 'Сохранения', 'CSV / TSV', 'Diff Lab', 'Сканер ссылок', 'Карантин', 'SQLite', 'Каталог строк', 'SHA-256']
        for x in required: assert x in names, x
        # Quick analysis and inspector.
        button(hub, 'Быстрый анализ установки').invoke(); app.update()
        nb.select(names.index('Инспектор')); button(hub, 'Сканировать').invoke(); app.update()
        assert any('config.ini' in str(w.item(i, 'values')) for w in walk(hub) if isinstance(w, ttk.Treeview) for i in w.get_children())
        # Patch pack -> install -> rollback transaction.
        stage = game/'mod_staging'; stage.mkdir(); (stage/'config.ini').write_text('[game]\nmode=patched\n', encoding='utf-8')
        patch_zip = Path(td)/'patch.zip'
        orig_save = adv.filedialog.asksaveasfilename; orig_open = adv.filedialog.askopenfilename
        adv.filedialog.asksaveasfilename = lambda *a, **k: str(patch_zip)
        nb.select(names.index('Патчи и откат')); button(hub, 'Собрать ZIP-патч').invoke(); app.update()
        assert patch_zip.is_file()
        adv.filedialog.askopenfilename = lambda *a, **k: str(patch_zip)
        button(hub, 'Установить патч').invoke(); app.update()
        assert 'patched' in (game/'config.ini').read_text(encoding='utf-8')
        op_dir = Path(td)/'FM2010SettingsTool'/'patch_operations'
        manifests = list(op_dir.glob('patch_*.json')); assert manifests
        adv.filedialog.askopenfilename = lambda *a, **k: str(manifests[-1])
        button(hub, 'Откат по журналу…').invoke(); app.update()
        assert 'original' in (game/'config.ini').read_text(encoding='utf-8')
        # CSV load, clean export.
        tab = nb.nametowidget(nb.tabs()[names.index('CSV / TSV')])
        csvin = game/'table.csv'; csvin.write_text('id;name\n1; A \n1; A \n2;B\n', encoding='utf-8')
        set_entry(tab, 0, str(csvin))
        button(hub, 'Загрузить / обновить').invoke(); app.update()
        csvout = Path(td)/'clean.csv'; adv.filedialog.asksaveasfilename = lambda *a, **k: str(csvout)
        button(hub, 'Удалить дубли').invoke(); app.update()
        assert csvout.is_file() and len(csvout.read_text(encoding='utf-8-sig').splitlines()) == 3
        # SQLite readonly browser.
        db = game/'probe.db'
        with sqlite3.connect(db) as con: con.execute('CREATE TABLE demo (id INTEGER, name TEXT)'); con.execute("INSERT INTO demo VALUES (1,'Alpha')")
        sqltab = nb.nametowidget(nb.tabs()[names.index('SQLite')]); set_entry(sqltab, 0, str(db))
        button(hub, 'Открыть только для чтения').invoke(); app.update()
        assert any(isinstance(w, tk.Listbox) and w.size() == 1 for w in walk(hub))
        # Quarantine candidate and restore.
        old = game/'unused.tmp'; old.write_text('temp', encoding='utf-8')
        nb.select(names.index('Карантин')); button(hub, 'Найти кандидатов').invoke(); app.update()
        qtrees = [w for w in walk(hub) if isinstance(w, ttk.Treeview) and 'reason' in w['columns']]
        assert qtrees and qtrees[-1].get_children()
        tree = qtrees[-1]; tree.selection_set(tree.get_children()[0])
        button(hub, 'В карантин выбранное').invoke(); app.update()
        assert not old.exists()
        manifests = list((Path(td)/'FM2010SettingsTool'/'ultimate_quarantine').rglob('quarantine_manifest.json')); assert manifests
        adv.filedialog.askopenfilename = lambda *a, **k: str(manifests[-1])
        button(hub, 'Восстановить по манифесту…').invoke(); app.update()
        assert old.is_file()
        # Copy-only asset organizer keeps original game files intact and skips executables.
        (game/'graphics').mkdir(exist_ok=True)
        (game/'graphics'/'crest.png').write_bytes(b'\x89PNG\r\n\x1a\n' + (13).to_bytes(4,'big') + b'IHDR' + (120).to_bytes(4,'big') + (80).to_bytes(4,'big'))
        asset_out = Path(td)/'asset_export'
        orgtab = nb.nametowidget(nb.tabs()[names.index('Органайзер')])
        set_entry(orgtab, 0, str(game)); set_entry(orgtab, 1, str(asset_out))
        button(hub, 'Скопировать и рассортировать').invoke(); app.update()
        assert (asset_out/'Images'/'crest.png').is_file()
        assert not (asset_out/'Other'/'fm.exe').exists() and (game/'fm.exe').is_file()
        # Save backup and restore roundtrip.
        save_dir = Path(td)/'saves'; save_dir.mkdir(); (save_dir/'season.fm').write_bytes(b'savegame test')
        savtab = nb.nametowidget(nb.tabs()[names.index('Сохранения')]); set_entry(savtab, 0, str(save_dir))
        button(savtab, 'Сканировать').invoke(); app.update()
        backup_out = Path(td)/'save_backups'; backup_out.mkdir()
        adv.filedialog.askdirectory = lambda *a, **k: str(backup_out)
        button(hub, 'Создать ZIP backup выбранных / всех').invoke(); app.update()
        save_archives = list(backup_out.glob('FM2010_saves_*.zip')); assert save_archives
        restore_dir = Path(td)/'restored_saves'; restore_dir.mkdir()
        adv.filedialog.askopenfilename = lambda *a, **k: str(save_archives[-1])
        adv.filedialog.askdirectory = lambda *a, **k: str(restore_dir)
        button(hub, 'Восстановить из ZIP…').invoke(); app.update()
        assert (restore_dir/'season.fm').read_bytes() == b'savegame test'
        # String catalog and checksum manifest flows.
        nb.select(names.index('Каталог строк')); button(hub, 'Собрать каталог').invoke(); app.update()
        assert any(isinstance(w, ttk.Treeview) and w.get_children() for w in walk(hub))
        manifest_out = Path(td)/'game_manifest.json'
        adv.filedialog.asksaveasfilename = lambda *a, **k: str(manifest_out)
        nb.select(names.index('SHA-256')); button(hub, 'Создать манифест…').invoke(); app.update()
        assert manifest_out.is_file() and json.loads(manifest_out.read_text(encoding='utf-8'))['files']
        # Traversal paths are rejected before extraction.
        for bad in ('../outside.txt', '/absolute.txt', r'C:\outside.txt', r'..\escape.txt'):
            try: adv._safe_member(game, bad)
            except ValueError: pass
            else: raise AssertionError(f'unsafe ZIP member accepted: {bad}')
        adv.filedialog.asksaveasfilename = orig_save; adv.filedialog.askopenfilename = orig_open
        app.destroy()
    print('ULTIMATE 5.0 GUI + patch install/rollback + CSV cleanup + SQLite readonly + quarantine + asset organizer + save backup/restore + string/hash catalog + ZIP path safety PASS')

if __name__ == '__main__': run()
