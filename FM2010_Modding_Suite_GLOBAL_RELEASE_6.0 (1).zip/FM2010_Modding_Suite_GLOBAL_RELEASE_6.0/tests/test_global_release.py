from __future__ import annotations
import os, sys, tempfile, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import fm2010_release6_tools as r6

class FileEncyclopediaTests(unittest.TestCase):
    def test_fm2010_dbc_guidance(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); p=root/'editor data'/'league_changes.dbc'; p.parent.mkdir(); p.write_bytes(b'not real dbc data')
            info=r6.explain_game_file(p, root)
            self.assertIn('Data Editor', info['edit'])
            self.assertIn('сжатом формате DBC', info['purpose'])
            self.assertIn('editor data', info['folder_context'])

    def test_editor_config_is_protected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); p=root/'editor data'/'config.xml'; p.parent.mkdir(); p.write_text('<record/>')
            info=r6.explain_game_file(p, root)
            self.assertIn('Не заменяй', info['edit'])
            self.assertEqual(info['risk'], 'Высокий')

    def test_lnc_is_text_instruction(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); p=root/'data'/'db'/'1000'/'lnc'/'all'/'fake.lnc'; p.parent.mkdir(parents=True); p.write_text('')
            info=r6.explain_game_file(p, root)
            self.assertIn('LNC', info['type'])
            self.assertIn('синтаксис', info['edit'])
            self.assertIn('Каталог текстовых инструкций', info['folder_context'])

    def test_unknown_format_is_honest(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); p=root/'mystery.zzz'; p.write_bytes(b'\0\1\2')
            info=r6.explain_game_file(p, root)
            self.assertIn('неизвестно', info['purpose'])
            self.assertIn('эвристическое', info['confidence'])

    def test_db_extension_needs_sqlite_signature(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); text_db=root/'not_sqlite.db'; text_db.write_text('plain text')
            info=r6.explain_game_file(text_db, root)
            self.assertNotEqual(info['type'], 'База SQLite')
            self.assertNotEqual(info['signature'], 'SQLite')
            real_db=root/'sample.db'; real_db.write_bytes(b'SQLite format 3\x00' + b'\0' * 32)
            info=r6.explain_game_file(real_db, root)
            self.assertEqual(info['type'], 'База SQLite')
            self.assertEqual(info['signature'], 'SQLite')


    def test_local_git_push_pull_roundtrip(self):
        if not r6._git_exe():
            self.skipTest('Git not installed in test environment')
        with tempfile.TemporaryDirectory() as td:
            base=Path(td); repo=base/'repo'; remote=base/'remote.git'; clone=base/'clone'
            repo.mkdir()
            code,out=r6._run_git(['init','-b','main'],repo); self.assertEqual(code,0,out)
            for key,value in [('user.name','FM Test'),('user.email','fm-test@example.invalid')]:
                code,out=r6._run_git(['config',key,value],repo); self.assertEqual(code,0,out)
            (repo/'notes.txt').write_text('first\n',encoding='utf-8')
            for args in (['add','-A'],['commit','-m','initial']):
                code,out=r6._run_git(args,repo); self.assertEqual(code,0,out)
            remote.mkdir()
            code,out=r6._run_git(['init','--bare','-b','main'],remote); self.assertEqual(code,0,out)
            code,out=r6._run_git(['remote','add','origin',str(remote)],repo); self.assertEqual(code,0,out)
            code,out=r6._run_git(['push','-u','origin','HEAD'],repo); self.assertEqual(code,0,out)
            code,out=r6._run_git(['clone',str(remote),str(clone)],base); self.assertEqual(code,0,out)
            for key,value in [('user.name','FM Test'),('user.email','fm-test@example.invalid')]:
                code,out=r6._run_git(['config',key,value],clone); self.assertEqual(code,0,out)
            with (clone/'notes.txt').open('a',encoding='utf-8') as f:f.write('second\n')
            for args in (['add','-A'],['commit','-m','second'],['push']):
                code,out=r6._run_git(args,clone); self.assertEqual(code,0,out)
            code,out=r6._run_git(['pull','--ff-only'],repo); self.assertEqual(code,0,out)
            self.assertIn('second',(repo/'notes.txt').read_text(encoding='utf-8'))

    def test_run_git_never_requires_shell(self):
        if not r6._git_exe():
            self.skipTest('Git not installed in test environment')
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            code,out=r6._run_git(['init','-b','main'],root)
            self.assertEqual(code,0,out)
            self.assertTrue((root/'.git').is_dir())

if __name__=='__main__': unittest.main()
