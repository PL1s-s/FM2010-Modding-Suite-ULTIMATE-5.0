# -*- coding: utf-8 -*-
"""FM2010 Modding Suite 6.0 — GitHub, file encyclopedia and release tools.

Git commands are executed as argument arrays (never through a shell). Tokens are
not requested or stored by this application; GitHub CLI manages authentication.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
import webbrowser
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

VERSION_6 = "6.0 GLOBAL RELEASE"
MAX_CATALOG_FILES = 120_000
MAX_HASH_BYTES = 128 * 1024 * 1024

# The guide uses extension + folder context. It deliberately labels uncertain
# formats as heuristic rather than pretending to know proprietary structures.
FILE_KNOWLEDGE: dict[str, dict[str, str]] = {
    ".exe": {"type": "Исполняемый файл", "purpose": "Запускаемая программа или инструмент игры.", "edit": "Не редактируй как текст и не меняй байты наугад. Для исправлений используй проверенный патч совместимой версии; перед заменой сохрани оригинал.", "tool": "Резервная копия / проверенный установщик", "risk": "Очень высокий"},
    ".dll": {"type": "Библиотека", "purpose": "Код, который загружается игрой или вспомогательной программой.", "edit": "Не открывай для обычного редактирования. Замена допустима только из доверенного патча той же версии.", "tool": "Backup / проверенный патч", "risk": "Очень высокий"},
    ".dat": {"type": "Данные / проприетарный формат", "purpose": "Может содержать игровые данные или упакованную структуру; назначение определяется по расположению и версии.", "edit": "Не меняй вручную в HEX без спецификации. Используй совместимый редактор игры, если формат им поддерживается.", "tool": "Специализированный редактор / HEX только для экспертов", "risk": "Очень высокий"},
    ".dbc": {"type": "Сжатые editor data FM", "purpose": "В FM2010 после обновления 10.2 редактор мог сохранять файлы изменений базы в сжатом формате DBC.", "edit": "Редактируй через Football Manager 2010 Data Editor: загрузи базу и изменения, внеси правки и сохрани новый файл. Не пытайся править байты как обычный текст.", "tool": "FM2010 Data Editor", "risk": "Высокий"},
    ".xml": {"type": "XML / структурированные данные", "purpose": "Текстовая структура: конфигурация, описание ресурсов или данные редактора.", "edit": "Открой в XML-редакторе, сохрани исходную кодировку и структуру, проверь корректность XML. Файлы Editor Data лучше создавать штатным редактором.", "tool": "FM2010 Data Editor / XML-редактор", "risk": "Средний–высокий"},
    ".lnc": {"type": "LNC — текстовые команды FM", "purpose": "В играх Football Manager LNC-файлы используются для отдельных изменений имён и других записей базы.", "edit": "Редактируй как текст, сохраняя кавычки, идентификаторы и синтаксис команд. Проверь папку версии базы и сделай backup; не вставляй неизвестные команды.", "tool": "Текстовый редактор", "risk": "Средний"},
    ".fmf": {"type": "Контейнер ресурсов FM", "purpose": "Похоже на собственный контейнер Football Manager; внутреннее устройство зависит от поколения игры и типа ресурса.", "edit": "Не распаковывай обычным ZIP-инструментом, если формат не распознан. Проверь совместимость с FM2010 и используй инструмент, который явно поддерживает этот контейнер.", "tool": "Совместимый FM-инструмент / резервная копия", "risk": "Высокий"},
    ".ini": {"type": "Конфигурация INI", "purpose": "Текстовые параметры программы или пользовательские настройки.", "edit": "Меняй только понятные ключи в существующих секциях. Не дублируй ключи; сравни до/после и перезапусти игру для проверки.", "tool": "Встроенный текстовый редактор", "risk": "Низкий–средний"},
    ".cfg": {"type": "Конфигурация CFG", "purpose": "Настройки или параметры компонента; точный формат зависит от файла.", "edit": "Сначала изучи соседние строки и комментарии. Меняй только известные параметры и сохраняй резервную копию.", "tool": "Текстовый редактор", "risk": "Средний"},
    ".txt": {"type": "Текстовый документ", "purpose": "Инструкция, список, журнал или пользовательские данные.", "edit": "Можно редактировать текстовым редактором. Уточни требуемую кодировку и формат строк.", "tool": "Текстовый редактор", "risk": "Низкий"},
    ".log": {"type": "Журнал событий", "purpose": "Диагностические сообщения программы или игры.", "edit": "Обычно только читают; редактирование не исправляет причину ошибки. Используй поиск по ERROR/WARNING и сохраняй оригинал.", "tool": "Просмотрщик журнала", "risk": "Низкий"},
    ".csv": {"type": "Таблица CSV", "purpose": "Строки и столбцы, часто экспорт/справочник/табличные данные.", "edit": "Проверь разделитель, заголовки, кодировку и кавычки. Сохраняй в новый файл, если игра ожидает строго заданную структуру.", "tool": "Табличная лаборатория / Excel / LibreOffice", "risk": "Средний"},
    ".tsv": {"type": "Таблица TSV", "purpose": "Табличные данные с разделителем Tab.", "edit": "Не заменяй табуляцию пробелами; проверь количество колонок в каждой строке.", "tool": "Табличная лаборатория", "risk": "Средний"},
    ".json": {"type": "JSON", "purpose": "Структурированные настройки или метаданные.", "edit": "Используй форматирование с проверкой JSON; сохраняй типы значений, запятые и имена ключей.", "tool": "JSON-редактор", "risk": "Средний"},
    ".png": {"type": "Изображение PNG", "purpose": "Графика: эмблемы, портреты, элементы интерфейса и другие изображения.", "edit": "Изменяй изображение в графическом редакторе. Сохраняй прозрачность, нужный размер и имя; проверь XML/конфиг, который на него ссылается.", "tool": "Графический редактор + config.xml", "risk": "Низкий–средний"},
    ".jpg": {"type": "Изображение JPEG", "purpose": "Фотография или графический ресурс без альфа-прозрачности.", "edit": "Сохраняй совместимые размеры и качество; если игра ожидает PNG или alpha, JPEG может не подойти.", "tool": "Графический редактор", "risk": "Низкий–средний"},
    ".bmp": {"type": "Изображение BMP", "purpose": "Растровый графический ресурс.", "edit": "Проверь глубину цвета и размеры. При замене сверяй, что оригинал действительно BMP, а не просто имеет такое расширение.", "tool": "Графический редактор", "risk": "Низкий–средний"},
    ".gif": {"type": "Изображение GIF", "purpose": "Иллюстрация или простая анимация.", "edit": "Сохраняй палитру, число кадров и прозрачность; поддержка анимации игрой может отличаться.", "tool": "Графический редактор", "risk": "Низкий–средний"},
    ".webp": {"type": "Изображение WebP", "purpose": "Современный формат растровой графики; поддержка старым движком FM2010 не гарантируется.", "edit": "Не используй как замену без проверки поддержки. При необходимости конвертируй в формат оригинала и проверь в игре.", "tool": "Графический редактор / конвертер", "risk": "Средний"},
    ".ico": {"type": "Иконка Windows", "purpose": "Значок программы или элемента интерфейса.", "edit": "Меняй только если ресурс действительно используется; сохрани размеры и набор разрешений.", "tool": "Редактор ICO", "risk": "Средний"},
    ".jpeg": {"type": "Изображение JPEG", "purpose": "Фотография или графический ресурс без альфа-прозрачности.", "edit": "Сохраняй совместимые размеры и качество; не меняй расширение без конвертации формата.", "tool": "Графический редактор", "risk": "Низкий–средний"},
    ".dds": {"type": "Текстура DDS", "purpose": "Текстура сжатого графического формата.", "edit": "Используй редактор с поддержкой DDS и точного типа сжатия. Простое переименование файла не конвертирует текстуру.", "tool": "Редактор текстур DDS", "risk": "Средний"},
    ".tga": {"type": "Изображение TGA", "purpose": "Растровая графика, иногда с альфа-каналом.", "edit": "Сохраняй глубину цвета и альфа-канал, если они есть.", "tool": "Графический редактор", "risk": "Средний"},
    ".wav": {"type": "Аудио WAV", "purpose": "Звуковой ресурс.", "edit": "Сохраняй частоту дискретизации, каналы и разрядность оригинала, если игра ожидает конкретные параметры.", "tool": "Аудиоредактор", "risk": "Средний"},
    ".ogg": {"type": "Аудио OGG", "purpose": "Сжатый звуковой ресурс.", "edit": "Проверяй, что игра и исходный ресурс используют именно OGG и совместимый кодек.", "tool": "Аудиоконвертер", "risk": "Средний"},
    ".mp3": {"type": "Аудио MP3", "purpose": "Сжатый звуковой файл.", "edit": "Сохраняй совместимую частоту и длительность; не меняй только расширение.", "tool": "Аудиоредактор", "risk": "Средний"},
    ".flac": {"type": "Аудио FLAC", "purpose": "Аудио без потерь; поддержка игры не гарантирована.", "edit": "Для игровых ресурсов конвертируй в исходный формат и параметры, если FM2010 не поддерживает FLAC.", "tool": "Аудиоконвертер", "risk": "Средний"},
    ".mid": {"type": "MIDI", "purpose": "Музыкальные события и ноты, а не обычная аудиозапись.", "edit": "Редактируй в MIDI-секвенсоре; проверь инструменты и совместимый MIDI-банк.", "tool": "MIDI-секвенсор", "risk": "Средний"},
    ".midi": {"type": "MIDI", "purpose": "Музыкальные события и ноты.", "edit": "Редактируй в MIDI-секвенсоре, сохрани дорожки и тайминг.", "tool": "MIDI-секвенсор", "risk": "Средний"},
    ".zip": {"type": "ZIP-архив", "purpose": "Мод-пак, резервная копия или набор файлов.", "edit": "Сначала проверь список содержимого и пути. Не запускай неизвестные EXE из архива; извлекай только в отдельную папку.", "tool": "ZIP-проверка / менеджер патчей", "risk": "Средний"},
    ".7z": {"type": "Архив 7-Zip", "purpose": "Сжатый архив с файлами или модом.", "edit": "Проверь список файлов и извлекай в отдельную staging-папку; не запускай неизвестные исполняемые файлы.", "tool": "7-Zip / архиватор", "risk": "Средний"},
    ".rar": {"type": "Архив RAR", "purpose": "Сжатый архив с ресурсами или модом.", "edit": "Сначала проверь содержимое и пути, затем распакуй в отдельную папку.", "tool": "Совместимый архиватор", "risk": "Средний"},
    ".cab": {"type": "Архив CAB", "purpose": "Архивный контейнер установщика или компонента Windows/игры.", "edit": "Не редактируй содержимое напрямую; сначала распакуй копию и выясни источник.", "tool": "Архиватор CAB", "risk": "Средний–высокий"},
    ".sav": {"type": "Сохранение игры", "purpose": "Состояние игровой карьеры.", "edit": "Не редактируй как текст/HEX. Создавай копии и используй совместимый редактор сохранений, если он поддерживает конкретный релиз.", "tool": "Менеджер сохранений / совместимый редактор", "risk": "Очень высокий"},
    ".fm": {"type": "Файл FM / возможное сохранение", "purpose": "В контексте папки games/saves может быть сохранением карьеры; вне неё назначение не гарантировано.", "edit": "Не редактируй текстом и не меняй HEX без спецификации. Создай копию и проверь в самой игре или совместимом редакторе.", "tool": "Менеджер сохранений / игра", "risk": "Очень высокий"},
    ".ttf": {"type": "Шрифт TrueType", "purpose": "Файл шрифта интерфейса или оформления.", "edit": "Сам шрифт лучше не патчить; для замены проверь лицензию, имена семейств и поддержку движком.", "tool": "Font editor / менеджер скина", "risk": "Средний"},
    ".otf": {"type": "Шрифт OpenType", "purpose": "Файл шрифта.", "edit": "Проверь совместимость со старым движком и лицензию на распространение.", "tool": "Font editor / менеджер скина", "risk": "Средний"},
    ".html": {"type": "HTML", "purpose": "Страница справки, интерфейс или локальная документация.", "edit": "Можно править в редакторе кода; сохраняй ссылки на ресурсы и относительные пути.", "tool": "Редактор кода", "risk": "Низкий–средний"},
    ".css": {"type": "CSS", "purpose": "Стили веб-страницы или встроенного UI-компонента.", "edit": "Меняй правила по одному и проверяй фактическое использование файла игрой.", "tool": "Редактор кода", "risk": "Средний"},
    ".vdf": {"type": "Valve Data Format", "purpose": "Текстовые настройки/метаданные экосистемы Steam или игровых инструментов.", "edit": "Не путай со структурой базы FM. Сохраняй фигурные скобки, кавычки и иерархию.", "tool": "Текстовый редактор", "risk": "Средний"},
    ".acf": {"type": "Файл состояния Steam", "purpose": "Может содержать метаданные установки приложения Steam, а не данные игрового мода.", "edit": "Не меняй вручную: Steam использует этот файл для учёта установки.", "tool": "Steam / резервная копия", "risk": "Высокий"},
    ".db": {"type": "Файл с данными", "purpose": "Может быть SQLite или проприетарной базой; проверяй сигнатуру, не только расширение.", "edit": "Если это SQLite, сначала открывай read-only и делай копию. Если формат неизвестен — не выполняй SQL и не меняй байты.", "tool": "SQLite Explorer только после распознавания", "risk": "Высокий"},
    ".bak": {"type": "Резервная копия", "purpose": "Копия файла или состояние до изменения.", "edit": "Обычно не редактируют. Сверь источник, дату и контрольную сумму; восстанови через менеджер backup.", "tool": "Backup Vault", "risk": "Низкий"},
}

FOLDER_GUIDES = [
    ("editor data", "Папка editor data с изменениями базы, созданными Data Editor. Содержит отдельные файлы изменений; не заменяй штатный config.xml.", "Football Manager 2010 Data Editor; размещай итоговые XML/DBC в Documents\\Sports Interactive\\Football Manager 2010\\editor data.", "Средний–высокий"),
    ("graphics", "Папка пользовательской графики: портреты, эмблемы, формы и другие изображения. Связь с игровым объектом часто задаётся config.xml.", "Редактор изображений + редактор config.xml; проверь атрибуты from/to и соответствие ID или именному шаблону.", "Средний"),
    ("preferences", "Папка пользовательских настроек FM. Состав и формат зависят от установленного патча.", "Сначала резервная копия; меняй только известные текстовые параметры, неизвестные файлы оставляй без изменений.", "Средний"),
    ("\\lnc\\all", "Каталог текстовых инструкций LNC, применяемых к данным Football Manager.", "Текстовый редактор; внимательно сохраняй синтаксис, кавычки и ID, сверяй версию базы.", "Средний"),
    ("skins", "Пользовательские скины и интерфейсные ресурсы.", "Работай в копии скина; проверь его совместимость с FM2010 и ссылки на графику.", "Средний"),
    ("data\\db", "Версионные игровые базы и связанные с ними ресурсы. Содержимое может быть проприетарным.", "Не редактируй файлы базы вручную; для правок базы используй FM2010 Data Editor и экспортируемые изменения.", "Высокий"),
]


def detect_file_signature(path: Path) -> str:
    """Lightweight signature check; extension is never treated as proof of format."""
    try:
        with path.open("rb") as stream:
            head = stream.read(32)
    except OSError:
        return "Недоступен"
    if not head:
        return "Пустой файл"
    signatures = (
        (b"MZ", "PE/EXE (MZ)"), (b"\x89PNG\r\n\x1a\n", "PNG"),
        (b"\xff\xd8\xff", "JPEG"), (b"GIF87a", "GIF"), (b"GIF89a", "GIF"),
        (b"BM", "BMP"), (b"DDS ", "DDS"), (b"PK\x03\x04", "ZIP"),
        (b"SQLite format 3\x00", "SQLite"), (b"OggS", "OGG"),
        (b"ID3", "MP3"), (b"\x1f\x8b", "GZIP"), (b"7z\xbc\xaf\x27\x1c", "7-Zip"),
        (b"Rar!\x1a\x07", "RAR"), (b"%PDF-", "PDF"),
    )
    for prefix, label in signatures:
        if head.startswith(prefix): return label
    if head.startswith(b"RIFF") and head[8:12] == b"WAVE": return "WAVE"
    if b"\x00" in head: return "Неизвестный бинарный"
    try:
        head.decode("utf-8")
        return "Текст UTF-8 / сигнатура не определена"
    except UnicodeError:
        return "Текст или бинарный формат не определён"


def explain_game_file(path: Path, game_root: Path) -> dict[str, str]:
    """Explain a path from known extension and folder heuristics; never overclaim."""
    suffix = path.suffix.lower()
    info = dict(FILE_KNOWLEDGE.get(suffix, {
        "type": "Неизвестный / специализированный формат",
        "purpose": "Назначение неизвестно: его нельзя достоверно определить только по имени или расширению.",
        "edit": "Сначала проверь сигнатуру, источник файла и документацию формата. Сделай резервную копию; не редактируй HEX наугад.",
        "tool": "Инспектор / резервное копирование / инструмент автора формата",
        "risk": "Неизвестный — действуй осторожно",
    }))
    rel = ""
    try:
        rel = str(path.resolve().relative_to(game_root.resolve())).replace("\\", "/")
    except (OSError, ValueError):
        rel = str(path)
    # Use the absolute path for folder context too: a user may select the
    # editor data directory itself as the catalog root.
    lower = str(path.resolve()).replace("\\", "/").casefold()
    for marker, purpose, edit, risk in FOLDER_GUIDES:
        normalized_marker = marker.replace("\\", "/").strip("/").casefold()
        if normalized_marker in lower:
            info["folder_context"] = purpose
            info["folder_edit"] = edit
            if risk in {"Высокий", "Средний–высокий"}:
                info["risk"] = risk
            break
    if path.name.casefold() == "fm.exe":
        info.update(type="Главный исполняемый файл FM2010", purpose="Основной файл запуска Football Manager 2010.", edit="Не редактируй вручную. Для восстановления используй проверку файлов игры в Steam. Всегда сохраняй данные карьеры отдельно.", tool="Steam: проверка целостности / запуск игры", risk="Очень высокий")
    elif path.name.casefold() == "config.xml" and "editor data" in lower:
        info.update(type="Системный config.xml Editor Data", purpose="Файл конфигурации, необходимый папке editor data; в руководствах FM2010 указано не перезаписывать его.", edit="Не заменяй шаблоном и не удаляй. Новые файлы изменений сохраняй под собственными именами в этой папке.", tool="FM2010 Data Editor / резервная копия", risk="Высокий")
    signature = detect_file_signature(path)
    if suffix in {".db", ".sqlite", ".sqlite3"} and signature == "SQLite":
        info.update(type="База SQLite", purpose="Содержимое имеет сигнатуру SQLite. Это подтверждает контейнер базы, но не доказывает, что она относится к FM2010.", edit="Открывай только read-only для изучения, сначала сделай копию. Изменение таблиц может повредить приложение, которое использует эту базу.", tool="SQLite Explorer (только чтение)", risk="Высокий")
    info["signature"] = signature
    info["confidence"] = "Контекст папки + имя файла" if "folder_context" in info else ("Тип по расширению; назначение эвристическое" if suffix else "Только имя и расположение")
    return info


def _git_exe() -> str | None:
    return shutil.which("git")


def _gh_exe() -> str | None:
    return shutil.which("gh")


def _run_git(args: list[str], cwd: Path, timeout: int = 90) -> tuple[int, str]:
    exe = _git_exe()
    if not exe:
        return 127, "Git не найден. Установи Git for Windows и перезапусти приложение."
    try:
        proc = subprocess.run([exe, *args], cwd=str(cwd), capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=timeout,
                              stdin=subprocess.DEVNULL, shell=False)
        output = (proc.stdout or "") + (proc.stderr or "")
        return proc.returncode, output.strip()
    except subprocess.TimeoutExpired:
        return 124, f"Команда превысила лимит времени {timeout} сек."
    except OSError as exc:
        return 1, str(exc)


class Release6Mixin:
    """Final global workbench, added without replacing the existing tool windows."""

    def open_global_workbench(self) -> None:
        try:
            game_root = self._require_install_root()
        except Exception as exc:
            messagebox.showwarning("GLOBAL WORKBENCH 6.0", str(exc), parent=self)
            return

        win = tk.Toplevel(self)
        win.title("FM2010 Modding Suite — GLOBAL RELEASE 6.0")
        win.geometry("1480x960")
        win.minsize(1120, 760)
        try:
            win.state("zoomed")
        except tk.TclError:
            pass
        win.transient(self)

        header = ttk.Frame(win, padding=12)
        header.pack(fill="x")
        ttk.Label(header, text="FM2010 MODDING SUITE · GLOBAL RELEASE 6.0", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(header, text=f"Игра: {game_root}  |  Git/GitHub + каталог назначения файлов + аудит + мастер мод-проекта", wraplength=1400).pack(anchor="w", pady=(3, 0))

        nb = ttk.Notebook(win)
        nb.pack(fill="both", expand=True, padx=10, pady=8)
        tab_names = [
            ("home", "Панель"), ("github", "GitHub / Git"), ("catalog", "Справочник файлов"),
            ("audit", "Глубокий аудит"), ("project", "Мастер проекта"),
            ("editor", "FM Data Editor"), ("compat", "Совместимость"),
        ]
        tabs: dict[str, ttk.Frame] = {}
        for key, title in tab_names:
            tabs[key] = ttk.Frame(nb, padding=12)
            nb.add(tabs[key], text=title)

        status_var = tk.StringVar(value="Готово")
        ttk.Label(win, textvariable=status_var, relief="sunken", anchor="w", padding=5).pack(fill="x", side="bottom")
        output = tk.Text(win, height=8, wrap="word", font=("Consolas", 9))
        output.pack(fill="x", padx=10, pady=(0, 8))

        def log(text: str) -> None:
            output.insert("end", f"[{dt.datetime.now():%H:%M:%S}] {text}\n")
            output.see("end")
            try:
                self.log("GLOBAL 6.0: %s", text)
            except Exception:
                pass

        result_queue: queue.Queue[tuple[str, int, str]] = queue.Queue()
        def poll_results() -> None:
            try:
                while True:
                    label, code, result = result_queue.get_nowait()
                    status_var.set(f"{label}: {'готово' if code == 0 else 'ошибка'} (код {code})")
                    log((label + "\n" + (result or "Нет вывода")).strip())
            except queue.Empty:
                pass
            if win.winfo_exists():
                win.after(150, poll_results)
        win.after(150, poll_results)

        def run_async(label: str, command: list[str], cwd: Path, timeout: int = 180) -> None:
            status_var.set(label + " — выполняется…")
            log(f"Команда: {' '.join(command[:4])}{' …' if len(command) > 4 else ''}  |  Каталог: {cwd}")
            def worker() -> None:
                try:
                    proc = subprocess.run(command, cwd=str(cwd), capture_output=True, text=True,
                                          encoding="utf-8", errors="replace", timeout=timeout,
                                          stdin=subprocess.DEVNULL, shell=False)
                    result_queue.put((label, proc.returncode, ((proc.stdout or "") + (proc.stderr or "")).strip()))
                except subprocess.TimeoutExpired:
                    result_queue.put((label, 124, f"Превышено время ожидания: {timeout} сек."))
                except OSError as exc:
                    result_queue.put((label, 1, str(exc)))
            threading.Thread(target=worker, daemon=True).start()

        def reveal(path: Path) -> None:
            try:
                if os.name == "nt": os.startfile(str(path))  # type: ignore[attr-defined]
                else: webbrowser.open(path.resolve().as_uri())
            except Exception as exc:
                messagebox.showerror("Открытие", str(exc), parent=win)

        # HOME / status card
        home = tabs["home"]
        ttk.Label(home, text="Финальная рабочая панель для модов Football Manager 2010. Все изменения в этой версии остаются под твоим контролем: сначала просмотр, затем резервирование и только после этого изменение.", wraplength=1350, font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 10))
        summary_var = tk.StringVar(value="Нажми «Провести анализ», чтобы получить сводку по выбранной установке.")
        ttk.Label(home, textvariable=summary_var, padding=16, relief="groove", wraplength=1350, justify="left").pack(fill="x", pady=6)
        home_grid = ttk.Frame(home); home_grid.pack(fill="both", expand=True, pady=12)
        quick = [
            ("Каталог назначений файлов", "catalog"), ("GitHub / Git", "github"),
            ("Аудит установки", "audit"), ("Мастер проекта мода", "project"),
            ("FM Data Editor и Editor Data", "editor"), ("Проверка совместимости", "compat"),
        ]
        for idx, (label, key) in enumerate(quick):
            ttk.Button(home_grid, text=label, command=lambda k=key: nb.select(tabs[k])).grid(row=idx//3, column=idx%3, sticky="nsew", padx=6, pady=6, ipady=20)
        for c in range(3): home_grid.columnconfigure(c, weight=1)
        for r in range(2): home_grid.rowconfigure(r, weight=1)
        def quick_scan() -> None:
            count = 0; total = 0; ext: dict[str, int] = {}; fmexe = (game_root / "fm.exe").is_file()
            for current, dirs, files in os.walk(game_root):
                dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "cache", ".fm2010_backups"}]
                for name in files:
                    p = Path(current) / name
                    try:
                        if p.is_symlink(): continue
                        st = p.stat(); count += 1; total += st.st_size
                        ext[p.suffix.lower() or "[без расширения]"] = ext.get(p.suffix.lower() or "[без расширения]", 0) + 1
                    except OSError: pass
                    if count >= MAX_CATALOG_FILES: break
                if count >= MAX_CATALOG_FILES: break
            summary_var.set(f"Файлов проанализировано: {count:,}\nОбщий объём: {total/1024/1024:,.1f} МБ\nfm.exe в корне: {'найден' if fmexe else 'не найден'}\nСамые частые типы: " + ", ".join(f"{k} ({v})" for k,v in sorted(ext.items(),key=lambda x:x[1],reverse=True)[:12]))
            log(f"Анализ завершён: {count} файлов")
        ttk.Button(home, text="Провести анализ установки", command=quick_scan).pack(anchor="w", pady=5)

        # GITHUB / GIT PANEL
        github = tabs["github"]
        ttk.Label(github, text="Подключение через официальные Git и GitHub CLI. Приложение не просит и не сохраняет PAT/пароль. Авторизация выполняется в отдельном окне GitHub CLI.", wraplength=1350).pack(anchor="w", pady=(0, 8))
        github_workspace = self.app_data_dir / "GitHubProjects"
        github_workspace.mkdir(parents=True, exist_ok=True)
        repo_var = tk.StringVar(value=str(github_workspace))
        repo_row = ttk.Frame(github); repo_row.pack(fill="x", pady=4)
        ttk.Label(repo_row, text="Папка проекта:").pack(side="left")
        ttk.Entry(repo_row, textvariable=repo_var).pack(side="left", fill="x", expand=True, padx=6)
        def choose_repo_dir() -> None:
            value = filedialog.askdirectory(parent=win, title="Выбери папку своего проекта / мода")
            if value: repo_var.set(value)
        ttk.Button(repo_row, text="Выбрать…", command=choose_repo_dir).pack(side="left")
        ttk.Label(github, text="ВАЖНО: выбирай папку своего мода/проекта, а не корень установленной игры. Не публикуй оригинальные игровые EXE, DLL, базы, графику и другие файлы, на распространение которых у тебя нет прав.", foreground="#9a4b00", wraplength=1350).pack(anchor="w", pady=(2, 10))
        gh_status = tk.StringVar(value="Git: проверка… | GitHub CLI: проверка…")
        ttk.Label(github, textvariable=gh_status, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=4)
        def check_tools() -> None:
            gh_status.set(f"Git: {'найден' if _git_exe() else 'не найден'} | GitHub CLI: {'найден' if _gh_exe() else 'не найден'}")
        check_tools()
        g_actions = ttk.Frame(github); g_actions.pack(fill="x", pady=4)
        def run_git_action(args: list[str], label: str, timeout: int = 90) -> None:
            project = Path(repo_var.get()).expanduser()
            if not project.exists() or not project.is_dir():
                messagebox.showerror("Git", "Сначала выбери существующую папку проекта.", parent=win); return
            if not _git_exe():
                messagebox.showwarning("Git не найден", "Установи Git for Windows, затем перезапусти Suite.", parent=win); return
            mutating = {"init", "add", "commit", "push", "pull", "switch", "checkout", "merge", "reset", "rebase", "tag"}
            if args and args[0] in mutating and is_game_install_tree(project):
                messagebox.showerror("Защита папки игры", "Изменяющие Git-операции запрещены в папке установки игры, её подпапках и родительских каталогах. Используй отдельный mod workspace.", parent=win); return
            run_async(label, [_git_exe() or "git", *args], project, timeout)
        def is_game_install_tree(project: Path) -> bool:
            try:
                resolved = project.resolve()
                return (resolved == game_root.resolve() or game_root.resolve() in resolved.parents or resolved in game_root.resolve().parents)
            except OSError:
                return False
        def git_init() -> None:
            project = Path(repo_var.get()).expanduser()
            if is_game_install_tree(project):
                messagebox.showerror("Защита папки игры", "Не создавай Git-репозиторий внутри установленной игры. Создай отдельную папку проекта мода.", parent=win); return
            if not project.exists():
                if messagebox.askyesno("Создать проект", f"Создать папку?\n{project}", parent=win): project.mkdir(parents=True, exist_ok=True)
                else: return
            if (project / ".git").exists():
                messagebox.showinfo("Git", "В этой папке уже есть репозиторий.", parent=win); return
            run_git_action(["init", "-b", "main"], "Создание Git-репозитория")
        def auth_login() -> None:
            gh = _gh_exe()
            if not gh:
                messagebox.showwarning("GitHub CLI не найден", "Установи GitHub CLI (gh), затем нажми «Проверить инструменты». Токен в приложение вводить не нужно.", parent=win)
                webbrowser.open("https://cli.github.com/")
                return
            try:
                flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0) if os.name == "nt" else 0
                subprocess.Popen([gh, "auth", "login", "--web"], cwd=repo_var.get(), creationflags=flags, shell=False)
                log("Открыта отдельная консоль для авторизации GitHub CLI")
            except OSError as exc: messagebox.showerror("GitHub login", str(exc), parent=win)
        def gh_status() -> None:
            gh = _gh_exe()
            if not gh: messagebox.showwarning("GitHub CLI", "GitHub CLI не найден. Установи его с официального сайта.", parent=win); webbrowser.open("https://cli.github.com/"); return
            project = Path(repo_var.get()).expanduser()
            if not project.is_dir(): project = Path.home()
            run_async("Статус авторизации GitHub", [gh, "auth", "status"], project, 25)
        def clone_repo() -> None:
            url = simpledialog.askstring("Клонировать репозиторий", "Ссылка https://github.com/owner/repo или SSH-ссылка:", parent=win)
            if not url: return
            url = url.strip()
            if not (url.startswith("https://github.com/") or url.startswith("git@github.com:")) or any(c in url for c in "\r\n\x00"):
                messagebox.showerror("Ссылка", "Поддерживаются только HTTPS/SSH-ссылки github.com.", parent=win); return
            dest = filedialog.askdirectory(parent=win, title="Выбери папку, внутри которой создать копию репозитория")
            if not dest: return
            if is_game_install_tree(Path(dest)):
                messagebox.showerror("Защита папки игры", "Не клонируй репозитории внутрь папки установленной игры.", parent=win); return
            command = [_git_exe() or "git", "clone", url, str(Path(dest) / url.rstrip("/").split("/")[-1].removesuffix(".git"))]
            run_async("Клонирование репозитория", command, Path(dest), 600)
        def create_remote() -> None:
            project = Path(repo_var.get()).expanduser()
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Нельзя создавать GitHub-репозиторий из папки игры, её подпапок или родительских каталогов. Создай отдельную папку мода.", parent=win); return
            if not (project / ".git").is_dir(): messagebox.showwarning("Git", "Сначала инициализируй Git-репозиторий.", parent=win); return
            gh = _gh_exe()
            if not gh: messagebox.showwarning("GitHub CLI", "Установи GitHub CLI и авторизуйся.", parent=win); return
            if not messagebox.askyesno("Создать приватный репозиторий", "Создать PRIVATE-репозиторий GitHub из выбранной папки?\nФайлы пока не будут отправлены; перед push нужно проверить список изменений.", parent=win): return
            name = simpledialog.askstring("Имя репозитория", "Название репозитория GitHub:", initialvalue=project.name, parent=win)
            if not name: return
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", name.strip()): messagebox.showerror("Имя", "Используй латинские буквы, цифры, точку, дефис или подчёркивание.", parent=win); return
            run_async("Создание приватного репозитория", [gh, "repo", "create", name.strip(), "--private", "--source", str(project), "--remote", "origin"], project, 180)
        def browse_repo() -> None:
            gh = _gh_exe(); project = Path(repo_var.get()).expanduser()
            if not gh or not project.is_dir(): messagebox.showwarning("GitHub", "Проверь GitHub CLI и папку проекта.", parent=win); return
            run_async("Открытие репозитория в браузере", [gh, "browse"], project, 30)
        def commit_all() -> None:
            project = Path(repo_var.get()).expanduser()
            if not (project / ".git").is_dir(): messagebox.showwarning("Git", "Сначала создай или клонируй Git-репозиторий.", parent=win); return
            if is_game_install_tree(project) or (project / "fm.exe").exists():
                messagebox.showerror("Защита от публикации игры", "Похоже, выбрана папка установки FM2010 или её вложенная папка. Отправка всего содержимого заблокирована. Создай отдельную папку мода и перенеси туда только свои файлы.", parent=win); return
            msg = simpledialog.askstring("Commit", "Сообщение коммита:", parent=win)
            if not msg or not msg.strip(): return
            if not messagebox.askyesno("Проверка", "Будут добавлены все файлы, не исключённые .gitignore (git add -A). Сначала проверь статус и список! Продолжить?", parent=win): return
            # Stage then commit in a single thread task, no shell; preserve clear output.
            def worker_commit() -> None:
                code1, out1 = _run_git(["add", "-A"], project)
                if code1:
                    result_queue.put(("Добавление файлов", code1, out1)); return
                code2, out2 = _run_git(["commit", "-m", msg.strip()], project)
                result_queue.put(("Commit", code2, (out1 + "\n" + out2).strip()))
            status_var.set("Commit — выполняется…")
            threading.Thread(target=worker_commit, daemon=True).start()
        def new_gitignore() -> None:
            project = Path(repo_var.get()).expanduser()
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Не создавай Git-файлы в каталоге установленной игры или его родительских папках. Выбери отдельную папку мода.", parent=win); return
            if not project.is_dir(): messagebox.showwarning(".gitignore", "Выбери существующую папку проекта.", parent=win); return
            target = project / ".gitignore"
            if target.exists() and not messagebox.askyesno("Перезаписать .gitignore?", "Файл уже существует. Перезаписать его резервной копией?", parent=win): return
            if target.exists(): shutil.copy2(target, target.with_suffix(".gitignore.backup"))
            text = """# FM2010 Modding Suite — generated safe defaults\n# Local caches and temporary output\n__pycache__/\n*.py[cod]\n*.tmp\n*.temp\n*.log\n*.bak\n*.backup\n.cache/\ncache/\ncrash dumps/\n\n# Personal saves and private settings — do not publish\nsaves/\n*.sav\n*.fm\npreferences/\n\n# Secrets and local credentials\n.env\n.env.*\n!.env.example\n*.pem\n*.key\n\n# Installed game binaries (do not commit original game executable/code)\n*.exe\n*.dll\n*.pyd\n*.sys\n\n# Database sidecar caches\n*.db-wal\n*.db-shm\n*.sqlite-wal\n*.sqlite-shm\n\n# Suite local data\n.fm2010_backups/\nFM2010SettingsTool/\n"""
            target.write_text(text, encoding="utf-8")
            log("Создан .gitignore с исключениями для кэша, сохранений, настроек и исполняемых файлов. Проверь его перед git add.")
        def write_readme() -> None:
            project = Path(repo_var.get()).expanduser()
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Не создавай Git-файлы в каталоге установленной игры или его родительских папках. Выбери отдельную папку мода.", parent=win); return
            if not project.is_dir(): messagebox.showwarning("README", "Сначала выбери существующую папку проекта.", parent=win); return
            name = simpledialog.askstring("README", "Название мода:", initialvalue=project.name, parent=win)
            if not name: return
            target = project / "README.md"
            if target.exists() and not messagebox.askyesno("README", "README.md уже существует. Заменить?", parent=win): return
            if target.exists(): shutil.copy2(target, project / "README.md.backup")
            target.write_text(f"# {name.strip()}\n\nМодификация для Football Manager 2010.\n\n## Установка\n\n1. Сделайте резервную копию исходных файлов.\n2. Скопируйте только файлы мода в соответствующие пользовательские папки FM2010.\n3. Проверьте совместимость с версией игры и патчем.\n\n## Состав\n\nОпишите изменённые файлы и их назначение. Не включайте оригинальные файлы игры без разрешения на распространение.\n\n## Совместимость\n\n- Игра: Football Manager 2010\n- Версия/патч: укажите проверенную версию\n\n## Авторы и источники\n\nУкажите авторов, лицензии и ссылки на источники используемых ресурсов.\n", encoding="utf-8")
            log("README.md создан")
        def configure_git_author() -> None:
            project = Path(repo_var.get()).expanduser()
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Не меняй Git-конфигурацию в каталоге установленной игры или его родительских папках.", parent=win); return
            if not (project / ".git").is_dir():
                messagebox.showwarning("Git", "Сначала создай локальный репозиторий.", parent=win); return
            name = simpledialog.askstring("Автор коммитов", "Имя автора (user.name):", parent=win)
            if not name or not name.strip(): return
            email = simpledialog.askstring("Автор коммитов", "Email автора (user.email):", parent=win)
            if not email or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email.strip()):
                messagebox.showerror("Email", "Укажи корректный email для Git.", parent=win); return
            def worker_config() -> None:
                code1, out1 = _run_git(["config", "user.name", name.strip()], project)
                code2, out2 = _run_git(["config", "user.email", email.strip()], project) if code1 == 0 else (code1, "Настройка email пропущена.")
                result_queue.put(("Настройка автора Git", code1 or code2, (out1 + "\n" + out2).strip()))
            status_var.set("Настройка автора Git…")
            threading.Thread(target=worker_config, daemon=True).start()
        def create_branch() -> None:
            project = Path(repo_var.get()).expanduser()
            if not (project / ".git").is_dir():
                messagebox.showwarning("Git", "Сначала создай локальный репозиторий.", parent=win); return
            branch = simpledialog.askstring("Новая ветка", "Название новой ветки:", parent=win)
            if not branch: return
            branch = branch.strip()
            if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,90}", branch) or ".." in branch or branch.endswith("/") or branch.endswith(".lock"):
                messagebox.showerror("Ветка", "Некорректное имя ветки Git.", parent=win); return
            run_git_action(["switch", "-c", branch], "Создание и переключение ветки")
        def push() -> None:
            project = Path(repo_var.get()).expanduser()
            if not (project / ".git").is_dir(): messagebox.showwarning("Git", "Нет локального репозитория.", parent=win); return
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Нельзя отправлять изменения из каталога установленной игры.", parent=win); return
            if not messagebox.askyesno("Отправить изменения", "Отправить локальные коммиты на удалённый GitHub-репозиторий? Убедись, что секреты и оригинальные игровые файлы не попали в коммит.", parent=win): return
            run_git_action(["push", "-u", "origin", "HEAD"], "Отправка на GitHub", 240)
        def pull() -> None:
            project = Path(repo_var.get()).expanduser()
            if not (project / ".git").is_dir(): messagebox.showwarning("Git", "Нет локального репозитория.", parent=win); return
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Нельзя выполнять pull в каталоге установленной игры.", parent=win); return
            if not messagebox.askyesno("Получить изменения", "Выполнить git pull? Несохранённые изменения лучше сначала закоммитить или сохранить отдельно.", parent=win): return
            run_git_action(["pull", "--ff-only"], "Получение изменений", 240)
        def create_github_release() -> None:
            gh = _gh_exe(); project = Path(repo_var.get()).expanduser()
            if not gh: messagebox.showwarning("GitHub CLI", "Установи GitHub CLI и авторизуйся.", parent=win); return
            if not (project / ".git").is_dir(): messagebox.showwarning("Git", "Выбранная папка не является Git-репозиторием.", parent=win); return
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Нельзя публиковать GitHub Release из каталога установленной игры.", parent=win); return
            asset = filedialog.askopenfilename(parent=win, title="Выбери ZIP модификации для прикрепления к релизу", filetypes=(("ZIP мод", "*.zip"), ("Все файлы", "*.*")))
            if not asset: return
            tag = simpledialog.askstring("Тег релиза", "Например v1.0.0:", parent=win)
            if not tag or not re.fullmatch(r"v?[0-9A-Za-z][0-9A-Za-z._-]{0,40}", tag.strip()): return
            title = simpledialog.askstring("Название релиза", "Название релиза:", initialvalue=tag.strip(), parent=win)
            if not title: return
            notes = simpledialog.askstring("Описание релиза", "Кратко опиши изменения:", parent=win)
            if notes is None: return
            if not messagebox.askyesno("Опубликовать релиз", f"Создать GitHub Release {tag.strip()} и загрузить:\n{asset}\n\nПродолжить?", parent=win): return
            command = [gh, "release", "create", tag.strip(), asset, "--title", title.strip(), "--notes", notes]
            run_async("Создание GitHub Release", command, project, 300)
        def create_pull_request() -> None:
            gh = _gh_exe(); project = Path(repo_var.get()).expanduser()
            if not gh or not (project / ".git").is_dir(): messagebox.showwarning("GitHub", "Нужны GitHub CLI и открытый репозиторий.", parent=win); return
            if is_game_install_tree(project): messagebox.showerror("Защита папки игры", "Нельзя создавать Pull Request из папки установки игры.", parent=win); return
            if not messagebox.askyesno("Pull Request", "Открыть браузерный мастер Pull Request для текущей ветки? Сначала отправь ветку через Push.", parent=win): return
            run_async("Открытие Pull Request", [gh, "pr", "create", "--fill", "--web"], project, 120)

        actions = [
            ("Проверить статус", lambda: run_git_action(["status", "--short", "--branch"], "Git status")),
            ("Показать diff", lambda: run_git_action(["diff", "--stat"], "Git diff")),
            ("Создать локальный репозиторий", git_init), ("Авторизация GitHub…", auth_login),
            ("Проверить авторизацию", gh_status), ("Клонировать GitHub…", clone_repo),
            ("Создать PRIVATE repo", create_remote), ("Настроить автора Git", configure_git_author),
            ("Новая ветка", create_branch), ("Commit всех файлов…", commit_all),
            ("Push", push), ("Pull (ff-only)", pull), ("История коммитов", lambda: run_git_action(["log", "--oneline", "-20"], "История коммитов")),
            ("Ветки", lambda: run_git_action(["branch", "-a"], "Список веток")),
            ("Открыть GitHub repo", browse_repo), ("Создать GitHub Release…", create_github_release),
            ("Pull Request…", create_pull_request), ("Создать .gitignore", new_gitignore),
            ("Создать README.md", write_readme), ("Проверить Git / gh", check_tools),
            ("Скачать Git for Windows", lambda: webbrowser.open("https://git-scm.com/install/windows")),
            ("Скачать GitHub CLI", lambda: webbrowser.open("https://cli.github.com/")),
        ]
        for i, (label, command) in enumerate(actions):
            ttk.Button(g_actions, text=label, command=command).grid(row=i//3, column=i%3, padx=4, pady=4, sticky="ew", ipady=5)
        for c in range(3): g_actions.columnconfigure(c, weight=1)
        ttk.Label(github, text="Полезно: GitHub CLI поддерживает браузерную авторизацию и операции с репозиториями. Suite вызывает git/gh без shell-команд и по умолчанию предлагает PRIVATE-репозиторий.", foreground="#555", wraplength=1350).pack(anchor="w", pady=10)

        # FILE ENCYCLOPEDIA
        catalog = tabs["catalog"]
        ttk.Label(catalog, text="Справочник объясняет назначение и способ изменения каждого найденного файла. Описание строится по расширению, сигнатуре имени и контексту папки; если конкретное назначение неизвестно, это явно отмечается.", wraplength=1350).pack(anchor="w", pady=(0, 8))
        scan_row = ttk.Frame(catalog); scan_row.pack(fill="x", pady=4)
        catalog_root_var = tk.StringVar(value=str(game_root))
        active_catalog_root = [game_root]
        ttk.Label(scan_row, text="Папка для сканирования:").pack(side="left")
        ttk.Entry(scan_row, textvariable=catalog_root_var).pack(side="left", fill="x", expand=True, padx=5)
        def choose_catalog_root() -> None:
            value = filedialog.askdirectory(parent=win, title="Выбери папку установки или пользовательских данных FM2010", initialdir=catalog_root_var.get())
            if value: catalog_root_var.set(value)
        def choose_fm_user_folder() -> None:
            docs = Path.home() / "Documents" / "Sports Interactive" / "Football Manager 2010"
            if not docs.is_dir(): docs = Path.home() / "Documents"
            value = filedialog.askdirectory(parent=win, title="Выбери папку пользовательских данных FM2010", initialdir=str(docs))
            if value: catalog_root_var.set(value)
        ttk.Button(scan_row, text="Обзор…", command=choose_catalog_root).pack(side="left")
        ttk.Button(scan_row, text="Папка данных FM2010…", command=choose_fm_user_folder).pack(side="left", padx=5)
        filter_row = ttk.Frame(catalog); filter_row.pack(fill="x", pady=4)
        search_var = tk.StringVar(); type_var = tk.StringVar(value="Все")
        ttk.Label(filter_row, text="Поиск:").pack(side="left"); ttk.Entry(filter_row, textvariable=search_var, width=34).pack(side="left", padx=5)
        ttk.Label(filter_row, text="Тип:").pack(side="left", padx=(12, 0))
        ttk.Combobox(filter_row, textvariable=type_var, values=["Все", "Текст", "База / данные", "Графика", "Аудио", "Исполняемые", "Архив", "Неизвестные"], state="readonly", width=18).pack(side="left", padx=5)
        columns = ("path", "ext", "role", "signature", "size", "risk")
        holder = ttk.Frame(catalog); holder.pack(fill="both", expand=True)
        file_tree = ttk.Treeview(holder, columns=columns, show="headings", selectmode="browse")
        for col, title, width in (("path","Путь в выбранной папке",400),("ext","Расширение",75),("role","Назначение",290),("signature","Сигнатура",180),("size","Размер",95),("risk","Риск",145)):
            file_tree.heading(col, text=title); file_tree.column(col, width=width, anchor="w")
        ybar = ttk.Scrollbar(holder, orient="vertical", command=file_tree.yview); xbar = ttk.Scrollbar(holder, orient="horizontal", command=file_tree.xview)
        file_tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        file_tree.grid(row=0,column=0,sticky="nsew"); ybar.grid(row=0,column=1,sticky="ns"); xbar.grid(row=1,column=0,sticky="ew")
        holder.rowconfigure(0,weight=1); holder.columnconfigure(0,weight=1)
        catalog_detail = tk.Text(catalog, height=9, wrap="word", font=("Segoe UI", 9)); catalog_detail.pack(fill="x", pady=(8, 0))
        catalog_rows: list[tuple[Path, dict[str, str], int]] = []
        visible_rows: list[tuple[Path, dict[str, str], int]] = []
        def classify_for_filter(info: dict[str, str]) -> str:
            t = info["type"].casefold()
            if any(x in t for x in ("исполняемый", "библиотека")): return "Исполняемые"
            if any(x in t for x in ("изображение", "текстура", "шрифт")): return "Графика"
            if "аудио" in t or "midi" in t: return "Аудио"
            if any(x in t for x in ("база", "данные", "dbc", "контейнер")): return "База / данные"
            if any(x in t for x in ("архив", "zip")): return "Архив"
            if any(x in t for x in ("неизвестный",)): return "Неизвестные"
            return "Текст"
        def apply_catalog_filter(*_args) -> None:
            file_tree.delete(*file_tree.get_children()); visible_rows.clear()
            query = search_var.get().casefold().strip(); filt = type_var.get()
            for p, info, size in catalog_rows:
                rel = str(p.relative_to(active_catalog_root[0])).replace("\\", "/")
                text = (rel + " " + info["type"] + " " + info["purpose"]).casefold()
                if query and query not in text: continue
                if filt != "Все" and classify_for_filter(info) != filt: continue
                visible_rows.append((p, info, size))
                if len(visible_rows) <= 8000:
                    file_tree.insert("", "end", iid=str(len(visible_rows)-1), values=(rel, p.suffix.lower() or "—", info["type"], info["signature"], _human_size(size), info["risk"]))
        search_var.trace_add("write", apply_catalog_filter); type_var.trace_add("write", apply_catalog_filter)
        def catalog_scan() -> None:
            scan_root = Path(catalog_root_var.get()).expanduser()
            if not scan_root.is_dir():
                messagebox.showwarning("Справочник", "Выбранная папка не существует.", parent=win); return
            active_catalog_root[0] = scan_root.resolve()
            catalog_rows.clear(); file_tree.delete(*file_tree.get_children())
            scanned = 0
            for current, dirs, names in os.walk(active_catalog_root[0]):
                dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "cache", ".fm2010_backups"}]
                for name in names:
                    p = Path(current) / name
                    try:
                        if p.is_symlink() or not p.is_file(): continue
                        size = p.stat().st_size
                    except OSError: continue
                    info = explain_game_file(p, active_catalog_root[0])
                    catalog_rows.append((p, info, size)); scanned += 1
                    if scanned >= MAX_CATALOG_FILES: break
                if scanned >= MAX_CATALOG_FILES: break
            apply_catalog_filter()
            log(f"Справочник: проиндексировано {scanned} файлов в {active_catalog_root[0]}")
        def show_catalog_detail(_event=None) -> None:
            sel = file_tree.selection()
            if not sel: return
            try: p, info, size = visible_rows[int(sel[0])]
            except (ValueError, IndexError): return
            rel = p.relative_to(active_catalog_root[0])
            body = [f"Файл: {rel}", f"Размер: {_human_size(size)}", f"Категория: {info['type']}", f"Сигнатура содержимого: {info['signature']}", f"Назначение: {info['purpose']}", f"Как изменить: {info['edit']}", f"Рекомендуемый инструмент: {info['tool']}", f"Риск изменения: {info['risk']}", f"Уверенность описания: {info['confidence']}"]
            if info.get("folder_context"): body.extend([f"Контекст папки: {info['folder_context']}", f"Рекомендация по папке: {info['folder_edit']}"])
            catalog_detail.delete("1.0", "end"); catalog_detail.insert("1.0", "\n".join(body))
        file_tree.bind("<<TreeviewSelect>>", show_catalog_detail)
        cbtn = ttk.Frame(catalog); cbtn.pack(fill="x", pady=6)
        ttk.Button(cbtn, text="Сканировать все файлы", command=catalog_scan).pack(side="left")
        def export_catalog() -> None:
            if not catalog_rows: messagebox.showinfo("Каталог", "Сначала выполни сканирование.", parent=win); return
            path = filedialog.asksaveasfilename(parent=win, defaultextension=".csv", initialfile="FM2010_File_Encyclopedia.csv", filetypes=(("CSV", "*.csv"),))
            if not path: return
            with Path(path).open("w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f, delimiter=";"); w.writerow(("path","extension","type","signature","purpose","how_to_modify","recommended_tool","risk","confidence"))
                for p, info, size in catalog_rows:
                    w.writerow((str(p.relative_to(active_catalog_root[0])), p.suffix, info["type"], info["signature"], info["purpose"], info["edit"], info["tool"], info["risk"], info["confidence"]))
            log(f"Каталог экспортирован: {path}")
        ttk.Button(cbtn, text="Экспортировать полный справочник CSV", command=export_catalog).pack(side="left", padx=6)
        ttk.Button(cbtn, text="Открыть выбранный файл", command=lambda: reveal(Path(visible_rows[int(file_tree.selection()[0])][0])) if file_tree.selection() else None).pack(side="right")

        # AUDIT: large files, duplicates (hash only within size limit), suspicious extensions, empty files
        audit = tabs["audit"]
        ttk.Label(audit, text="Ищет тяжёлые файлы, пустые файлы, одинаковые копии и необычные расширения. Ничего не удаляет и не меняет.", wraplength=1350).pack(anchor="w", pady=(0, 8))
        audit_tree = ttk.Treeview(audit, columns=("kind","path","size","extra"), show="headings", height=18)
        for col,title,width in (("kind","Проверка",140),("path","Файл",610),("size","Размер",120),("extra","Детали",350)):
            audit_tree.heading(col,text=title); audit_tree.column(col,width=width,anchor="w")
        audit_tree.pack(fill="both",expand=True)
        audit_result = tk.StringVar(value="Аудит ещё не запускался.")
        ttk.Label(audit,textvariable=audit_result).pack(anchor="w",pady=5)
        def audit_run() -> None:
            audit_tree.delete(*audit_tree.get_children()); sizes=[]; hashes: dict[str,list[Path]]={}; empties=[]; unknown=[]; count=0; total=0
            for current,dirs,names in os.walk(game_root):
                dirs[:] = [d for d in dirs if d not in {".git","__pycache__","cache",".fm2010_backups"}]
                for name in names:
                    p=Path(current)/name
                    try:
                        if p.is_symlink(): continue
                        size=p.stat().st_size
                    except OSError: continue
                    count+=1; total+=size; sizes.append((size,p))
                    if size==0: empties.append(p)
                    if p.suffix.lower() not in FILE_KNOWLEDGE and not p.suffix: unknown.append(p)
                    if size<=MAX_HASH_BYTES and size>0:
                        try:
                            h=hashlib.sha256(p.read_bytes()).hexdigest(); hashes.setdefault(h,[]).append(p)
                        except OSError: pass
                    if count>=MAX_CATALOG_FILES: break
                if count>=MAX_CATALOG_FILES: break
            issues=0
            for size,p in sorted(sizes,reverse=True)[:30]:
                audit_tree.insert("","end",values=("Самый большой",str(p.relative_to(game_root)),_human_size(size),"Топ-30 по размеру"));issues+=1
            for p in empties[:100]: audit_tree.insert("","end",values=("Пустой файл",str(p.relative_to(game_root)),"0 Б","Не удалять автоматически"));issues+=1
            for group in hashes.values():
                if len(group)>1:
                    for p in group[1:4]: audit_tree.insert("","end",values=("Дубликат",str(p.relative_to(game_root)),_human_size(p.stat().st_size),f"Одинаковый SHA-256: {len(group)} копий"));issues+=1
            for p in unknown[:80]: audit_tree.insert("","end",values=("Без расширения",str(p.relative_to(game_root)),_human_size(p.stat().st_size),"Назначение проверь вручную"));issues+=1
            audit_result.set(f"Файлов: {count:,} | Объём: {total/1024/1024:,.1f} МБ | Показано наблюдений: {issues} | Хешируются только файлы до {MAX_HASH_BYTES//1024//1024} МБ")
            log("Глубокий аудит завершён")
        ttk.Button(audit,text="Запустить глубокий аудит",command=audit_run).pack(anchor="w",pady=6)

        # PROJECT WIZARD
        project = tabs["project"]
        ttk.Label(project,text="Создай чистую структуру мода без копирования оригинальных ресурсов игры.",wraplength=1350).pack(anchor="w",pady=(0,8))
        ppath_var=tk.StringVar(value=str(self.app_data_dir/"Projects"))
        pname_var=tk.StringVar(value="FM2010_My_Mod")
        pr=ttk.Frame(project);pr.pack(fill="x",pady=4)
        ttk.Label(pr,text="Папка:").pack(side="left");ttk.Entry(pr,textvariable=ppath_var).pack(side="left",fill="x",expand=True,padx=5)
        def pick_project_parent():
            p=filedialog.askdirectory(parent=win,title="Выбери папку для проекта")
            if p:ppath_var.set(p)
        ttk.Button(pr,text="Обзор…",command=pick_project_parent).pack(side="left")
        pr2=ttk.Frame(project);pr2.pack(fill="x",pady=4)
        ttk.Label(pr2,text="Название:").pack(side="left");ttk.Entry(pr2,textvariable=pname_var,width=45).pack(side="left",padx=5)
        proj_info=tk.Text(project,height=16,wrap="word");proj_info.pack(fill="both",expand=True,pady=8)
        structure=["editor_data","graphics/faces","graphics/logos","graphics/kits","graphics/backgrounds","config","database/notes","database/source_files","translations","audio","screenshots","build","docs","tests","tools"]
        proj_info.insert("1.0","Структура нового проекта:\n"+"\n".join("  /"+x for x in structure)+"\n\nБудут созданы README, metadata JSON, .gitignore и список источников. Оригинальные файлы игры не копируются.")
        def create_project() -> None:
            parent=Path(ppath_var.get()).expanduser(); name=pname_var.get().strip()
            if not re.fullmatch(r"[A-Za-z0-9_. -]{2,80}",name):messagebox.showerror("Проект","Название 2–80 символов: латиница, цифры, пробел, точка, _ или -.",parent=win);return
            folder=parent/name
            if folder.exists() and any(folder.iterdir()):messagebox.showerror("Проект","Папка уже существует и не пустая. Выбери другое имя.",parent=win);return
            try:
                folder.mkdir(parents=True,exist_ok=True)
                for item in structure:(folder/item).mkdir(parents=True,exist_ok=True)
                (folder/"FM2010_MOD_INFO.json").write_text(json.dumps({"name":name,"game":"Football Manager 2010","version":"0.1.0","created":dt.datetime.now().isoformat(timespec="seconds"),"description":"Опиши здесь свой мод","supported_patches":[],"authors":[],"sources":[],"files":[]},ensure_ascii=False,indent=2),encoding="utf-8")
                (folder/"README.md").write_text(f"# {name}\n\nМодификация для Football Manager 2010.\n\n## Что изменено\n\n- Заполни список изменённых файлов и их назначение.\n\n## Установка\n\n1. Сделай резервную копию игры.\n2. Установи только файлы этой модификации.\n3. Проверь версию игры и патч.\n\n## Источники и лицензии\n\nУкажи авторство каждого внешнего ресурса. Не распространяй оригинальные файлы игры.\n",encoding="utf-8")
                (folder/".gitignore").write_text("__pycache__/\n*.py[cod]\n*.tmp\n*.log\n*.bak\n*.sav\ncache/\ncrash dumps/\n",encoding="utf-8")
                (folder/"docs"/"FILE_CHANGELOG.csv").write_text("file;change;reason;source;tested_patch\n",encoding="utf-8-sig")
                ppath_var.set(str(parent));log(f"Создан проект: {folder}");messagebox.showinfo("Готово",f"Проект создан:\n{folder}",parent=win)
            except OSError as exc:messagebox.showerror("Создание проекта",str(exc),parent=win)
        ttk.Button(project,text="Создать структуру мода",command=create_project).pack(anchor="w",pady=4)

        # FM DATA EDITOR / EDITOR DATA
        editor=tabs["editor"]
        ttk.Label(editor,text="Помощник по редактору базы FM2010: ищет установленный editor.exe, показывает правильное место для изменений базы и помогает не перезаписать config.xml.",wraplength=1350).pack(anchor="w",pady=(0,8))
        editor_path=tk.StringVar(value="Редактор не найден")
        edd=ttk.Label(editor,textvariable=editor_path,wraplength=1350,padding=10,relief="groove");edd.pack(fill="x",pady=5)
        def find_editor() -> Path | None:
            candidates=[game_root/"tools"/"editor"/"editor.exe",game_root/"Tools"/"Editor"/"editor.exe"]
            for tools in (game_root/"tools",game_root/"Tools"):
                if tools.is_dir():
                    try:candidates.extend(tools.rglob("editor.exe"))
                    except OSError:pass
            for c in candidates:
                if c.is_file():return c
            return None
        def refresh_editor() -> None:
            exe=find_editor();editor_path.set(str(exe) if exe else "FM2010 Data Editor не найден в tools/editor. Проверь компоненты Steam/установки.")
        refresh_editor()
        ed_actions=ttk.Frame(editor);ed_actions.pack(fill="x",pady=5)
        def open_editor_data() -> None:
            candidates=[Path.home()/"Documents"/"Sports Interactive"/"Football Manager 2010"/"editor data",Path.home()/"Мои документы"/"Sports Interactive"/"Football Manager 2010"/"editor data"]
            folder=next((x for x in candidates if x.exists()),candidates[0])
            folder.mkdir(parents=True,exist_ok=True);reveal(folder)
            log(f"Открыта папка Editor Data: {folder}")
        def editor_howto() -> None:
            text=("FM2010 Data Editor — безопасный путь изменения основной базы:\n\n"
                  "1. Открой Data Editor и загрузи нужную базу данных.\n"
                  "2. Внеси изменения через поля редактора.\n"
                  "3. Выбери File → Save Editor Data As… и дай файлу уникальное имя.\n"
                  "4. Сохрани XML/DBC в Documents\\Sports Interactive\\Football Manager 2010\\editor data.\n"
                  "5. НЕ перезаписывай config.xml этой папки.\n"
                  "6. При создании новой карьеры выбери Editor Data Files и отметь нужные изменения.\n\n"
                  "Совместимость и доступные пункты меню сверяй с установленной версией редактора.")
            messagebox.showinfo("Рабочий процесс FM2010",text,parent=win)
        ttk.Button(ed_actions,text="Найти Data Editor",command=refresh_editor).pack(side="left")
        ttk.Button(ed_actions,text="Запустить Data Editor",command=lambda: subprocess.Popen([str(find_editor())],cwd=str(find_editor().parent)) if find_editor() else messagebox.showwarning("Редактор","Editor.exe не найден",parent=win)).pack(side="left",padx=5)
        ttk.Button(ed_actions,text="Открыть Editor Data",command=open_editor_data).pack(side="left",padx=5)
        ttk.Button(ed_actions,text="Инструкция по изменениям базы",command=editor_howto).pack(side="left",padx=5)
        ed_text=tk.Text(editor,height=15,wrap="word");ed_text.pack(fill="both",expand=True,pady=8)
        ed_text.insert("1.0","ВАЖНО: FM2010 использует отдельные editor data files, чтобы изменения базы не записывались напрямую в оригинальную базу. По историческим руководствам FM2010 после патча 10.2 редактор поддерживает сжатый формат .dbc наряду с .xml. Несколько отдельных файлов могут загружаться вместе, однако конфликтующие изменения правил лиг/национальных правил могут быть несовместимы.\n\nSuite не генерирует корректную базу самостоятельно: для структурных изменений используй Data Editor.")

        # COMPATIBILITY CHECKER / PRE-FLIGHT
        compat=tabs["compat"]
        ttk.Label(compat,text="Проверки перед установкой или распространением мода. Отчёт показывает обнаруженные признаки и ограничения; это не заменяет запуск игры и тест новой карьеры.",wraplength=1350).pack(anchor="w",pady=(0,8))
        compat_text=tk.Text(compat,wrap="word",height=20);compat_text.pack(fill="both",expand=True)
        def compatibility_scan() -> None:
            report=[f"FM2010 PRE-FLIGHT · {dt.datetime.now():%Y-%m-%d %H:%M:%S}",f"Папка игры: {game_root}",f"fm.exe: {'OK' if (game_root/'fm.exe').is_file() else 'не найден в корне'}"]
            for folder in ("data","tools","Data","Tools"):
                if (game_root/folder).is_dir():report.append(f"Папка {folder}: найдена")
            editor_data_candidates=[Path.home()/"Documents"/"Sports Interactive"/"Football Manager 2010"/"editor data",Path.home()/"Мои документы"/"Sports Interactive"/"Football Manager 2010"/"editor data"]
            eddata=next((p for p in editor_data_candidates if p.is_dir()),None)
            report.append(f"Папка пользовательских Editor Data: {eddata if eddata else 'не найдена (может быть создана при необходимости)'}")
            if eddata:
                for name in ("config.xml",):report.append(f"{name}: {'есть' if (eddata/name).is_file() else 'нет'}")
                for p in sorted(eddata.iterdir()):
                    if p.is_file() and p.suffix.lower() in {".xml",".dbc"}:report.append(f"  Editor Data: {p.name}")
            if not (game_root/"fm.exe").is_file():report.append("ВНИМАНИЕ: выбранная папка может быть не корнем установки; укажи папку с fm.exe.")
            report.extend(["","Рекомендации:","- Не перезаписывай оригинальную базу игры ради обычного editor-data мода.","- Проверяй моды на копии установки или отдельном профиле.","- Сверяй версию игры, патч и набор баз данных.","- Для Editor Data используй штатный Data Editor и уникальные имена файлов.","- Не публикуй exe/dll и исходные игровые ресурсы без прав на распространение."])
            compat_text.delete("1.0","end");compat_text.insert("1.0","\n".join(report));log("Pre-flight проверка завершена")
        def save_compat() -> None:
            out=filedialog.asksaveasfilename(parent=win,defaultextension=".txt",initialfile="FM2010_Preflight.txt")
            if out:Path(out).write_text(compat_text.get("1.0","end"),encoding="utf-8");log(f"Отчёт сохранён: {out}")
        cp=ttk.Frame(compat);cp.pack(fill="x",pady=6);ttk.Button(cp,text="Проверить совместимость",command=compatibility_scan).pack(side="left");ttk.Button(cp,text="Сохранить отчёт",command=save_compat).pack(side="left",padx=6)
        ttk.Label(win,text="Защита: Suite не хранит GitHub-токены, не публикует исходные игровые файлы намеренно и не пытается декомпилировать проприетарные форматы. Перед любыми изменениями делай backup.",foreground="#875000",wraplength=1400).pack(side="bottom",pady=(0,5))
        try:self.log("Открыта Global Workbench %s",VERSION_6)
        except Exception:pass


def _human_size(value: int) -> str:
    size=float(value)
    for unit in ("Б","КБ","МБ","ГБ","ТБ"):
        if size<1024 or unit=="ТБ":return f"{int(size)} {unit}" if unit=="Б" else f"{size:.1f} {unit}"
        size/=1024
    return str(value)
