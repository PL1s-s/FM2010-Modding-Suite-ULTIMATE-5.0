# -*- coding: utf-8 -*-
"""FM2010 Modding Suite RELEASE — additional workbench modules.

Standard-library-only tools for project creation, modpack handling, folder
comparison, batch renaming, text resource formatting, asset cataloguing,
launch profiles, diagnostics and backup recovery.
"""
from __future__ import annotations

import configparser
import csv
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import xml.etree.ElementTree as ET


RELEASE_VERSION = "4.0"
TEXT_LIMIT = 10 * 1024 * 1024
HASH_LIMIT = 256 * 1024 * 1024
MAX_SCAN_FILES = 250_000
MAX_ZIP_FILES = 50_000
MAX_ZIP_UNPACKED = 5 * 1024 * 1024 * 1024


def _format_bytes(size: int) -> str:
    value = float(max(0, size))
    for unit in ("Б", "КБ", "МБ", "ГБ", "ТБ"):
        if value < 1024 or unit == "ТБ":
            return f"{value:.1f} {unit}" if unit != "Б" else f"{int(value)} Б"
        value /= 1024
    return str(size)


def _is_child(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def _zip_target(root: Path, member: str) -> Path:
    """Validate an archive member before using it as a filesystem path."""
    if not member or "\x00" in member:
        raise ValueError("В архиве обнаружено пустое или некорректное имя пути.")
    win = PureWindowsPath(member)
    posix = PurePosixPath(member.replace("\\", "/"))
    if win.is_absolute() or win.drive or posix.is_absolute() or ".." in posix.parts:
        raise ValueError(f"Небезопасный путь в ZIP: {member}")
    target = (root / Path(*posix.parts)).resolve()
    if not _is_child(target, root):
        raise ValueError(f"Путь выходит за пределы папки назначения: {member}")
    return target


def _hash(path: Path, limit: int = HASH_LIMIT) -> str | None:
    try:
        if path.stat().st_size > limit:
            return None
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except OSError:
        return None


def _decode_text(raw: bytes) -> tuple[str, str, str]:
    if b"\x00" in raw:
        raise ValueError("Похоже, это бинарный файл; текстовые операции недоступны.")
    if raw.startswith(b"\xef\xbb\xbf"):
        encodings = ("utf-8-sig",)
    elif raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        encodings = ("utf-16",)
    else:
        encodings = ("utf-8", "cp1251", "cp1252", "latin-1")
    content = None
    encoding = ""
    last_error = None
    for candidate in encodings:
        try:
            content = raw.decode(candidate)
            encoding = candidate
            break
        except UnicodeDecodeError as exc:
            last_error = exc
    if content is None:
        raise ValueError(f"Не удалось определить кодировку: {last_error}")
    newline = "CRLF" if b"\r\n" in raw else ("CR" if b"\r" in raw and b"\n" not in raw else "LF")
    return content, encoding, newline


def _image_dimensions(path: Path) -> tuple[int, int] | None:
    """Read dimensions for common image formats without third-party packages."""
    try:
        with path.open("rb") as stream:
            data = stream.read(1024 * 1024)
        if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
            return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
        if data[:6] in (b"GIF87a", b"GIF89a") and len(data) >= 10:
            return int.from_bytes(data[6:8], "little"), int.from_bytes(data[8:10], "little")
        if data.startswith(b"BM") and len(data) >= 26:
            return abs(int.from_bytes(data[18:22], "little", signed=True)), abs(int.from_bytes(data[22:26], "little", signed=True))
        if data.startswith(b"\xff\xd8"):
            i = 2
            while i + 9 < len(data):
                if data[i] != 0xFF:
                    i += 1
                    continue
                marker = data[i + 1]
                i += 2
                if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
                    continue
                if i + 2 > len(data):
                    break
                length = int.from_bytes(data[i:i + 2], "big")
                if length < 2 or i + length > len(data):
                    break
                if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    return int.from_bytes(data[i + 5:i + 7], "big"), int.from_bytes(data[i + 3:i + 5], "big")
                i += length
    except OSError:
        return None
    return None


class ReleaseToolsMixin:
    """Mixin adding the v4.0 RELEASE workbench to the main FM2010 application."""

    def open_release_workbench(self) -> None:
        try:
            game_root = self._require_install_root()
        except Exception as exc:
            messagebox.showwarning("FM2010 RELEASE", str(exc), parent=self)
            return

        win = tk.Toplevel(self)
        win.title("FM2010 Modding Suite — RELEASE 4.0")
        win.geometry("1330x880")
        win.minsize(1050, 700)
        win.transient(self)
        header = ttk.Frame(win, padding=(14, 10))
        header.pack(fill="x")
        ttk.Label(header, text="FM2010 MODDING SUITE · RELEASE", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(header, text=f"Игровая папка: {game_root}", foreground="#555", wraplength=1250).pack(anchor="w", pady=(3, 0))
        nb = ttk.Notebook(win)
        nb.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        status = tk.StringVar(value="Готово. Выберите модуль.")
        ttk.Label(win, textvariable=status, relief="sunken", anchor="w", padding=6).pack(fill="x", side="bottom")

        overview = ttk.Frame(nb, padding=12)
        project = ttk.Frame(nb, padding=10)
        compare = ttk.Frame(nb, padding=10)
        rename = ttk.Frame(nb, padding=10)
        textlab = ttk.Frame(nb, padding=10)
        assets = ttk.Frame(nb, padding=10)
        launch = ttk.Frame(nb, padding=10)
        audit = ttk.Frame(nb, padding=10)
        vault = ttk.Frame(nb, padding=10)
        for frame, label in ((overview, "Старт"), (project, "Студия модов"), (compare, "Сравнение папок"),
                             (rename, "Пакетное переименование"), (textlab, "Лаборатория ресурсов"),
                             (assets, "Медиатека"), (launch, "Профили запуска"), (audit, "Аудит и журналы"),
                             (vault, "Хранилище копий")):
            nb.add(frame, text=label)

        # Shared helpers
        def files_under(path: Path, cap: int = MAX_SCAN_FILES) -> list[Path]:
            result: list[Path] = []
            for current, dirs, names in os.walk(path):
                dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", ".fm2010_backups"}]
                for name in names:
                    item = Path(current) / name
                    try:
                        if item.is_file() and not item.is_symlink():
                            result.append(item)
                    except OSError:
                        pass
                    if len(result) >= cap:
                        return result
            return result

        def backup_before(path: Path) -> Path | None:
            if not path.exists():
                return None
            backup = self._backup_file_before_save(path)
            if backup is None:
                raise OSError(f"Не удалось создать резервную копию: {path}")
            return backup

        def open_path(path: Path) -> None:
            try:
                if os.name == "nt":
                    os.startfile(str(path))  # type: ignore[attr-defined]
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", str(path)])
                else:
                    subprocess.Popen(["xdg-open", str(path)])
            except (OSError, AttributeError) as exc:
                messagebox.showerror("Открытие", str(exc), parent=win)

        # START / overview
        ttk.Label(overview, text="Единая мастерская для создания модов, анализа установки и обслуживания файлов.",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(2, 12))
        summary = tk.StringVar(value="Здесь появится сводка по игре и рабочим модулям.")
        ttk.Label(overview, textvariable=summary, justify="left", wraplength=1240, padding=12,
                  background="#f1f3f5").pack(fill="x", pady=(0, 12))
        shortcuts = ttk.Frame(overview)
        shortcuts.pack(fill="both", expand=True)
        shortcut_items = [
            ("Создать проект мода", project), ("Сравнить две папки", compare),
            ("Переименовать файлы пачкой", rename), ("Редактировать текстовый ресурс", textlab),
            ("Каталог графики и аудио", assets), ("Профили запуска игры", launch),
            ("Аудит установки и логи", audit), ("Резервные копии", vault),
        ]
        for i, (label, target) in enumerate(shortcut_items):
            ttk.Button(shortcuts, text=label, command=lambda t=target: nb.select(t)).grid(
                row=i // 2, column=i % 2, sticky="nsew", padx=5, pady=6, ipady=13)
        shortcuts.columnconfigure(0, weight=1)
        shortcuts.columnconfigure(1, weight=1)
        shortcuts.rowconfigure(0, weight=1)
        shortcuts.rowconfigure(1, weight=1)
        ttk.Label(overview, text="Принцип безопасности: изменения делаются через временный файл; перед перезаписью создаётся backup. "
                  "Неизвестные игровые бинарные форматы не преобразуются в вымышленные таблицы — для них доступны анализ, копирование и HEX-инструменты старой версии.",
                  foreground="#805000", wraplength=1240).pack(anchor="w", pady=(12, 0))

        def refresh_summary() -> None:
            try:
                all_files = files_under(game_root)
                total = sum(p.stat().st_size for p in all_files if p.exists())
                ext_counts: dict[str, int] = {}
                for p in all_files:
                    ext = p.suffix.lower() or "(без расширения)"
                    ext_counts[ext] = ext_counts.get(ext, 0) + 1
                top = sorted(ext_counts.items(), key=lambda x: x[1], reverse=True)[:8]
                exe = self.game_exe if getattr(self, "game_exe", None) and self.game_exe.exists() else None
                summary.set(f"Файлов: {len(all_files):,}   •   Объём: {_format_bytes(total)}   •   Типов: {len(ext_counts)}\n"
                            f"Запускатель: {exe or 'не обнаружен автоматически'}\n"
                            f"Частые типы: " + ", ".join(f"{ext}: {count}" for ext, count in top))
                status.set("Обзор обновлён")
            except OSError as exc:
                messagebox.showerror("Обзор", str(exc), parent=win)
        ttk.Button(overview, text="Обновить сводку", command=refresh_summary).pack(anchor="e", pady=(8, 0))

        # PROJECT STUDIO
        ttk.Label(project, text="Создавайте структуру мода, собирайте ZIP-пакеты и проверяйте их до установки.",
                  wraplength=1200).pack(anchor="w", pady=(0, 8))
        ptop = ttk.Frame(project); ptop.pack(fill="x", pady=5)
        project_name = tk.StringVar(value="My_FM2010_Mod")
        project_base = tk.StringVar(value=str(Path.home() / "Documents"))
        ttk.Label(ptop, text="Имя проекта:").grid(row=0, column=0, sticky="w")
        ttk.Entry(ptop, textvariable=project_name, width=32).grid(row=0, column=1, padx=5, sticky="ew")
        ttk.Label(ptop, text="Место создания:").grid(row=0, column=2, sticky="w")
        ttk.Entry(ptop, textvariable=project_base).grid(row=0, column=3, padx=5, sticky="ew")
        def browse_project_base() -> None:
            chosen = filedialog.askdirectory(parent=win, title="Где создать проект", initialdir=project_base.get() or str(Path.home()))
            if chosen: project_base.set(chosen)
        ttk.Button(ptop, text="Обзор…", command=browse_project_base).grid(row=0, column=4)
        ptop.columnconfigure(3, weight=1)
        project_path = tk.StringVar(value="Проект ещё не создан")
        ttk.Label(project, textvariable=project_path, foreground="#555", wraplength=1200).pack(anchor="w", pady=5)
        pbuttons = ttk.Frame(project); pbuttons.pack(fill="x", pady=6)

        def create_project() -> None:
            name = project_name.get().strip()
            if not name or name in {".", ".."} or any(x in name for x in '<>:"/\\|?*'):
                messagebox.showwarning("Проект", "Укажи допустимое имя папки проекта.", parent=win); return
            base = Path(project_base.get()).expanduser()
            target = (base / name).resolve()
            try:
                base.mkdir(parents=True, exist_ok=True)
                if target.exists() and any(target.iterdir()):
                    raise OSError("Папка с таким именем уже существует и не пуста. Выбери другое имя.")
                for sub in ("config", "database", "graphics", "logos", "kits", "faces", "backgrounds", "audio", "notes", "build", "backups"):
                    (target / sub).mkdir(parents=True, exist_ok=True)
                manifest = {"name": name, "game": "Football Manager 2010", "tool_version": RELEASE_VERSION,
                            "created": dt.datetime.now().isoformat(timespec="seconds"),
                            "description": "Опиши назначение мода здесь.", "version": "1.0.0", "author": "", "files": []}
                (target / "FM2010_MOD_PROJECT.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
                (target / "README.txt").write_text(f"{name}\n\nПроект мода для Football Manager 2010.\n\nПапки:\n- config: настройки и конфигурация\n- database: табличные и структурированные данные\n- graphics/logos/kits/faces/backgrounds: графика\n- audio: звук\n- notes: заметки и документация\n- build: собранные пакеты\n", encoding="utf-8")
                project_path.set(str(target)); status.set(f"Создан проект: {target}")
                messagebox.showinfo("Проект создан", f"Структура проекта создана:\n{target}", parent=win)
            except OSError as exc:
                messagebox.showerror("Создание проекта", str(exc), parent=win)
        def open_project_folder() -> None:
            p = Path(project_path.get())
            if p.is_dir(): open_path(p)
            else: messagebox.showinfo("Проект", "Сначала создай или выбери проект.", parent=win)
        def build_project_pack() -> None:
            folder = filedialog.askdirectory(parent=win, title="Выбери папку проекта мода")
            if not folder: return
            src = Path(folder).resolve()
            out = filedialog.asksaveasfilename(parent=win, title="Сохранить ZIP-мод", defaultextension=".zip",
                    initialfile=f"{src.name}_FM2010.zip", filetypes=(("ZIP", "*.zip"),))
            if not out: return
            out_path = Path(out).resolve()
            files = []
            for item in files_under(src):
                if item == out_path or any(part in {"__pycache__", ".git", "build"} for part in item.parts):
                    continue
                if item.suffix.lower() in {".tmp", ".pyc", ".bak"} or item.name.endswith("~"):
                    continue
                files.append(item)
            if len(files) > MAX_ZIP_FILES:
                messagebox.showerror("Сборка", f"Слишком много файлов: {len(files)}", parent=win); return
            try:
                manifest = {"mod_name": src.name, "game": "Football Manager 2010", "tool_version": RELEASE_VERSION,
                            "built": dt.datetime.now().isoformat(timespec="seconds"),
                            "file_count": len(files), "files": [str(p.relative_to(src)).replace("\\", "/") for p in files]}
                with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
                    z.writestr("FM2010_MODPACK.json", json.dumps(manifest, ensure_ascii=False, indent=2))
                    for p in files:
                        z.write(p, str(p.relative_to(src)).replace("\\", "/"))
                with zipfile.ZipFile(out_path) as z:
                    bad = z.testzip()
                    if bad: raise zipfile.BadZipFile(f"Ошибка проверки: {bad}")
                status.set(f"Собран ZIP: {out_path.name} ({len(files)} файлов)")
                messagebox.showinfo("Мод собран", f"Пакет готов:\n{out_path}\nФайлов: {len(files)}", parent=win)
            except (OSError, zipfile.BadZipFile) as exc:
                messagebox.showerror("Сборка мода", str(exc), parent=win)
        def inspect_pack() -> None:
            name = filedialog.askopenfilename(parent=win, title="Проверить ZIP-мод", filetypes=(("ZIP", "*.zip"),))
            if not name: return
            try:
                with zipfile.ZipFile(name) as z:
                    infos = z.infolist()
                    if len(infos) > MAX_ZIP_FILES: raise ValueError("В архиве слишком много файлов.")
                    total = 0
                    for info in infos:
                        if info.is_dir(): continue
                        _zip_target(Path(tempfile.gettempdir()) / "fm2010_zip_validation_root", info.filename)
                        total += info.file_size
                        if total > MAX_ZIP_UNPACKED: raise ValueError("Распакованный размер превышает 5 ГБ.")
                    bad = z.testzip()
                    if bad: raise zipfile.BadZipFile(f"Повреждён элемент: {bad}")
                messagebox.showinfo("Проверка ZIP", f"Архив прошёл проверку.\nФайлов/элементов: {len(infos)}\nРаспакованный размер: {_format_bytes(total)}", parent=win)
                status.set(f"ZIP проверен: {Path(name).name}")
            except (OSError, ValueError, zipfile.BadZipFile) as exc:
                messagebox.showerror("Проверка ZIP", str(exc), parent=win)
        def install_pack() -> None:
            name = filedialog.askopenfilename(parent=win, title="Установить ZIP-мод", filetypes=(("ZIP", "*.zip"),))
            if not name: return
            try:
                with zipfile.ZipFile(name) as z:
                    infos = [i for i in z.infolist() if not i.is_dir() and i.filename != "FM2010_MODPACK.json"]
                    if len(infos) > MAX_ZIP_FILES: raise ValueError("В архиве слишком много файлов.")
                    total = sum(i.file_size for i in infos)
                    if total > MAX_ZIP_UNPACKED: raise ValueError("Распакованный размер превышает лимит 5 ГБ.")
                    planned = [(_zip_target(game_root, i.filename), i) for i in infos]
                    normalized_targets = [str(target).casefold() for target, _info in planned]
                    if len(normalized_targets) != len(set(normalized_targets)):
                        raise ValueError("В ZIP обнаружены повторяющиеся пути (в Windows они могут перезаписывать друг друга).")
                    for target, info in planned:
                        if target.exists() and target.is_dir(): raise ValueError(f"Цель является папкой: {target}")
                    conflicts = [str(p.relative_to(game_root)) for p, _ in planned if p.exists()]
                    prompt = f"Будет установлено файлов: {len(planned)}\nЗамен существующих: {len(conflicts)}\n\nПеред заменой будут созданы резервные копии. Продолжить?"
                    if conflicts: prompt += "\n\n" + "\n".join(conflicts[:12])
                    if not messagebox.askyesno("Установка ZIP-мода", prompt, icon="warning", parent=win): return
                    bad = z.testzip()
                    if bad: raise zipfile.BadZipFile(f"Повреждён элемент: {bad}")
                    for target, _ in planned:
                        if target.exists(): backup_before(target)
                    for target, info in planned:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        fd, tmp_name = tempfile.mkstemp(prefix="fm2010_mod_", suffix=".tmp", dir=target.parent)
                        try:
                            with z.open(info) as source, os.fdopen(fd, "wb") as out:
                                shutil.copyfileobj(source, out, 1024 * 1024); out.flush(); os.fsync(out.fileno())
                            os.replace(tmp_name, target)
                        finally:
                            try: os.unlink(tmp_name)
                            except FileNotFoundError: pass
                status.set(f"Установлен мод: {Path(name).name}")
                messagebox.showinfo("Мод установлен", f"Файлов установлено: {len(planned)}\nРезервные копии заменённых файлов созданы.", parent=win)
            except (OSError, ValueError, zipfile.BadZipFile) as exc:
                messagebox.showerror("Установка ZIP-мода", str(exc), parent=win)
        for label, cb in (("Создать каркас проекта", create_project), ("Открыть папку проекта", open_project_folder),
                          ("Собрать ZIP из папки…", build_project_pack), ("Проверить ZIP…", inspect_pack),
                          ("Установить ZIP-мод…", install_pack)):
            ttk.Button(pbuttons, text=label, command=cb).pack(side="left", padx=(0, 5), pady=3)

        # FOLDER COMPARISON
        cbar = ttk.Frame(compare); cbar.pack(fill="x", pady=(0, 8))
        dir_a = tk.StringVar(value=str(game_root)); dir_b = tk.StringVar()
        ttk.Label(cbar, text="Папка A:").grid(row=0, column=0, sticky="w")
        ttk.Entry(cbar, textvariable=dir_a).grid(row=0, column=1, sticky="ew", padx=5)
        ttk.Button(cbar, text="Обзор…", command=lambda: self._release_choose_dir(dir_a, win)).grid(row=0, column=2)
        ttk.Label(cbar, text="Папка B:").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(cbar, textvariable=dir_b).grid(row=1, column=1, sticky="ew", padx=5)
        ttk.Button(cbar, text="Обзор…", command=lambda: self._release_choose_dir(dir_b, win)).grid(row=1, column=2)
        cbar.columnconfigure(1, weight=1)
        comp_tree = ttk.Treeview(compare, columns=("state", "size_a", "size_b", "note"), show="tree headings", height=20)
        comp_tree.heading("#0", text="Относительный путь"); comp_tree.heading("state", text="Статус")
        comp_tree.heading("size_a", text="Размер A"); comp_tree.heading("size_b", text="Размер B"); comp_tree.heading("note", text="Сравнение")
        comp_tree.column("#0", width=510); comp_tree.column("state", width=140); comp_tree.column("size_a", width=100); comp_tree.column("size_b", width=100); comp_tree.column("note", width=260)
        comp_tree.pack(fill="both", expand=True)
        comparison_rows: list[tuple[str, str, int, int, str]] = []
        def compare_folders() -> None:
            a = Path(dir_a.get()).expanduser(); b = Path(dir_b.get()).expanduser()
            if not a.is_dir() or not b.is_dir():
                messagebox.showwarning("Сравнение", "Выбери две существующие папки.", parent=win); return
            comp_tree.delete(*comp_tree.get_children()); comparison_rows.clear()
            map_a = {str(p.relative_to(a)).replace("\\", "/"): p for p in files_under(a)}
            map_b = {str(p.relative_to(b)).replace("\\", "/"): p for p in files_under(b)}
            keys = sorted(set(map_a) | set(map_b), key=str.casefold)
            for rel in keys:
                pa, pb = map_a.get(rel), map_b.get(rel)
                if pa is None:
                    state, sa, sb, note = "Только B", 0, pb.stat().st_size, "Есть только во второй папке"
                elif pb is None:
                    state, sa, sb, note = "Только A", pa.stat().st_size, 0, "Есть только в первой папке"
                else:
                    sa, sb = pa.stat().st_size, pb.stat().st_size
                    if sa != sb: state, note = "Изменён", f"Размер отличается: {sa} → {sb}"
                    else:
                        ha, hb = _hash(pa), _hash(pb)
                        if ha is not None and hb is not None:
                            state, note = ("Совпадает", "SHA-256 совпадает") if ha == hb else ("Изменён", "SHA-256 различается")
                        else:
                            state, note = ("Возможно совпадает", "Файлы больше лимита хеширования; совпадение не доказано")
                comparison_rows.append((rel, state, sa, sb, note))
                comp_tree.insert("", "end", text=rel, values=(state, _format_bytes(sa), _format_bytes(sb), note))
            counts: dict[str, int] = {}
            for row in comparison_rows: counts[row[1]] = counts.get(row[1], 0) + 1
            status.set("Сравнение: " + ", ".join(f"{k}: {v}" for k, v in counts.items()))
        def export_compare() -> None:
            if not comparison_rows: messagebox.showinfo("Экспорт", "Сначала сравни папки.", parent=win); return
            name = filedialog.asksaveasfilename(parent=win, defaultextension=".csv", initialfile="FM2010_folder_diff.csv", filetypes=(("CSV", "*.csv"),))
            if not name: return
            with Path(name).open("w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f, delimiter=";"); w.writerow(("path", "status", "size_a", "size_b", "details")); w.writerows(comparison_rows)
            status.set(f"Отчёт сравнения экспортирован: {name}")
        cbuttons = ttk.Frame(compare); cbuttons.pack(fill="x", pady=7)
        ttk.Button(cbuttons, text="Сравнить папки", command=compare_folders).pack(side="left")
        ttk.Button(cbuttons, text="Экспорт CSV", command=export_compare).pack(side="left", padx=6)

        # BATCH RENAME
        ttk.Label(rename, text="Переименование по правилам. Сначала построй предварительный список; изменения можно отменить последним манифестом.", wraplength=1200).pack(anchor="w", pady=(0, 8))
        rbar = ttk.Frame(rename); rbar.pack(fill="x", pady=3)
        filter_ext = tk.StringVar(value="*"); replace_from = tk.StringVar(); replace_to = tk.StringVar(); prefix = tk.StringVar(); suffix = tk.StringVar()
        for i, (label, variable, width) in enumerate((("Типы (* или .png,.xml):", filter_ext, 25), ("Заменить в имени:", replace_from, 22), ("На:", replace_to, 18), ("Префикс:", prefix, 16), ("Суффикс:", suffix, 16))):
            ttk.Label(rbar, text=label).grid(row=0, column=i*2, sticky="w")
            ttk.Entry(rbar, textvariable=variable, width=width).grid(row=0, column=i*2+1, padx=4, sticky="ew")
        rbar.columnconfigure(3, weight=1)
        rename_tree = ttk.Treeview(rename, columns=("new", "state"), show="tree headings", height=20, selectmode="extended")
        rename_tree.heading("#0", text="Текущее имя"); rename_tree.heading("new", text="Новое имя"); rename_tree.heading("state", text="Состояние")
        rename_tree.column("#0", width=480); rename_tree.column("new", width=480); rename_tree.column("state", width=200)
        rename_tree.pack(fill="both", expand=True)
        rename_plan: list[tuple[Path, Path]] = []
        rename_manifest_dir = Path(self.app_data_dir) / "rename_manifests"
        def preview_rename() -> None:
            rename_tree.delete(*rename_tree.get_children()); rename_plan.clear()
            ext_raw = filter_ext.get().strip()
            exts = {x.strip().casefold() if x.strip().startswith(".") else "." + x.strip().casefold() for x in ext_raw.split(",") if x.strip() and x.strip() != "*"}
            seen: set[Path] = set()
            for p in files_under(game_root):
                if ext_raw and ext_raw != "*" and p.suffix.casefold() not in exts: continue
                new_name = p.name
                if replace_from.get(): new_name = new_name.replace(replace_from.get(), replace_to.get())
                new_name = prefix.get() + new_name + suffix.get()
                target = p.with_name(new_name)
                if target == p: continue
                state_text = "Готово"
                if target.exists() and target not in {old for old, _ in rename_plan}:
                    state_text = "Конфликт: имя уже занято"
                if target in seen: state_text = "Конфликт: дубликат цели"
                seen.add(target)
                rename_tree.insert("", "end", text=str(p.relative_to(game_root)), values=(str(target.relative_to(game_root)), state_text))
                if state_text == "Готово": rename_plan.append((p, target))
            status.set(f"Предпросмотр переименования: {len(rename_plan)} готово; конфликтные строки помечены.")
        def apply_rename() -> None:
            if not rename_plan: messagebox.showinfo("Переименование", "Нет безопасных строк для применения.", parent=win); return
            if not messagebox.askyesno("Пакетное переименование", f"Переименовать {len(rename_plan)} файлов? Будет создан манифест отмены.", parent=win): return
            pairs = [(a, b) for a, b in rename_plan if a.exists() and _is_child(a, game_root) and _is_child(b, game_root)]
            if len(pairs) != len(rename_plan):
                messagebox.showerror("Переименование", "Состав файлов изменился после предпросмотра. Построй предпросмотр заново.", parent=win); return
            temps: list[tuple[Path, Path, Path]] = []
            try:
                for old, new in pairs:
                    temp = old.with_name(f".__fm2010_rename_{os.getpid()}_{len(temps)}.tmp")
                    if temp.exists(): raise OSError(f"Временное имя уже существует: {temp}")
                    old.rename(temp); temps.append((old, temp, new))
                for old, temp, new in temps:
                    if new.exists(): raise OSError(f"Целевое имя занято: {new}")
                    temp.rename(new)
                rename_manifest_dir.mkdir(parents=True, exist_ok=True)
                manifest = {"created": dt.datetime.now().isoformat(timespec="seconds"), "root": str(game_root),
                            "renames": [{"old": str(old), "new": str(new)} for old, _temp, new in temps]}
                mpath = rename_manifest_dir / f"rename_{dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.json"
                mpath.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
                status.set(f"Переименовано: {len(temps)}. Манифест отмены: {mpath.name}")
                preview_rename()
            except Exception as exc:
                # Best-effort rollback on partial failure.
                for old, temp, new in reversed(temps):
                    try:
                        if new.exists() and not old.exists(): new.rename(old)
                        elif temp.exists() and not old.exists(): temp.rename(old)
                    except OSError: pass
                messagebox.showerror("Переименование", f"Операция остановлена; выполнен откат где это было возможно.\n{exc}", parent=win)
        def undo_rename() -> None:
            manifests = sorted(rename_manifest_dir.glob("rename_*.json"), reverse=True) if rename_manifest_dir.exists() else []
            if not manifests: messagebox.showinfo("Отмена", "Манифесты переименования не найдены.", parent=win); return
            chosen = filedialog.askopenfilename(parent=win, title="Выбрать манифест отмены", initialdir=str(rename_manifest_dir), filetypes=(("JSON", "*.json"),))
            if not chosen: return
            try:
                m = json.loads(Path(chosen).read_text(encoding="utf-8"))
                if Path(m.get("root", "")).resolve() != game_root.resolve(): raise ValueError("Манифест создан для другой папки игры.")
                pairs = [(Path(x["new"]), Path(x["old"])) for x in m["renames"]]
                for new, old in pairs:
                    if not _is_child(new, game_root) or not _is_child(old, game_root) or not new.exists() or old.exists():
                        raise ValueError(f"Не удалось проверить пару: {new} → {old}")
                for new, old in pairs: new.rename(old)
                status.set(f"Отменено переименований: {len(pairs)}")
                preview_rename()
            except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
                messagebox.showerror("Отмена переименования", str(exc), parent=win)
        rbuttons = ttk.Frame(rename); rbuttons.pack(fill="x", pady=7)
        ttk.Button(rbuttons, text="Построить предпросмотр", command=preview_rename).pack(side="left")
        ttk.Button(rbuttons, text="Применить переименование", command=apply_rename).pack(side="left", padx=6)
        ttk.Button(rbuttons, text="Отменить по манифесту…", command=undo_rename).pack(side="left", padx=6)

        # TEXT RESOURCE LAB
        ttk.Label(textlab, text="Проверка, форматирование JSON/XML, конвертация кодировки и переносов строк. Сохранение всегда делает резервную копию.", wraplength=1200).pack(anchor="w", pady=(0, 7))
        tbar = ttk.Frame(textlab); tbar.pack(fill="x", pady=4)
        text_path = tk.StringVar(); text_info = tk.StringVar(value="Файл не выбран")
        ttk.Entry(tbar, textvariable=text_path).pack(side="left", fill="x", expand=True, padx=(0, 5))
        text_widget = tk.Text(textlab, wrap="none", undo=True, height=25, font=("Consolas", 10))
        yscroll = ttk.Scrollbar(textlab, orient="vertical", command=text_widget.yview); xscroll = ttk.Scrollbar(textlab, orient="horizontal", command=text_widget.xview)
        text_widget.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        text_widget.pack(fill="both", expand=True, side="top"); yscroll.pack(side="right", fill="y"); xscroll.pack(fill="x")
        ttk.Label(textlab, textvariable=text_info, foreground="#555").pack(anchor="w", pady=4)
        text_state: dict[str, str] = {"encoding": "utf-8", "newline": "LF"}
        def load_text_resource(path: Path | None = None) -> None:
            if path is None:
                name = filedialog.askopenfilename(parent=win, title="Открыть текстовый ресурс игры")
                if not name: return
                path = Path(name)
            try:
                if path.stat().st_size > TEXT_LIMIT: raise ValueError("Файл больше 10 МБ; открой его внешним редактором.")
                content, enc, nl = _decode_text(path.read_bytes())
                text_widget.delete("1.0", "end"); text_widget.insert("1.0", content)
                text_path.set(str(path)); text_state.update(encoding=enc, newline=nl)
                text_info.set(f"Кодировка: {enc} · Переносы: {nl} · Размер: {_format_bytes(path.stat().st_size)}")
                status.set(f"Открыт ресурс: {path.name}")
            except (OSError, ValueError) as exc: messagebox.showerror("Открытие ресурса", str(exc), parent=win)
        def current_text_path() -> Path:
            p = Path(text_path.get()).expanduser()
            if not p.is_file(): raise ValueError("Сначала выбери существующий файл.")
            if not _is_child(p, game_root): raise ValueError("Редактирование разрешено только внутри выбранной установки игры.")
            return p
        def validate_text_resource() -> None:
            try:
                p = current_text_path(); text = text_widget.get("1.0", "end-1c"); ext = p.suffix.lower()
                if ext == ".json": json.loads(text); message = "JSON корректен."
                elif ext in {".xml", ".svg", ".xhtml"}: ET.fromstring(text); message = "XML корректен."
                elif ext in {".ini", ".cfg", ".conf"}:
                    parser = configparser.ConfigParser(interpolation=None); parser.read_string(text or "\n"); message = f"INI прочитан: {len(parser.sections())} секций."
                elif ext == ".csv":
                    rows = list(csv.reader(text.splitlines())); message = f"CSV прочитан: {len(rows)} строк."
                else: message = "Общая проверка пройдена: текст прочитан без ошибок кодировки."
                status.set(message); messagebox.showinfo("Проверка ресурса", message, parent=win)
            except Exception as exc: messagebox.showerror("Проверка ресурса", str(exc), parent=win)
        def format_text_resource(kind: str) -> None:
            try:
                text = text_widget.get("1.0", "end-1c")
                if kind == "json-pretty": text = json.dumps(json.loads(text), ensure_ascii=False, indent=2) + "\n"
                elif kind == "json-min": text = json.dumps(json.loads(text), ensure_ascii=False, separators=(",", ":"))
                elif kind == "xml":
                    root_el = ET.fromstring(text); ET.indent(root_el, space="  "); text = ET.tostring(root_el, encoding="unicode", xml_declaration=False) + "\n"
                elif kind == "utf8": text_state["encoding"] = "utf-8"
                elif kind == "lf": text = text.replace("\r\n", "\n").replace("\r", "\n"); text_state["newline"] = "LF"
                elif kind == "crlf": text = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\r\n"); text_state["newline"] = "CRLF"
                text_widget.delete("1.0", "end"); text_widget.insert("1.0", text)
                status.set(f"Применено преобразование: {kind}. Не забудь сохранить файл.")
            except Exception as exc: messagebox.showerror("Преобразование", str(exc), parent=win)
        def save_text_resource() -> None:
            try:
                p = current_text_path(); text = text_widget.get("1.0", "end-1c")
                ext = p.suffix.lower()
                if ext == ".json": json.loads(text)
                if ext in {".xml", ".svg", ".xhtml"}: ET.fromstring(text)
                enc = text_state["encoding"]
                text = text.replace("\r\n", "\n").replace("\r", "\n")
                if text_state["newline"] == "CRLF": text = text.replace("\n", "\r\n")
                elif text_state["newline"] == "CR": text = text.replace("\n", "\r")
                payload = text.encode("utf-8" if enc == "utf-8-sig" else enc)
                backup = backup_before(p)
                if backup is None: raise OSError("Резервная копия не создана.")
                self.atomic_write_bytes(p, payload)
                text_info.set(f"Сохранено · кодировка: {enc} · backup: {backup.name}")
                status.set(f"Сохранено: {p.name}")
            except (OSError, ValueError, UnicodeEncodeError, ET.ParseError, json.JSONDecodeError) as exc:
                messagebox.showerror("Сохранение ресурса", str(exc), parent=win)
        tbuttons = ttk.Frame(textlab); tbuttons.pack(fill="x", pady=5)
        ttk.Button(tbar, text="Выбрать файл…", command=load_text_resource).pack(side="right")
        for label, cb in (("Проверить", validate_text_resource), ("JSON красиво", lambda: format_text_resource("json-pretty")),
                          ("JSON компактно", lambda: format_text_resource("json-min")), ("Форматировать XML", lambda: format_text_resource("xml")),
                          ("UTF-8", lambda: format_text_resource("utf8")), ("Переносы LF", lambda: format_text_resource("lf")),
                          ("Переносы CRLF", lambda: format_text_resource("crlf")), ("Сохранить + backup", save_text_resource)):
            ttk.Button(tbuttons, text=label, command=cb).pack(side="left", padx=(0, 4), pady=2)

        # ASSET LIBRARY
        ttk.Label(assets, text="Каталог графики, аудио, видео и шрифтов. Изображения читаются по метаданным; для полного предпросмотра открой внешний просмотрщик.", wraplength=1200).pack(anchor="w", pady=(0, 8))
        abar = ttk.Frame(assets); abar.pack(fill="x", pady=4)
        asset_query = tk.StringVar(); asset_ext = tk.StringVar(value=".png,.jpg,.jpeg,.bmp,.gif,.dds,.tga,.wav,.mp3,.ogg,.avi,.mp4,.ttf,.otf")
        ttk.Label(abar, text="Поиск имени:").pack(side="left"); ttk.Entry(abar, textvariable=asset_query, width=28).pack(side="left", padx=5)
        ttk.Label(abar, text="Расширения:").pack(side="left"); ttk.Entry(abar, textvariable=asset_ext, width=62).pack(side="left", padx=5)
        asset_tree = ttk.Treeview(assets, columns=("type", "size", "dimensions", "modified"), show="tree headings", selectmode="browse", height=21)
        for col, title, width in (("#0", "Файл", 560), ("type", "Категория", 160), ("size", "Размер", 110), ("dimensions", "Размер изображения", 160), ("modified", "Изменён", 150)):
            asset_tree.heading(col, text=title); asset_tree.column(col, width=width)
        asset_tree.pack(fill="both", expand=True)
        asset_paths: dict[str, Path] = {}
        def scan_assets() -> None:
            asset_tree.delete(*asset_tree.get_children()); asset_paths.clear()
            raw = asset_ext.get().strip(); exts = {x.strip().casefold() if x.strip().startswith(".") else "." + x.strip().casefold() for x in raw.split(",") if x.strip()}
            count = 0; query = asset_query.get().casefold()
            for p in files_under(game_root):
                if exts and p.suffix.casefold() not in exts: continue
                if query and query not in p.name.casefold(): continue
                try:
                    st = p.stat(); dims = _image_dimensions(p) if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp", ".gif"} else None
                    dim_text = f"{dims[0]} × {dims[1]}" if dims else "—"
                    iid = f"asset{count}"; asset_paths[iid] = p
                    asset_tree.insert("", "end", iid=iid, text=str(p.relative_to(game_root)),
                        values=(p.suffix.upper().lstrip(".") or "Файл", _format_bytes(st.st_size), dim_text, dt.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")))
                    count += 1
                except OSError: pass
            status.set(f"Медиатека: найдено {count} ресурсов")
        def open_selected_asset(_event=None) -> None:
            selected = asset_tree.selection()
            if selected and selected[0] in asset_paths: open_path(asset_paths[selected[0]])
        asset_tree.bind("<Double-1>", open_selected_asset)
        abuttons = ttk.Frame(assets); abuttons.pack(fill="x", pady=6)
        ttk.Button(abuttons, text="Сканировать медиатеку", command=scan_assets).pack(side="left")
        ttk.Button(abuttons, text="Открыть выбранный", command=open_selected_asset).pack(side="left", padx=6)
        ttk.Button(abuttons, text="Открыть папку выбранного", command=lambda: open_path(asset_paths[asset_tree.selection()[0]].parent) if asset_tree.selection() and asset_tree.selection()[0] in asset_paths else None).pack(side="left")
        ttk.Button(abuttons, text="Экспорт списка CSV", command=lambda: self._release_export_asset_csv(asset_paths, asset_tree, win)).pack(side="left", padx=6)
        ttk.Button(abuttons, text="Обновить фильтр", command=scan_assets).pack(side="right")

        # LAUNCH PROFILES
        ttk.Label(launch, text="Профили запуска сохраняют параметры командной строки и могут пригодиться для разных режимов запуска. Команда запускается без shell.", wraplength=1200).pack(anchor="w", pady=(0, 8))
        lp = ttk.Frame(launch); lp.pack(fill="x", pady=4)
        launch_name = tk.StringVar(value="Обычный запуск"); launch_args = tk.StringVar(); launch_exe = tk.StringVar(value=str(getattr(self, "game_exe", "") or ""))
        ttk.Label(lp, text="Имя профиля:").grid(row=0, column=0, sticky="w"); ttk.Entry(lp, textvariable=launch_name, width=24).grid(row=0, column=1, padx=5)
        ttk.Label(lp, text="Аргументы:").grid(row=0, column=2, sticky="w"); ttk.Entry(lp, textvariable=launch_args).grid(row=0, column=3, padx=5, sticky="ew")
        ttk.Label(lp, text="EXE:").grid(row=1, column=0, sticky="w", pady=4); ttk.Entry(lp, textvariable=launch_exe).grid(row=1, column=1, columnspan=3, sticky="ew", padx=5)
        lp.columnconfigure(3, weight=1)
        profile_file = Path(self.app_data_dir) / "launch_profiles.json"
        profile_list = ttk.Treeview(launch, columns=("args", "exe"), show="tree headings", height=18)
        profile_list.heading("#0", text="Профиль"); profile_list.heading("args", text="Аргументы"); profile_list.heading("exe", text="Исполняемый файл")
        profile_list.column("#0", width=190); profile_list.column("args", width=380); profile_list.column("exe", width=550)
        profile_list.pack(fill="both", expand=True, pady=5)
        def load_profiles() -> list[dict[str, str]]:
            try:
                data = json.loads(profile_file.read_text(encoding="utf-8"))
                return data if isinstance(data, list) else []
            except (OSError, json.JSONDecodeError): return []
        def save_profiles(data: list[dict[str, str]]) -> None:
            profile_file.parent.mkdir(parents=True, exist_ok=True)
            profile_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        def refresh_profiles() -> None:
            profile_list.delete(*profile_list.get_children())
            for i, item in enumerate(load_profiles()): profile_list.insert("", "end", iid=str(i), text=item.get("name", f"Профиль {i+1}"), values=(item.get("args", ""), item.get("exe", "")))
        def select_profile(_event=None) -> None:
            sel = profile_list.selection()
            if not sel: return
            items = load_profiles(); idx = int(sel[0])
            if idx < len(items):
                launch_name.set(items[idx].get("name", "")); launch_args.set(items[idx].get("args", "")); launch_exe.set(items[idx].get("exe", ""))
        def save_profile() -> None:
            name = launch_name.get().strip()
            if not name: messagebox.showwarning("Профиль", "Укажи название профиля.", parent=win); return
            items = load_profiles(); entry = {"name": name, "args": launch_args.get(), "exe": launch_exe.get().strip()}
            existing = next((i for i, x in enumerate(items) if x.get("name", "").casefold() == name.casefold()), None)
            if existing is None: items.append(entry)
            else: items[existing] = entry
            save_profiles(items); refresh_profiles(); status.set(f"Профиль сохранён: {name}")
        def delete_profile() -> None:
            sel = profile_list.selection()
            if not sel: return
            items = load_profiles(); idx = int(sel[0])
            if 0 <= idx < len(items):
                removed = items.pop(idx); save_profiles(items); refresh_profiles(); status.set(f"Удалён профиль: {removed.get('name', '')}")
        def launch_profile() -> None:
            exe = Path(launch_exe.get()).expanduser()
            if not exe.is_file(): messagebox.showerror("Запуск", "Укажи существующий EXE игры.", parent=win); return
            if not _is_child(exe, game_root): messagebox.showerror("Запуск", "EXE должен находиться внутри выбранной папки игры.", parent=win); return
            try:
                if os.name == "nt":
                    subprocess.Popen(f'"{exe}" {launch_args.get()}'.strip(), cwd=str(game_root), shell=False)
                else:
                    import shlex
                    subprocess.Popen([str(exe), *shlex.split(launch_args.get())], cwd=str(game_root), shell=False)
                status.set(f"Запущен профиль: {launch_name.get()}")
            except OSError as exc: messagebox.showerror("Запуск", str(exc), parent=win)
        lbuttons = ttk.Frame(launch); lbuttons.pack(fill="x", pady=6)
        ttk.Button(lbuttons, text="Сохранить профиль", command=save_profile).pack(side="left")
        ttk.Button(lbuttons, text="Удалить профиль", command=delete_profile).pack(side="left", padx=5)
        ttk.Button(lbuttons, text="Запустить выбранный", command=launch_profile).pack(side="left", padx=5)
        profile_list.bind("<<TreeviewSelect>>", select_profile)
        refresh_profiles()

        # AUDIT AND LOGS
        ttk.Label(audit, text="Глубокое сканирование файлов, отчёт о структуре и сбор ошибок/предупреждений из игровых журналов.", wraplength=1200).pack(anchor="w", pady=(0, 7))
        audit_output = tk.Text(audit, wrap="word", height=22, font=("Consolas", 9), state="disabled")
        audit_output.pack(fill="both", expand=True)
        def set_audit(text: str) -> None:
            audit_output.configure(state="normal"); audit_output.delete("1.0", "end"); audit_output.insert("1.0", text); audit_output.configure(state="disabled")
        def run_audit() -> None:
            records = files_under(game_root)
            total = sum(p.stat().st_size for p in records if p.exists())
            counts: dict[str, int] = {}; large = []; empty = []; denied = 0
            for p in records:
                try:
                    st = p.stat(); ext = p.suffix.lower() or "(без расширения)"; counts[ext] = counts.get(ext, 0) + 1
                    if st.st_size == 0: empty.append(p)
                    if st.st_size >= 250 * 1024 * 1024: large.append((st.st_size, p))
                except OSError: denied += 1
            lines = ["FM2010 RELEASE — INSTALLATION AUDIT", f"Дата: {dt.datetime.now().isoformat(timespec='seconds')}",
                     f"Путь: {game_root}", f"Файлов: {len(records)}", f"Общий размер: {_format_bytes(total)}", f"Пустых файлов: {len(empty)}", f"Недоступно: {denied}",
                     f"EXE: {getattr(self, 'game_exe', None)}", "", "РАСШИРЕНИЯ:"]
            lines.extend(f"{ext}: {count}" for ext, count in sorted(counts.items(), key=lambda x: x[1], reverse=True)[:40])
            lines.append("\nКРУПНЫЕ ФАЙЛЫ (от 250 МБ):")
            lines.extend(f"{_format_bytes(size)} — {p.relative_to(game_root)}" for size, p in sorted(large, reverse=True)[:60])
            lines.append("\nПУСТЫЕ ФАЙЛЫ:")
            lines.extend(str(p.relative_to(game_root)) for p in empty[:100])
            set_audit("\n".join(lines)); status.set(f"Аудит завершён: {len(records)} файлов")
        def scan_logs() -> None:
            log_files = [p for p in files_under(game_root) if p.suffix.lower() in {".log", ".err", ".out"}]
            try:
                app_log = Path(self.app_data_dir) / "fm_settings_tool.log"
                if app_log.is_file(): log_files.append(app_log)
            except Exception: pass
            lines = ["FM2010 LOG SCAN", f"Найдено журналов: {len(log_files)}", ""]
            patterns = re.compile(r"error|warning|failed|exception|traceback|ошибк|предупрежд", re.I)
            hits = 0
            for p in log_files:
                try:
                    content, _enc, _nl = _decode_text(p.read_bytes()[-2 * 1024 * 1024:])
                    matched = [line for line in content.splitlines() if patterns.search(line)]
                    if matched:
                        lines.append(f"\n[{p}]")
                        lines.extend(matched[-100:]); hits += len(matched)
                except (OSError, ValueError): continue
            if not hits: lines.append("Совпадений error/warning/failed/exception не найдено.")
            set_audit("\n".join(lines)); status.set(f"Анализ журналов: найдено строк-кандидатов {hits}")
        def export_audit() -> None:
            name = filedialog.asksaveasfilename(parent=win, title="Сохранить отчёт", defaultextension=".txt", initialfile="FM2010_release_audit.txt", filetypes=(("Текст", "*.txt"),))
            if name: Path(name).write_text(audit_output.get("1.0", "end-1c"), encoding="utf-8"); status.set(f"Отчёт сохранён: {name}")
        audit_buttons = ttk.Frame(audit); audit_buttons.pack(fill="x", pady=6)
        ttk.Button(audit_buttons, text="Полный аудит установки", command=run_audit).pack(side="left")
        ttk.Button(audit_buttons, text="Анализировать логи", command=scan_logs).pack(side="left", padx=5)
        ttk.Button(audit_buttons, text="Экспорт отчёта", command=export_audit).pack(side="left", padx=5)

        # BACKUP VAULT
        ttk.Label(vault, text="Все резервные копии файлов, созданные инструментами suite, отображаются здесь. Перед восстановлением текущий файл также сохраняется.", wraplength=1200).pack(anchor="w", pady=(0, 8))
        vault_tree = ttk.Treeview(vault, columns=("created", "original", "size"), show="tree headings", height=22)
        vault_tree.heading("#0", text="Резервная копия"); vault_tree.heading("created", text="Дата"); vault_tree.heading("original", text="Исходный файл"); vault_tree.heading("size", text="Размер")
        vault_tree.column("#0", width=300); vault_tree.column("created", width=160); vault_tree.column("original", width=600); vault_tree.column("size", width=110)
        vault_tree.pack(fill="both", expand=True)
        vault_items: dict[str, tuple[Path, Path]] = {}
        def refresh_vault() -> None:
            vault_tree.delete(*vault_tree.get_children()); vault_items.clear()
            backup_root = Path(self.app_data_dir) / "file_backups"
            if not backup_root.is_dir(): status.set("Хранилище пока пусто."); return
            count = 0
            for meta_path in sorted(backup_root.glob("*.backup.json"), reverse=True):
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8")); backup = Path(meta["backup_path"]).resolve(); original = Path(meta["original_path"]).resolve()
                    if not _is_child(backup, backup_root.resolve()) or not backup.is_file(): continue
                    iid = f"vault{count}"; vault_items[iid] = (backup, original)
                    st = backup.stat(); created = meta.get("created", "")
                    vault_tree.insert("", "end", iid=iid, text=backup.name, values=(created, str(original), _format_bytes(st.st_size))); count += 1
                except (OSError, KeyError, json.JSONDecodeError): continue
            status.set(f"Резервных копий в хранилище: {count}")
        def restore_vault() -> None:
            sel = vault_tree.selection()
            if not sel or sel[0] not in vault_items: messagebox.showinfo("Восстановление", "Выбери backup.", parent=win); return
            backup, original = vault_items[sel[0]]
            try:
                allowed_roots = [game_root]
                for candidate in (getattr(self, "game_dir", None), getattr(self, "preferences_dir", None)):
                    if candidate and Path(candidate).is_dir(): allowed_roots.append(Path(candidate).resolve())
                if not any(_is_child(original, allowed) for allowed in allowed_roots):
                    raise OSError("Исходный путь резервной копии не относится к папке игры или пользовательским данным FM2010.")
                if not backup.is_file(): raise OSError("Файл резервной копии отсутствует.")
                if not messagebox.askyesno("Восстановление", f"Восстановить файл?\n\n{original}\n\nТекущий файл (если есть) будет сохранён отдельно.", parent=win): return
                if original.exists(): backup_before(original)
                original.parent.mkdir(parents=True, exist_ok=True)
                self.atomic_copy_file(backup, original)
                status.set(f"Восстановлено: {original}")
                messagebox.showinfo("Восстановлено", f"Файл восстановлен:\n{original}", parent=win)
            except OSError as exc: messagebox.showerror("Восстановление", str(exc), parent=win)
        vbuttons = ttk.Frame(vault); vbuttons.pack(fill="x", pady=6)
        ttk.Button(vbuttons, text="Обновить список", command=refresh_vault).pack(side="left")
        ttk.Button(vbuttons, text="Восстановить выбранную копию", command=restore_vault).pack(side="left", padx=6)
        ttk.Button(vbuttons, text="Открыть хранилище", command=lambda: open_path(Path(self.app_data_dir) / "file_backups")).pack(side="right")

        refresh_summary()
        self.log("Открыта мастерская RELEASE %s", RELEASE_VERSION)

    @staticmethod
    def _release_choose_dir(variable: tk.StringVar, parent: tk.Misc) -> None:
        chosen = filedialog.askdirectory(parent=parent, title="Выбери папку для сравнения")
        if chosen: variable.set(chosen)

    @staticmethod
    def _release_export_asset_csv(asset_paths: dict[str, Path], tree: ttk.Treeview, parent: tk.Misc) -> None:
        selected_paths = list(asset_paths.values())
        if not selected_paths:
            messagebox.showinfo("Экспорт", "Сначала выполни сканирование медиатеки.", parent=parent); return
        name = filedialog.asksaveasfilename(parent=parent, defaultextension=".csv", initialfile="FM2010_assets.csv", filetypes=(("CSV", "*.csv"),))
        if not name: return
        with Path(name).open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";"); w.writerow(("path", "extension", "size_bytes"))
            for p in selected_paths:
                try: w.writerow((str(p), p.suffix.lower(), p.stat().st_size))
                except OSError: pass

