Put only confirmed text configuration resources here.
