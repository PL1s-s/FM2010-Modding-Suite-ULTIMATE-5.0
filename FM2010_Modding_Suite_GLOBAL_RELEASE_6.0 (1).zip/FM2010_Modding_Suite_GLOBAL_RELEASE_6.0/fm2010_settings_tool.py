#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Football Manager 2010 File Center — Windows desktop helper.

A cautious game-folder explorer, text editor, file replacer and backup utility.
Text formats can be edited in-app; any file type can be inspected, backed up,
opened externally or replaced with an explicit backup and confirmation.
"""
from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import json
import logging
import os
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import xml.etree.ElementTree as ET

try:
    import winreg  # type: ignore
except ImportError:  # pragma: no cover - Windows-only feature
    winreg = None

APP_TITLE = "FM 2010 — Modding Suite"
APP_VERSION = "6.0 GLOBAL RELEASE"
GAME_FOLDER_NAME = "Football Manager 2010"
PREFERENCES_NAME = "preferences"
CONFIG_NAME = "config.xml"
BACKUP_DIR_NAME = ".fm2010_backups"
LOG_NAME = "fm_settings_tool.log"
EDITABLE_EXTENSIONS = {
    ".xml", ".cfg", ".ini", ".txt", ".json", ".dat", ".log", ".csv", ".md",
    ".vdf", ".acf", ".sii", ".html", ".htm", ".css", ".js", ".lua",
    ".py", ".yml", ".yaml", ".toml", ".properties", ".tsv", ".sql",
    ".reg", ".inf", ".nfo", ".rtf", ".svg", ".po", ".pot", ".bat",
    ".cmd", ".ps1", ".vbs", ".sh", ".ini"
}
MAX_EDIT_SIZE = 10 * 1024 * 1024
PROTECTED_BINARY_EXTENSIONS = {".exe", ".dll", ".sys", ".com", ".scr", ".msi", ".ocx", ".drv", ".pyd"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tga", ".dds", ".webp", ".ico"}
AUDIO_EXTENSIONS = {".wav", ".mp3", ".ogg", ".flac", ".wma", ".mid", ".midi"}
VIDEO_EXTENSIONS = {".mp4", ".avi", ".wmv", ".mov", ".mkv", ".mpeg", ".mpg"}
ARCHIVE_EXTENSIONS = {".zip", ".7z", ".rar", ".pak", ".cab", ".7zip"}
FONT_EXTENSIONS = {".ttf", ".otf", ".fon"}


def classify_game_file(path: Path) -> str:
    """Return a human-readable file category based on its extension."""
    suffix = path.suffix.lower()
    if suffix in EDITABLE_EXTENSIONS:
        return "Текст / настройки"
    if suffix in IMAGE_EXTENSIONS:
        return "Изображение"
    if suffix in AUDIO_EXTENSIONS:
        return "Аудио"
    if suffix in VIDEO_EXTENSIONS:
        return "Видео"
    if suffix in ARCHIVE_EXTENSIONS:
        return "Архив / пакет"
    if suffix in FONT_EXTENSIONS:
        return "Шрифт"
    if suffix in PROTECTED_BINARY_EXTENSIONS:
        return "Исполняемый файл"
    return "Данные / неизвестный тип"


def format_file_size(size: int) -> str:
    value = float(size)
    for unit in ("Б", "КБ", "МБ", "ГБ", "ТБ"):
        if value < 1024 or unit == "ТБ":
            return f"{value:.1f} {unit}" if unit != "Б" else f"{int(value)} Б"
        value /= 1024
    return f"{size} Б"


def sha256_file(path: Path, max_bytes: int = 64 * 1024 * 1024) -> str | None:
    """Hash reasonably sized files; avoid freezing the UI on huge game assets."""
    try:
        if path.stat().st_size > max_bytes:
            return None
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except OSError:
        return None


class SettingsError(Exception):
    """An expected user-facing application error."""


def documents_candidates() -> list[Path]:
    """Return likely Windows Documents locations, without creating anything."""
    home = Path.home()
    candidates = [home / "Documents", home / "Мои документы"]
    for variable in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        value = os.environ.get(variable)
        if value:
            candidates.insert(0, Path(value) / "Documents")
    return list(dict.fromkeys(candidates))


def locate_game_data_folder() -> Path | None:
    for documents in documents_candidates():
        candidate = documents / "Sports Interactive" / GAME_FOLDER_NAME
        if candidate.is_dir():
            return candidate
    return None


def is_within(path: Path, directory: Path) -> bool:
    """Cross-version, resolved containment test."""
    try:
        path.resolve().relative_to(directory.resolve())
        return True
    except (ValueError, OSError):
        return False


def safe_member_path(root: Path, member: str) -> Path:
    """Resolve a ZIP member and reject absolute paths and traversal."""
    posix = PurePosixPath(member.replace("\\", "/"))
    windows = PureWindowsPath(member)
    if posix.is_absolute() or windows.is_absolute() or windows.drive:
        raise ValueError(f"Небезопасный путь в архиве: {member}")
    if ".." in posix.parts or ".." in windows.parts:
        raise ValueError(f"Небезопасный путь в архиве: {member}")
    target = (root / Path(*posix.parts)).resolve()
    root_resolved = root.resolve()
    if target != root_resolved and root_resolved not in target.parents:
        raise ValueError(f"Небезопасный путь в архиве: {member}")
    return target


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower().replace("-", "_")


def app_data_directory() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    if base:
        return Path(base) / "FM2010SettingsTool"
    return Path.home() / ".fm2010_settings_tool"


def _registry_steam_paths() -> list[Path]:
    found: list[Path] = []
    if winreg is None:
        return found
    keys = (
        (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Valve\Steam"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Valve\Steam"),
    )
    for hive, key_path in keys:
        try:
            with winreg.OpenKey(hive, key_path) as key:
                for value_name in ("SteamPath", "InstallPath"):
                    try:
                        value, _ = winreg.QueryValueEx(key, value_name)
                        if value:
                            candidate = Path(str(value))
                            if candidate.is_dir():
                                found.append(candidate)
                    except OSError:
                        pass
        except OSError:
            pass
    return found


def _registry_game_paths() -> list[Path]:
    found: list[Path] = []
    if winreg is None:
        return found
    uninstall_keys = (
        r"Software\Microsoft\Windows\CurrentVersion\Uninstall",
        r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
    )
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for base_key in uninstall_keys:
            try:
                with winreg.OpenKey(hive, base_key) as root_key:
                    count = winreg.QueryInfoKey(root_key)[0]
                    for index in range(count):
                        try:
                            sub_name = winreg.EnumKey(root_key, index)
                            with winreg.OpenKey(root_key, sub_name) as item:
                                display_name = ""
                                install_location = ""
                                display_icon = ""
                                for name, target in (("DisplayName", "display"), ("InstallLocation", "install"), ("DisplayIcon", "icon")):
                                    try:
                                        value, _ = winreg.QueryValueEx(item, name)
                                        if target == "display":
                                            display_name = str(value)
                                        elif target == "install":
                                            install_location = str(value)
                                        else:
                                            display_icon = str(value)
                                    except OSError:
                                        pass
                                if "football manager 2010" not in display_name.casefold():
                                    continue
                                if install_location:
                                    found.append(Path(install_location.strip('"')))
                                if display_icon:
                                    icon_path = display_icon.split(",", 1)[0].strip().strip('"')
                                    icon = Path(icon_path)
                                    if icon.suffix.lower() == ".exe":
                                        found.append(icon)
                        except OSError:
                            continue
            except OSError:
                continue
    return found


def steam_library_roots() -> list[Path]:
    roots = _registry_steam_paths()
    for variable in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"):
        value = os.environ.get(variable)
        if value:
            roots.append(Path(value) / "Steam")
    roots.extend((Path("C:/Program Files (x86)/Steam"), Path("C:/Program Files/Steam")))
    unique_roots: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        try:
            resolved = root.resolve()
            key = str(resolved).casefold()
            if resolved.is_dir() and key not in seen:
                seen.add(key)
                unique_roots.append(resolved)
        except OSError:
            continue

    libraries: list[Path] = []
    for root in unique_roots:
        libraries.append(root)
        vdf = root / "steamapps" / "libraryfolders.vdf"
        if not vdf.is_file():
            continue
        try:
            content = vdf.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        # Current Steam format uses "path"; older formats use numeric keys.
        candidates = re.findall(r'"path"\s*"([^"]+)"', content, flags=re.IGNORECASE)
        candidates += re.findall(r'^\s*"\d+"\s*"([A-Za-z]:\\[^"\r\n]+)"', content, flags=re.MULTILINE)
        for value in candidates:
            value = value.replace("\\\\", "\\")
            path = Path(value)
            if path.is_dir():
                libraries.append(path)
    deduped: list[Path] = []
    seen.clear()
    for path in libraries:
        key = str(path.resolve()).casefold()
        if key not in seen:
            seen.add(key)
            deduped.append(path)
    return deduped


def _find_game_executable(folder: Path) -> Path | None:
    if folder.is_file() and folder.suffix.lower() == ".exe":
        return folder
    if not folder.is_dir():
        return None
    wanted = {"fm.exe", "football manager 2010.exe"}
    try:
        # Prefer an executable directly in the game directory.
        for child in folder.iterdir():
            if child.is_file() and child.name.casefold() in wanted:
                return child
        # Some retail layouts put the executable one or two folders deeper.
        for current, dirs, files in os.walk(folder):
            current_path = Path(current)
            depth = len(current_path.relative_to(folder).parts)
            if depth >= 2:
                dirs[:] = []
            for filename in files:
                if filename.casefold() in wanted:
                    return current_path / filename
    except OSError:
        return None
    return None


def locate_game_executable(saved_path: Path | None = None) -> Path | None:
    """Find FM2010 through saved path, uninstall registry and Steam libraries."""
    candidates: list[Path] = []
    if saved_path:
        candidates.append(saved_path)
    candidates.extend(_registry_game_paths())
    for library in steam_library_roots():
        steamapps = library / "steamapps"
        common = steamapps / "common"
        manifest_dir = steamapps
        if common.is_dir():
            try:
                for folder in common.iterdir():
                    if folder.is_dir() and "football manager 2010" in folder.name.casefold():
                        candidates.append(folder)
            except OSError:
                pass
        if manifest_dir.is_dir():
            try:
                for manifest in manifest_dir.glob("appmanifest_*.acf"):
                    try:
                        manifest_text = manifest.read_text(encoding="utf-8", errors="replace")
                    except OSError:
                        continue
                    name = re.search(r'"name"\s*"([^"]+)"', manifest_text, flags=re.IGNORECASE)
                    install_dir = re.search(r'"installdir"\s*"([^"]+)"', manifest_text, flags=re.IGNORECASE)
                    if name and install_dir and "football manager 2010" in name.group(1).casefold():
                        candidates.append(common / install_dir.group(1))
            except OSError:
                pass
    for variable in ("ProgramFiles", "ProgramFiles(x86)", "ProgramW6432"):
        value = os.environ.get(variable)
        if value:
            base = Path(value)
            candidates.append(base / "Sports Interactive" / GAME_FOLDER_NAME)
            candidates.append(base / GAME_FOLDER_NAME)
    for extra in (
        Path("C:/Games") / GAME_FOLDER_NAME,
        Path("D:/Games") / GAME_FOLDER_NAME,
        Path("C:/Sports Interactive") / GAME_FOLDER_NAME,
        Path("D:/Sports Interactive") / GAME_FOLDER_NAME,
    ):
        candidates.append(extra)

    seen: set[str] = set()
    for candidate in candidates:
        try:
            key = str(candidate.resolve()).casefold()
            if key in seen:
                continue
            seen.add(key)
            result = _find_game_executable(candidate)
            if result and result.is_file():
                return result.resolve()
        except OSError:
            continue
    return None


from fm2010_release_tools import ReleaseToolsMixin
from fm2010_advanced_tools import AdvancedToolsMixin
from fm2010_release6_tools import Release6Mixin


class FMTool(Release6Mixin, AdvancedToolsMixin, ReleaseToolsMixin, tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_TITLE} v{APP_VERSION}")
        self.geometry("1180x790")
        self.minsize(980, 680)
        self.option_add("*Font", ("Segoe UI", 10))
        self.option_add("*TButton.Font", ("Segoe UI", 10, "bold"))

        self.app_data_dir = app_data_directory()
        self.app_data_dir.mkdir(parents=True, exist_ok=True)
        self.settings_file = self.app_data_dir / "settings.json"
        self.saved_settings = self._load_settings()

        self.game_dir: Path | None = self._valid_saved_path("data_folder") or locate_game_data_folder()
        self.preferences_dir: Path | None = self.game_dir / PREFERENCES_NAME if self.game_dir else None
        saved_exe = self._valid_saved_path("game_exe")
        self.game_exe: Path | None = saved_exe if saved_exe and saved_exe.is_file() else locate_game_executable()
        saved_install = self._valid_saved_path("install_dir")
        self.install_dir: Path | None = saved_install if saved_install and saved_install.is_dir() else (self.game_exe.parent if self.game_exe else None)

        self.logger = logging.getLogger("fm2010_settings_tool")
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False
        self._set_log_file()

        self.selected_file: Path | None = None
        self.language_var = tk.StringVar(value="ru")
        self.save_path_var = tk.StringVar()
        self.animations_var = tk.BooleanVar(value=False)
        self.language_enabled_var = tk.BooleanVar(value=False)
        self.save_path_enabled_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="Готово")
        self.path_var = tk.StringVar(value="Папка пользовательских данных не найдена")
        self.install_path_var = tk.StringVar(value="Путь к установленной игре пока не определён")
        self.selected_file_var = tk.StringVar(value="Файл для редактирования не выбран")

        self._build_ui()
        self.update_path_labels()
        self.log("Приложение запущено — GLOBAL RELEASE 6.0")

    def _load_settings(self) -> dict:
        try:
            data = json.loads(self.settings_file.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def _valid_saved_path(self, key: str) -> Path | None:
        value = self.saved_settings.get(key)
        if not isinstance(value, str) or not value.strip():
            return None
        try:
            path = Path(value).expanduser()
            return path if path.exists() else None
        except OSError:
            return None

    def _save_settings(self) -> None:
        try:
            self.app_data_dir.mkdir(parents=True, exist_ok=True)
            data = {
                "data_folder": str(self.game_dir) if self.game_dir else "",
                "game_exe": str(self.game_exe) if self.game_exe else "",
                "install_dir": str(self.install_dir) if self.install_dir else "",
            }
            self.settings_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError as exc:
            self.log("Не удалось сохранить параметры приложения: %s", exc, level=logging.WARNING)

    def _set_log_file(self) -> None:
        target_dir = self.game_dir if self.game_dir and self.game_dir.is_dir() else self.app_data_dir
        try:
            target_dir.mkdir(parents=True, exist_ok=True)
            log_path = target_dir / LOG_NAME
            for handler in list(self.logger.handlers):
                self.logger.removeHandler(handler)
                handler.close()
            handler = logging.FileHandler(log_path, encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
            self.logger.addHandler(handler)
        except OSError:
            # The on-screen log still works when the target directory is read-only.
            pass

    def _build_ui(self) -> None:
        header = ttk.Frame(self, padding=(16, 12, 16, 6))
        header.pack(fill="x")
        ttk.Label(header, text=APP_TITLE, font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(header, textvariable=self.path_var, foreground="#444", wraplength=1120).pack(anchor="w", pady=(5, 0))
        ttk.Label(header, textvariable=self.install_path_var, foreground="#555", wraplength=1120).pack(anchor="w", pady=(3, 0))

        toolbar = ttk.Frame(self, padding=(16, 4, 16, 10))
        toolbar.pack(fill="x")
        actions = [
            ("Выбрать папку игры → файлы", self.select_game_install_folder),
            ("Открыть файловый центр", self.open_game_file_manager),
            ("Показать путь к игре", self.show_game_path),
            ("Запустить игру", self.launch_game),
            ("Открыть папку игры", self.open_install_folder),
            ("Выбрать папку данных", self.select_data_folder),
            ("Открыть preferences", self.open_preferences),
            ("Список файлов preferences", self.show_file_list),
            ("Выбрать и изменить файл", self.choose_and_edit_file),
            ("Backup настроек", self.create_backup),
            ("Восстановить backup", self.restore_backup),
            ("Восстановить файл", self.restore_file_backup),
            ("Пересканировать пути", self.detect_paths),
            ("КЛАССИЧЕСКИЕ ИНСТРУМЕНТЫ PRO", self.open_modding_suite),
            ("FM2010 RELEASE WORKBENCH 4.0", self.open_release_workbench),
            ("ULTIMATE WORKBENCH 5.0 · 12 НОВЫХ ИНСТРУМЕНТОВ", self.open_advanced_workbench),
            ("GLOBAL WORKBENCH 6.0 · GITHUB + СПРАВОЧНИК ФАЙЛОВ", self.open_global_workbench),
        ]
        for index, (label, command) in enumerate(actions):
            row, column = divmod(index, 4)
            ttk.Button(toolbar, text=label, command=command).grid(
                row=row, column=column, sticky="ew", padx=4, pady=4, ipadx=5, ipady=6
            )
        for column in range(4):
            toolbar.columnconfigure(column, weight=1)

        body = ttk.PanedWindow(self, orient="horizontal")
        body.pack(fill="both", expand=True, padx=16, pady=(0, 10))
        presets = ttk.LabelFrame(body, text="Быстрые настройки", padding=14)
        info = ttk.LabelFrame(body, text="Журнал работы", padding=10)
        body.add(presets, weight=1)
        body.add(info, weight=1)

        ttk.Label(
            presets,
            text="Выберите папку установки — откроется полный список файлов игры.\n"
                 "Текстовые файлы можно редактировать внутри программы; любые файлы можно просматривать, резервировать и заменять.",
            wraplength=420, foreground="#444",
        ).pack(anchor="w", pady=(0, 12))

        ttk.Checkbutton(presets, text="Отключить анимации (если параметр есть)", variable=self.animations_var).pack(anchor="w", pady=6)
        language_row = ttk.Frame(presets)
        language_row.pack(fill="x", pady=6)
        ttk.Checkbutton(language_row, text="Изменить язык:", variable=self.language_enabled_var).pack(side="left")
        ttk.Combobox(language_row, textvariable=self.language_var, values=("ru", "en"), state="readonly", width=7).pack(side="left", padx=8)

        ttk.Checkbutton(presets, text="Изменить путь к сохранениям", variable=self.save_path_enabled_var).pack(anchor="w", pady=6)
        save_row = ttk.Frame(presets)
        save_row.pack(fill="x", pady=(0, 8))
        ttk.Entry(save_row, textvariable=self.save_path_var).pack(side="left", fill="x", expand=True)
        ttk.Button(save_row, text="Обзор…", command=self.choose_save_path).pack(side="left", padx=(6, 0))

        ttk.Button(presets, text="Применить выбранные настройки", command=self.apply_presets).pack(fill="x", ipady=9, pady=(10, 0))
        ttk.Separator(presets).pack(fill="x", pady=16)
        ttk.Label(presets, text="Выбранный файл:", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ttk.Label(presets, textvariable=self.selected_file_var, wraplength=420, foreground="#555").pack(anchor="w", pady=(4, 0))
        ttk.Label(
            presets,
            text="Важно: бинарные файлы можно резервировать и заменять из файлового центра. Встроенный редактор предназначен для текстовых форматов.",
            wraplength=420, foreground="#7a4b00",
        ).pack(anchor="w", pady=(18, 0))

        self.log_text = tk.Text(info, wrap="word", state="disabled", height=20, background="#fafafa", font=("Consolas", 10))
        self.log_text.pack(fill="both", expand=True)
        log_buttons = ttk.Frame(info)
        log_buttons.pack(fill="x", pady=(8, 0))
        ttk.Button(log_buttons, text="Очистить журнал", command=self.clear_log).pack(side="left")
        ttk.Button(log_buttons, text="Открыть папку резервных копий", command=self.open_backup_folder).pack(side="right")

        ttk.Label(self, textvariable=self.status_var, relief="sunken", anchor="w", padding=6).pack(fill="x", side="bottom")

    def update_path_labels(self) -> None:
        if self.game_dir:
            pref_status = "найдена" if self.preferences_dir and self.preferences_dir.is_dir() else "не найдена"
            self.path_var.set(f"Папка данных: {self.game_dir}  |  preferences: {pref_status}")
        else:
            self.path_var.set("Папка данных: не найдена — выберите её вручную")
        install_text = f"Папка установки: {self.install_dir}" if self.install_dir else "Папка установки: не выбрана"
        exe_text = f"fm.exe: {self.game_exe}" if self.game_exe else "fm.exe: не найден (можно указать вручную)"
        self.install_path_var.set(f"{install_text}  |  {exe_text}")

    def detect_paths(self) -> None:
        data_folder = self._valid_saved_path("data_folder") or locate_game_data_folder()
        self.game_dir = data_folder if data_folder and data_folder.is_dir() else None
        self.preferences_dir = self.game_dir / PREFERENCES_NAME if self.game_dir else None
        saved_exe = self._valid_saved_path("game_exe")
        if saved_exe and saved_exe.is_file():
            self.game_exe = saved_exe
        else:
            self.game_exe = locate_game_executable()
        saved_install = self._valid_saved_path("install_dir")
        self.install_dir = saved_install if saved_install and saved_install.is_dir() else (self.game_exe.parent if self.game_exe else None)
        self._set_log_file()
        self.update_path_labels()
        self.status_var.set("Поиск завершён")
        self.log("Пути обновлены: данные=%s; игра=%s", self.game_dir or "не найдены", self.game_exe or "не найдена")
        self._save_settings()

    def log(self, message: str, *args: object, level: int = logging.INFO) -> None:
        rendered = message % args if args else message
        self.logger.log(level, rendered)
        if hasattr(self, "log_text"):
            self.log_text.configure(state="normal")
            self.log_text.insert("end", f"{dt.datetime.now():%H:%M:%S}  {rendered}\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")

    def clear_log(self) -> None:
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")
        self.log("Журнал очищен")

    def require_preferences(self) -> Path:
        if not self.preferences_dir or not self.preferences_dir.is_dir():
            raise SettingsError("Папка preferences не найдена. Запустите игру один раз или выберите папку данных вручную.")
        return self.preferences_dir

    def select_data_folder(self) -> None:
        selected = filedialog.askdirectory(title="Выберите папку Football Manager 2010 или preferences")
        if not selected:
            return
        chosen = Path(selected).resolve()
        if chosen.name.casefold() == PREFERENCES_NAME.casefold():
            data_folder = chosen.parent
            preferences = chosen
        else:
            data_folder = chosen
            preferences = data_folder / PREFERENCES_NAME
        if not preferences.is_dir():
            messagebox.showerror(
                "Папка данных",
                "В выбранной папке не найдена подпапка preferences.\n"
                "Выберите папку Football Manager 2010 из Документов или саму папку preferences.",
            )
            return
        self.game_dir = data_folder
        self.preferences_dir = preferences
        self._set_log_file()
        self._save_settings()
        self.update_path_labels()
        self.status_var.set("Папка пользовательских данных установлена")
        self.log("Выбрана папка данных: %s", data_folder)

    def select_game_install_folder(self) -> None:
        selected = filedialog.askdirectory(title="Выберите корневую папку установки Football Manager 2010")
        if not selected:
            return
        root = Path(selected).resolve()
        if not root.is_dir():
            messagebox.showerror("Папка игры", "Выбранный путь не является папкой.")
            return
        self.install_dir = root
        found = _find_game_executable(root)
        self.game_exe = found.resolve() if found else None
        self._save_settings()
        self.update_path_labels()
        self.status_var.set("Папка установки выбрана — открывается файловый центр")
        self.log("Выбрана папка установки игры: %s", root)
        if not found:
            messagebox.showwarning(
                "Папка выбрана",
                "Папка сохранена, но fm.exe внутри неё не найден. Просматривать и редактировать файлы всё равно можно.",
                parent=self,
            )
        self.open_game_file_manager(root)

    def backup_dir(self) -> Path:
        if not self.game_dir:
            raise SettingsError("Сначала выберите папку пользовательских данных.")
        path = self.game_dir / BACKUP_DIR_NAME
        path.mkdir(parents=True, exist_ok=True)
        return path

    def create_backup(self, quiet: bool = False) -> Path | None:
        try:
            preferences = self.require_preferences()
            destination_dir = self.backup_dir()
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            destination = destination_dir / f"preferences_{timestamp}.zip"
            counter = 1
            while destination.exists():
                destination = destination_dir / f"preferences_{timestamp}_{counter}.zip"
                counter += 1
            files = [item for item in preferences.rglob("*") if item.is_file()]
            with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
                for file_path in files:
                    archive.write(file_path, file_path.relative_to(preferences).as_posix())
            self.log("Создана резервная копия: %s (%d файлов)", destination, len(files))
            self.status_var.set(f"Backup создан: {destination.name}")
            if not quiet:
                messagebox.showinfo("Backup", f"Резервная копия создана.\n\n{destination}")
            return destination
        except (OSError, SettingsError, zipfile.BadZipFile) as exc:
            self.log("Ошибка создания backup: %s", exc, level=logging.ERROR)
            if not quiet:
                messagebox.showerror("Ошибка backup", str(exc))
            return None

    def open_backup_folder(self) -> None:
        try:
            if self.game_dir:
                folder = self.backup_dir()
            else:
                folder = self.app_data_dir / "file_backups"
                folder.mkdir(parents=True, exist_ok=True)
            os.startfile(str(folder))  # type: ignore[attr-defined]
            self.log("Открыта папка резервных копий: %s", folder)
        except (OSError, SettingsError) as exc:
            messagebox.showerror("Резервные копии", str(exc))

    def open_preferences(self) -> None:
        try:
            path = self.require_preferences()
            os.startfile(str(path))  # type: ignore[attr-defined]
            self.log("Открыта папка preferences")
        except (OSError, SettingsError) as exc:
            self.log("Не удалось открыть preferences: %s", exc, level=logging.ERROR)
            messagebox.showerror("Ошибка", str(exc))

    def open_install_folder(self) -> None:
        if not self.install_dir or not self.install_dir.is_dir():
            self.show_game_path()
            return
        try:
            os.startfile(str(self.install_dir))  # type: ignore[attr-defined]
            self.log("Открыта папка установленной игры: %s", self.install_dir)
        except OSError as exc:
            messagebox.showerror("Папка игры", str(exc))

    def launch_game(self) -> None:
        if not self.game_exe or not self.game_exe.is_file():
            found = _find_game_executable(self.install_dir) if self.install_dir and self.install_dir.is_dir() else locate_game_executable()
            if found:
                self.game_exe = found.resolve()
                self.install_dir = self.game_exe.parent
                self._save_settings()
                self.update_path_labels()
        if not self.game_exe or not self.game_exe.is_file():
            messagebox.showwarning("Запуск игры", "fm.exe не найден. Сначала укажите путь к исполняемому файлу игры.", parent=self)
            self.show_game_path()
            return
        try:
            os.startfile(str(self.game_exe))  # type: ignore[attr-defined]
            self.log("Запущена Football Manager 2010: %s", self.game_exe)
            self.status_var.set("Команда запуска игры отправлена")
        except (OSError, AttributeError) as exc:
            messagebox.showerror("Запуск игры", str(exc), parent=self)

    def show_game_path(self) -> None:
        window = tk.Toplevel(self)
        window.title("Путь к Football Manager 2010")
        window.geometry("760x220")
        window.minsize(620, 200)
        window.transient(self)
        frame = ttk.Frame(window, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Путь к исполняемому файлу Football Manager 2010:", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        value = tk.StringVar(value=str(self.game_exe) if self.game_exe else "Игра автоматически не найдена")
        entry = ttk.Entry(frame, textvariable=value, state="readonly")
        entry.pack(fill="x", pady=(8, 12))
        ttk.Label(frame, text="Папка установки: " + (str(self.install_dir) if self.install_dir else "не определена"), wraplength=700).pack(anchor="w", pady=(0, 12))
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x")

        def refresh() -> None:
            found = locate_game_executable()
            if found:
                self.game_exe = found
                self.install_dir = found.parent
                self._save_settings()
                self.update_path_labels()
                value.set(str(found))
                self.status_var.set("Путь к игре найден")
                self.log("Найден исполняемый файл игры: %s", found)
            else:
                value.set("Игра не найдена автоматически — укажите fm.exe вручную")
                messagebox.showinfo("Поиск игры", "Автоматический поиск не нашёл fm.exe. Нажмите «Выбрать файл игры» и укажите его вручную.", parent=window)

        def choose_exe() -> None:
            selected = filedialog.askopenfilename(
                parent=window,
                title="Выберите исполняемый файл Football Manager 2010",
                filetypes=(("Исполняемый файл", "*.exe"), ("Все файлы", "*.*")),
            )
            if not selected:
                return
            chosen = Path(selected).resolve()
            if not chosen.is_file() or chosen.suffix.lower() != ".exe":
                messagebox.showerror("Путь к игре", "Нужно выбрать существующий EXE-файл.", parent=window)
                return
            self.game_exe = chosen
            self.install_dir = chosen.parent
            self._save_settings()
            self.update_path_labels()
            value.set(str(chosen))
            self.status_var.set("Путь к игре сохранён")
            self.log("Путь к игре указан вручную: %s", chosen)

        def copy_path() -> None:
            if self.game_exe:
                self.clipboard_clear()
                self.clipboard_append(str(self.game_exe))
                self.status_var.set("Путь к игре скопирован")
                self.log("Путь к игре скопирован в буфер обмена")
            else:
                messagebox.showwarning("Путь к игре", "Сначала найдите игру или выберите fm.exe.", parent=window)

        def open_folder() -> None:
            if self.install_dir and self.install_dir.is_dir():
                try:
                    os.startfile(str(self.install_dir))  # type: ignore[attr-defined]
                except OSError as exc:
                    messagebox.showerror("Папка игры", str(exc), parent=window)
            else:
                messagebox.showwarning("Путь к игре", "Папка установки не определена.", parent=window)

        ttk.Button(buttons, text="Скопировать путь", command=copy_path).pack(side="left", padx=(0, 6))
        ttk.Button(buttons, text="Открыть папку", command=open_folder).pack(side="left", padx=6)
        ttk.Button(buttons, text="Выбрать файл игры…", command=choose_exe).pack(side="left", padx=6)
        ttk.Button(buttons, text="Найти автоматически", command=refresh).pack(side="right")

    def config_path(self) -> Path:
        return self.require_preferences() / CONFIG_NAME

    def validate_config(self) -> None:
        try:
            path = self.config_path()
            ET.parse(path)
            self.status_var.set("config.xml: проверка пройдена")
            self.log("XML корректен: %s", path)
            messagebox.showinfo("Проверка config.xml", "Файл config.xml существует и содержит корректный XML.")
        except FileNotFoundError:
            messagebox.showerror("Проверка config.xml", "Файл config.xml не найден в папке preferences.")
        except (OSError, ET.ParseError, SettingsError) as exc:
            self.log("Ошибка проверки config.xml: %s", exc, level=logging.ERROR)
            messagebox.showerror("Проверка config.xml", f"Файл не прошёл проверку:\n\n{exc}")

    def open_editor(self) -> None:
        try:
            path = self.config_path()
            if not path.is_file():
                raise SettingsError(f"Файл не найден: {path}")
            self.open_file_editor(path)
        except (OSError, SettingsError) as exc:
            self.log("Не удалось открыть config.xml: %s", exc, level=logging.ERROR)
            messagebox.showerror("Редактор", str(exc))

    def choose_and_edit_file(self) -> None:
        initial = self.preferences_dir if self.preferences_dir and self.preferences_dir.is_dir() else (self.game_dir or Path.home())
        selected = filedialog.askopenfilename(
            title="Выберите файл настроек для редактирования",
            initialdir=str(initial),
            filetypes=(
                ("Файлы настроек и текста", "*.xml *.cfg *.ini *.txt *.json *.dat *.log *.csv *.md"),
                ("Все файлы", "*.*"),
            ),
        )
        if not selected:
            return
        self.open_file_editor(Path(selected).resolve())

    def _read_editable_file(self, path: Path) -> tuple[str, str, str]:
        if path.suffix.lower() in PROTECTED_BINARY_EXTENSIONS:
            raise SettingsError("Это исполняемый или бинарный компонент игры. Его можно просматривать, резервировать и заменять через файловый центр, но не редактировать как текст.")
        if path.suffix.lower() not in EDITABLE_EXTENSIONS:
            raise SettingsError("Формат не входит в список текстовых форматов. Используйте просмотр, открытие внешней программой или замену файла с резервной копией.")
        size = path.stat().st_size
        if size > MAX_EDIT_SIZE:
            raise SettingsError(f"Файл слишком большой для встроенного редактора (лимит {MAX_EDIT_SIZE // (1024 * 1024)} МБ).")
        raw = path.read_bytes()
        if b"\x00" in raw:
            raise SettingsError("Похоже, это бинарный файл. Он не будет открыт в текстовом редакторе.")
        control_bytes = sum(1 for byte in raw if byte < 9 or 13 < byte < 32)
        if raw and control_bytes / len(raw) > 0.03:
            raise SettingsError("Файл содержит слишком много управляющих байтов и, вероятно, является бинарным. Используйте HEX-просмотр или замену с backup.")
        newline = "\r\n" if b"\r\n" in raw else "\n"
        if raw.startswith(b"\xef\xbb\xbf"):
            encoding = "utf-8-sig"
        else:
            try:
                raw.decode("utf-8")
                encoding = "utf-8"
            except UnicodeDecodeError:
                encoding = "cp1251"
        try:
            content = raw.decode(encoding)
        except UnicodeDecodeError as exc:
            raise SettingsError(f"Не удалось определить кодировку файла: {exc}") from exc
        return content, encoding, newline

    def _backup_file_before_save(self, path: Path) -> Path | None:
        if not path.exists():
            return None
        if self.preferences_dir and self.preferences_dir.is_dir() and is_within(path, self.preferences_dir):
            return self.create_backup(quiet=True)
        backup_root = self.app_data_dir / "file_backups"
        backup_root.mkdir(parents=True, exist_ok=True)
        timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        token = hashlib.sha256(str(path.resolve()).casefold().encode("utf-8", errors="replace")).hexdigest()[:10]
        backup_path = backup_root / f"{path.stem}_{token}_{timestamp}{path.suffix}.bak"
        shutil.copy2(path, backup_path)
        metadata = {
            "original_path": str(path.resolve()),
            "backup_path": str(backup_path.resolve()),
            "created": dt.datetime.now().isoformat(timespec="seconds"),
        }
        backup_path.with_suffix(backup_path.suffix + ".backup.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return backup_path

    @staticmethod
    def atomic_write_bytes(path: Path, payload: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix="fm2010_", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

    def open_file_editor(self, path: Path) -> None:
        try:
            content, encoding, newline = self._read_editable_file(path)
        except (OSError, SettingsError) as exc:
            self.log("Не удалось открыть файл %s: %s", path, exc, level=logging.ERROR)
            messagebox.showerror("Редактор", f"Не удалось открыть файл:\n{exc}")
            return

        self.selected_file = path
        self.selected_file_var.set(str(path))
        self.status_var.set(f"Открыт файл: {path.name}")
        self.log("Открыт редактор файла: %s", path)

        window = tk.Toplevel(self)
        window.title(f"Редактор — {path.name}")
        window.geometry("1050x740")
        window.minsize(780, 520)
        window.transient(self)

        search_frame = ttk.Frame(window, padding=(10, 10, 10, 4))
        search_frame.pack(fill="x")
        ttk.Label(search_frame, text="Найти:").pack(side="left")
        find_var = tk.StringVar()
        find_entry = ttk.Entry(search_frame, textvariable=find_var, width=28)
        find_entry.pack(side="left", padx=(6, 12))
        ttk.Label(search_frame, text="Заменить на:").pack(side="left")
        replace_var = tk.StringVar()
        ttk.Entry(search_frame, textvariable=replace_var, width=28).pack(side="left", padx=6)

        editor_frame = ttk.Frame(window)
        editor_frame.pack(fill="both", expand=True, padx=10, pady=6)
        editor = tk.Text(editor_frame, wrap="none", undo=True, maxundo=-1, font=("Consolas", 11), tabs=(4,))
        y_scroll = ttk.Scrollbar(editor_frame, orient="vertical", command=editor.yview)
        x_scroll = ttk.Scrollbar(editor_frame, orient="horizontal", command=editor.xview)
        editor.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
        editor.grid(row=0, column=0, sticky="nsew")
        y_scroll.grid(row=0, column=1, sticky="ns")
        x_scroll.grid(row=1, column=0, sticky="ew")
        editor_frame.rowconfigure(0, weight=1)
        editor_frame.columnconfigure(0, weight=1)
        editor.insert("1.0", content)
        editor.edit_modified(False)
        editor.tag_configure("search_hit", background="#ffe58a")

        def find_next() -> None:
            needle = find_var.get()
            if not needle:
                return
            start = editor.index("insert")
            found = editor.search(needle, start, stopindex="end", nocase=False)
            if not found:
                found = editor.search(needle, "1.0", stopindex=start, nocase=False)
            editor.tag_remove("search_hit", "1.0", "end")
            if found:
                end = f"{found}+{len(needle)}c"
                editor.tag_add("search_hit", found, end)
                editor.mark_set("insert", end)
                editor.see(found)
                editor.focus_set()
            else:
                messagebox.showinfo("Поиск", "Совпадений больше нет.", parent=window)

        def replace_all() -> None:
            old = find_var.get()
            if not old:
                messagebox.showwarning("Замена", "Введите текст для поиска.", parent=window)
                return
            current = editor.get("1.0", "end-1c")
            count = current.count(old)
            if not count:
                messagebox.showinfo("Замена", "Совпадений не найдено.", parent=window)
                return
            if not messagebox.askyesno("Подтверждение", f"Будет заменено совпадений: {count}. Продолжить?", parent=window):
                return
            updated = current.replace(old, replace_var.get())
            editor.edit_separator()
            editor.delete("1.0", "end")
            editor.insert("1.0", updated)
            editor.edit_separator()
            self.status_var.set(f"Заменено: {count}")
            self.log("В файле %s выполнена замена (%d раз)", path.name, count)

        ttk.Button(search_frame, text="Найти далее", command=find_next).pack(side="left", padx=4)
        ttk.Button(search_frame, text="Заменить всё", command=replace_all).pack(side="left", padx=4)
        find_entry.bind("<Return>", lambda _event: find_next())

        def focus_search(_event: object) -> str:
            find_entry.focus_set()
            return "break"

        def save_shortcut(_event: object) -> str:
            save()
            return "break"

        def select_all_shortcut(_event: object) -> str:
            editor.tag_add("sel", "1.0", "end-1c")
            return "break"

        window.bind("<Control-f>", focus_search)
        window.bind("<Control-s>", save_shortcut)
        window.bind("<Control-a>", select_all_shortcut)

        bottom = ttk.Frame(window, padding=(10, 4, 10, 10))
        bottom.pack(fill="x")
        ttk.Label(bottom, text=f"{path}  |  Кодировка: {encoding}", wraplength=630).pack(side="left")

        def validate_content(new_content: str, suffix: str | None = None) -> None:
            suffix = (suffix or path.suffix).lower()
            if suffix == ".xml":
                try:
                    ET.fromstring(new_content)
                except ET.ParseError as exc:
                    raise SettingsError(f"Некорректный XML. Исправьте файл перед сохранением.\n\n{exc}") from exc
            elif suffix == ".json":
                try:
                    json.loads(new_content)
                except json.JSONDecodeError as exc:
                    raise SettingsError(f"Некорректный JSON. Исправьте файл перед сохранением.\n\n{exc}") from exc

        def save() -> None:
            nonlocal content
            new_content = editor.get("1.0", "end-1c")
            try:
                validate_content(new_content)
            except SettingsError as exc:
                messagebox.showerror("Проверка файла", str(exc), parent=window)
                return
            if new_content == content:
                messagebox.showinfo("Редактор", "Изменений нет — файл не перезаписывался.", parent=window)
                return
            if not messagebox.askyesno("Сохранение", "Создать резервную копию и сохранить изменения?", parent=window):
                return
            try:
                backup = self._backup_file_before_save(path)
                if path.exists() and backup is None:
                    raise SettingsError("Не удалось создать backup — файл не изменён.")
                normalized = new_content.replace("\r\n", "\n").replace("\r", "\n")
                if newline == "\r\n":
                    normalized = normalized.replace("\n", "\r\n")
                payload = normalized.encode(encoding)
                self.atomic_write_bytes(path, payload)
                content = new_content
                self.log("Сохранён файл: %s; backup: %s", path, backup or "новый файл")
                self.status_var.set(f"Сохранён файл: {path.name}")
                messagebox.showinfo("Редактор", "Файл сохранён. Резервная копия создана.", parent=window)
            except (OSError, UnicodeEncodeError, SettingsError) as exc:
                self.log("Ошибка сохранения %s: %s", path, exc, level=logging.ERROR)
                messagebox.showerror("Ошибка сохранения", str(exc), parent=window)

        def save_as() -> None:
            destination = filedialog.asksaveasfilename(
                parent=window,
                title="Сохранить копию файла",
                initialdir=str(path.parent),
                initialfile=path.name,
                defaultextension=path.suffix,
                filetypes=(("Текущий тип файла", f"*{path.suffix}"), ("Все файлы", "*.*")),
            )
            if not destination:
                return
            target = Path(destination).resolve()
            try:
                if target.suffix.lower() in PROTECTED_BINARY_EXTENSIONS:
                    raise SettingsError("Нельзя сохранять текстовый документ под именем исполняемого файла.")
                validate_content(editor.get("1.0", "end-1c"), target.suffix)
                if target.exists():
                    if not messagebox.askyesno("Перезапись", f"Файл уже существует:\n{target}\n\nСоздать backup и перезаписать?", parent=window):
                        return
                    target_backup = self._backup_file_before_save(target)
                    if target_backup is None:
                        raise SettingsError("Не удалось создать backup целевого файла.")
                new_content = editor.get("1.0", "end-1c").replace("\r\n", "\n").replace("\r", "\n")
                if newline == "\r\n":
                    new_content = new_content.replace("\n", "\r\n")
                self.atomic_write_bytes(target, new_content.encode(encoding))
                self.log("Сохранена копия файла: %s", target)
                self.status_var.set(f"Копия сохранена: {target.name}")
                messagebox.showinfo("Сохранить как", f"Копия сохранена:\n{target}", parent=window)
            except (OSError, UnicodeEncodeError, SettingsError) as exc:
                messagebox.showerror("Сохранить как", str(exc), parent=window)

        def open_parent() -> None:
            try:
                os.startfile(str(path.parent))  # type: ignore[attr-defined]
            except OSError as exc:
                messagebox.showerror("Папка файла", str(exc), parent=window)

        ttk.Button(bottom, text="Открыть папку", command=open_parent).pack(side="right", padx=4)
        ttk.Button(bottom, text="Сохранить как…", command=save_as).pack(side="right", padx=4)
        ttk.Button(bottom, text="Сохранить", command=save).pack(side="right", padx=4)
        ttk.Button(bottom, text="Закрыть", command=window.destroy).pack(side="right", padx=4)

    def show_file_list(self) -> None:
        try:
            preferences = self.require_preferences()
        except SettingsError as exc:
            messagebox.showerror("Список файлов", str(exc))
            return
        window = tk.Toplevel(self)
        window.title("Файлы настроек FM 2010")
        window.geometry("820x560")
        window.transient(self)
        top = ttk.Frame(window, padding=10)
        top.pack(fill="x")
        ttk.Label(top, text="Фильтр:").pack(side="left")
        filter_var = tk.StringVar()
        search = ttk.Entry(top, textvariable=filter_var)
        search.pack(side="left", fill="x", expand=True, padx=8)
        tree = ttk.Treeview(window, columns=("size", "modified"), show="tree headings")
        tree.heading("#0", text="Файл")
        tree.heading("size", text="Размер")
        tree.heading("modified", text="Изменён")
        tree.column("#0", width=430)
        tree.column("size", width=110, anchor="e")
        tree.column("modified", width=180)
        tree.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        files: list[Path] = []
        try:
            files = sorted((p for p in preferences.rglob("*") if p.is_file()), key=lambda p: str(p).casefold())
        except OSError as exc:
            messagebox.showerror("Список файлов", str(exc), parent=window)
            window.destroy()
            return

        def populate(*_args: object) -> None:
            needle = filter_var.get().casefold().strip()
            tree.delete(*tree.get_children())
            for item in files:
                relative = item.relative_to(preferences)
                if needle and needle not in str(relative).casefold():
                    continue
                try:
                    stat = item.stat()
                    size = f"{stat.st_size:,} Б".replace(",", " ")
                    modified = dt.datetime.fromtimestamp(stat.st_mtime).strftime("%d.%m.%Y %H:%M")
                except OSError:
                    size, modified = "—", "—"
                tree.insert("", "end", iid=str(item), text=str(relative), values=(size, modified))

        def edit_selected(_event: object = None) -> None:
            selection = tree.selection()
            if selection:
                self.open_file_editor(Path(selection[0]))

        def open_file_location() -> None:
            selection = tree.selection()
            if not selection:
                return
            try:
                os.startfile(str(Path(selection[0]).parent))  # type: ignore[attr-defined]
            except OSError as exc:
                messagebox.showerror("Папка файла", str(exc), parent=window)

        filter_var.trace_add("write", populate)
        tree.bind("<Double-1>", edit_selected)
        populate()
        bottom = ttk.Frame(window, padding=(10, 0, 10, 10))
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Редактировать", command=edit_selected).pack(side="right", padx=4)
        ttk.Button(bottom, text="Открыть папку файла", command=open_file_location).pack(side="right", padx=4)
        ttk.Label(bottom, text=f"Файлов найдено: {len(files)}").pack(side="left")

    def open_game_file_manager(self, root: Path | None = None) -> None:
        """Open a full game installation browser with safe file operations."""
        root = root or self.install_dir
        if not root or not root.is_dir():
            messagebox.showinfo(
                "Файловый центр",
                "Сначала нажмите «Выбрать папку игры → файлы» и укажите папку установки Football Manager 2010.",
                parent=self,
            )
            return
        root = root.resolve()
        self.install_dir = root
        self._save_settings()

        window = tk.Toplevel(self)
        window.title(f"Файловый центр — {root.name}")
        window.geometry("1320x820")
        window.minsize(1050, 680)
        window.transient(self)

        header = ttk.Frame(window, padding=(12, 10, 12, 6))
        header.pack(fill="x")
        ttk.Label(header, text="Папка игры:", font=("Segoe UI", 10, "bold")).pack(side="left")
        root_var = tk.StringVar(value=str(root))
        ttk.Entry(header, textvariable=root_var, state="readonly").pack(side="left", fill="x", expand=True, padx=8)

        toolbar = ttk.Frame(window, padding=(10, 2, 10, 8))
        toolbar.pack(fill="x")
        search_var = tk.StringVar()
        category_var = tk.StringVar(value="Все файлы")
        ttk.Label(toolbar, text="Поиск:").pack(side="left")
        search_entry = ttk.Entry(toolbar, textvariable=search_var, width=24)
        search_entry.pack(side="left", padx=(5, 12))
        ttk.Label(toolbar, text="Категория:").pack(side="left")
        categories = (
            "Все файлы", "Текст / настройки", "Изображение", "Аудио", "Видео",
            "Архив / пакет", "Исполняемый файл", "Шрифт", "Данные / неизвестный тип",
        )
        category_box = ttk.Combobox(toolbar, textvariable=category_var, values=categories, state="readonly", width=25)
        category_box.pack(side="left", padx=5)
        global_search_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(toolbar, text="По всей игре", variable=global_search_var, command=lambda: populate_files(current_folder)).pack(side="left", padx=5)
        ttk.Button(toolbar, text="Пересканировать", command=lambda: scan_root()).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Отчёт CSV", command=lambda: export_inventory()).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Запустить игру", command=lambda: self.launch_game()).pack(side="left", padx=4)
        ttk.Button(toolbar, text="Сменить папку", command=lambda: choose_another_root()).pack(side="left", padx=4)

        pane = ttk.PanedWindow(window, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        left = ttk.LabelFrame(pane, text="Папки игры", padding=6)
        right = ttk.LabelFrame(pane, text="Файлы выбранной папки", padding=6)
        pane.add(left, weight=1)
        pane.add(right, weight=4)

        folder_tree = ttk.Treeview(left, show="tree", selectmode="browse")
        folder_scroll = ttk.Scrollbar(left, orient="vertical", command=folder_tree.yview)
        folder_tree.configure(yscrollcommand=folder_scroll.set)
        folder_tree.pack(side="left", fill="both", expand=True)
        folder_scroll.pack(side="right", fill="y")

        file_tree = ttk.Treeview(
            right,
            columns=("category", "size", "modified"),
            show="tree headings",
            selectmode="extended",
        )
        file_tree.heading("#0", text="Имя файла")
        file_tree.heading("category", text="Тип")
        file_tree.heading("size", text="Размер")
        file_tree.heading("modified", text="Изменён")
        file_tree.column("#0", width=420, minwidth=220)
        file_tree.column("category", width=165, minwidth=120)
        file_tree.column("size", width=105, anchor="e")
        file_tree.column("modified", width=145)
        file_scroll = ttk.Scrollbar(right, orient="vertical", command=file_tree.yview)
        file_tree.configure(yscrollcommand=file_scroll.set)
        file_tree.pack(side="left", fill="both", expand=True)
        file_scroll.pack(side="right", fill="y")

        details = tk.Text(window, height=5, wrap="word", state="disabled", background="#f6f7f9", font=("Consolas", 9))
        details.pack(fill="x", padx=12, pady=(0, 8))
        footer = ttk.Frame(window, padding=(10, 0, 10, 10))
        footer.pack(fill="x")
        count_var = tk.StringVar(value="Сканирование ещё не выполнено")
        ttk.Label(footer, textvariable=count_var).pack(side="left")

        folder_paths: dict[str, Path] = {}
        file_paths: dict[str, Path] = {}
        current_folder = root
        all_files: list[Path] = []
        folder_counter = 0
        dummy_prefix = "__lazy_folder__"

        def set_details(value: str) -> None:
            details.configure(state="normal")
            details.delete("1.0", "end")
            details.insert("1.0", value)
            details.configure(state="disabled")

        def add_folder_node(parent_id: str, path: Path) -> None:
            nonlocal folder_counter
            try:
                child_dirs = sorted(
                    (item for item in path.iterdir() if item.is_dir() and not item.is_symlink()),
                    key=lambda item: item.name.casefold(),
                )
            except (OSError, PermissionError):
                child_dirs = []
            for child in child_dirs:
                folder_counter += 1
                node_id = f"folder:{folder_counter}"
                folder_paths[node_id] = child
                folder_tree.insert(parent_id, "end", iid=node_id, text=child.name, open=False)
                try:
                    has_subfolder = any(item.is_dir() and not item.is_symlink() for item in child.iterdir())
                except OSError:
                    has_subfolder = False
                if has_subfolder:
                    folder_tree.insert(node_id, "end", iid=f"{dummy_prefix}:{folder_counter}", text="…")

        def on_folder_open(_event: object = None) -> None:
            selected = folder_tree.focus()
            if not selected or selected not in folder_paths:
                return
            children = folder_tree.get_children(selected)
            if children and all(child.startswith(dummy_prefix + ":") for child in children):
                for child in children:
                    folder_tree.delete(child)
                add_folder_node(selected, folder_paths[selected])

        def populate_files(folder: Path) -> None:
            nonlocal current_folder
            current_folder = folder
            file_tree.delete(*file_tree.get_children())
            file_paths.clear()
            needle = search_var.get().casefold().strip()
            try:
                if needle and global_search_var.get():
                    items = sorted(all_files, key=lambda item: str(item.relative_to(root)).casefold())
                else:
                    items = sorted((item for item in folder.iterdir() if item.is_file()), key=lambda item: item.name.casefold())
            except OSError as exc:
                set_details(f"Не удалось прочитать папку:\n{folder}\n\n{exc}")
                return
            wanted_category = category_var.get()
            visible = 0
            for item in items:
                kind = classify_game_file(item)
                if needle and needle not in (str(item.relative_to(root)) if global_search_var.get() else item.name).casefold():
                    continue
                if wanted_category != "Все файлы" and kind != wanted_category:
                    continue
                try:
                    stat = item.stat()
                    size = format_file_size(stat.st_size)
                    modified = dt.datetime.fromtimestamp(stat.st_mtime).strftime("%d.%m.%Y %H:%M")
                except OSError:
                    size, modified = "—", "—"
                item_id = f"file:{visible}:{item.as_posix()}"
                file_paths[item_id] = item
                display_name = str(item.relative_to(root)) if needle and global_search_var.get() else item.name
                file_tree.insert("", "end", iid=item_id, text=display_name, values=(kind, size, modified))
                visible += 1
            scope_label = "по всей игре" if needle and global_search_var.get() else str(folder)
            count_var.set(f"Файлов в игре: {len(all_files):,}  |  Показано: {visible:,}  |  {scope_label}".replace(",", " "))
            if not visible:
                set_details("В этой папке нет файлов, подходящих под текущий поиск и фильтр.")

        def on_folder_select(_event: object = None) -> None:
            selected = folder_tree.focus()
            folder = folder_paths.get(selected)
            if folder:
                populate_files(folder)

        def scan_root() -> None:
            nonlocal all_files, folder_counter
            count_var.set("Сканирование папки игры…")
            window.update_idletasks()
            found: list[Path] = []
            try:
                for current, dirs, names in os.walk(root, followlinks=False):
                    base = Path(current)
                    dirs[:] = [d for d in dirs if not (base / d).is_symlink() and d.casefold() not in {".fm2010_backups", "__pycache__"}]
                    for name in names:
                        candidate = base / name
                        try:
                            if not candidate.is_symlink() and candidate.is_file():
                                found.append(candidate)
                        except OSError:
                            continue
            except OSError as exc:
                messagebox.showerror("Сканирование", str(exc), parent=window)
                return
            all_files = found
            folder_tree.delete(*folder_tree.get_children())
            folder_paths.clear()
            file_tree.delete(*file_tree.get_children())
            folder_counter = 0
            root_id = "folder:root"
            folder_paths[root_id] = root
            folder_tree.insert("", "end", iid=root_id, text=root.name, open=True)
            add_folder_node(root_id, root)
            folder_tree.selection_set(root_id)
            folder_tree.focus(root_id)
            populate_files(root)
            count_var.set(f"Сканирование завершено. Найдено файлов: {len(all_files):,}".replace(",", " "))
            self.status_var.set(f"Файлов игры найдено: {len(all_files)}")
            self.log("Просканирована папка игры %s — файлов: %d", root, len(all_files))

        def selected_files() -> list[Path]:
            return [file_paths[item] for item in file_tree.selection() if item in file_paths]

        def selected_file() -> Path | None:
            choices = selected_files()
            return choices[0] if choices else None

        def show_file_details(_event: object = None) -> None:
            choices = selected_files()
            if not choices:
                set_details(f"Папка: {current_folder}\nВыберите файл, чтобы увидеть его свойства и доступные действия.")
                return
            if len(choices) > 1:
                total_size = 0
                for item in choices:
                    try:
                        total_size += item.stat().st_size
                    except OSError:
                        pass
                set_details(f"Выбрано файлов: {len(choices)}\nОбщий размер: {format_file_size(total_size)}\nМожно создать резервные копии всех выбранных файлов.")
                return
            item = choices[0]
            try:
                stat = item.stat()
                digest = sha256_file(item)
                hash_line = f"SHA-256: {digest}" if digest else "SHA-256: не рассчитан (файл больше 64 МБ или недоступен)"
                text = (
                    f"Файл: {item.name}\nПуть: {item}\nТип: {classify_game_file(item)}\n"
                    f"Размер: {format_file_size(stat.st_size)} ({stat.st_size:,} байт)\n"
                    f"Изменён: {dt.datetime.fromtimestamp(stat.st_mtime):%d.%m.%Y %H:%M:%S}\n{hash_line}"
                )
            except OSError as exc:
                text = f"{item}\nНе удалось получить свойства: {exc}"
            set_details(text)

        def edit_current() -> None:
            item = selected_file()
            if not item:
                messagebox.showinfo("Редактор", "Выберите один файл.", parent=window)
                return
            self.open_file_editor(item)

        def backup_selected() -> None:
            choices = selected_files()
            if not choices:
                messagebox.showinfo("Резервная копия", "Выберите один или несколько файлов.", parent=window)
                return
            if not messagebox.askyesno("Резервная копия", f"Создать отдельные резервные копии для {len(choices)} файла(ов)?", parent=window):
                return
            completed = 0
            failures: list[str] = []
            for item in choices:
                try:
                    backup = self._backup_file_before_save(item)
                    if item.exists() and backup is None:
                        raise OSError("backup не создан")
                    completed += 1
                except OSError as exc:
                    failures.append(f"{item.name}: {exc}")
            self.log("Созданы резервные копии: %d из %d", completed, len(choices))
            self.status_var.set(f"Резервные копии: {completed}/{len(choices)}")
            summary = f"Успешно: {completed} из {len(choices)}.\nПапка backup: {self.app_data_dir / 'file_backups'}"
            if failures:
                summary += "\n\nОшибки:\n" + "\n".join(failures[:10])
            messagebox.showinfo("Резервная копия", summary, parent=window)

        def replace_current() -> None:
            target = selected_file()
            if not target:
                messagebox.showinfo("Замена файла", "Выберите один файл для замены.", parent=window)
                return
            source_name = filedialog.askopenfilename(
                parent=window,
                title=f"Выберите новый файл для замены {target.name}",
                filetypes=(("Все файлы", "*.*"),),
            )
            if not source_name:
                return
            source = Path(source_name).resolve()
            if not source.is_file() or source == target.resolve():
                messagebox.showwarning("Замена файла", "Выбранный файл недоступен или совпадает с целевым.", parent=window)
                return
            target_ext = target.suffix.casefold()
            source_ext = source.suffix.casefold()
            if target_ext != source_ext and not messagebox.askyesno(
                "Разные расширения",
                f"У файлов разные расширения: {target_ext or '(нет)'} и {source_ext or '(нет)'}.\n\nПродолжить замену?",
                parent=window,
            ):
                return
            binary_warning = target.suffix.lower() in PROTECTED_BINARY_EXTENSIONS or classify_game_file(target) in {"Исполняемый файл", "Данные / неизвестный тип"}
            message = (
                f"Заменить файл игры?\n\nЦелевой файл:\n{target}\n\nНовый файл:\n{source}\n\n"
                "Перед заменой будет создана резервная копия. Неподходящий файл может нарушить работу игры."
            )
            if binary_warning:
                message += "\n\nВНИМАНИЕ: это бинарный или исполняемый файл. Проверьте, что выбран совместимый файл той же версии игры."
            if not messagebox.askyesno("Подтверждение замены", message, icon="warning", parent=window):
                return
            try:
                backup = self._backup_file_before_save(target)
                if target.exists() and backup is None:
                    raise SettingsError("Не удалось создать резервную копию — замена отменена.")
                self.atomic_copy_file(source, target)
                self.log("Файл заменён: %s; источник=%s; backup=%s", target, source, backup)
                self.status_var.set(f"Файл заменён: {target.name}")
                populate_files(current_folder)
                messagebox.showinfo("Замена файла", f"Файл заменён. Резервная копия:\n{backup}", parent=window)
            except (OSError, SettingsError) as exc:
                self.log("Ошибка замены файла %s: %s", target, exc, level=logging.ERROR)
                messagebox.showerror("Замена файла", str(exc), parent=window)

        def open_external() -> None:
            item = selected_file()
            if not item:
                return
            try:
                os.startfile(str(item))  # type: ignore[attr-defined]
            except (OSError, AttributeError) as exc:
                messagebox.showerror("Открытие файла", f"Не удалось открыть файл внешней программой:\n{exc}", parent=window)

        def open_location() -> None:
            item = selected_file()
            if not item:
                return
            try:
                os.startfile(str(item.parent))  # type: ignore[attr-defined]
            except (OSError, AttributeError) as exc:
                messagebox.showerror("Папка файла", str(exc), parent=window)

        def copy_path() -> None:
            item = selected_file()
            if item:
                window.clipboard_clear()
                window.clipboard_append(str(item))
                self.status_var.set("Путь к файлу скопирован")

        def compare_selected() -> None:
            choices = selected_files()
            if len(choices) != 2:
                messagebox.showinfo("Сравнение файлов", "Выберите ровно два файла (Ctrl или Shift для множественного выбора).", parent=window)
                return
            first, second = choices
            try:
                if first.suffix.lower() in EDITABLE_EXTENSIONS and second.suffix.lower() in EDITABLE_EXTENSIONS:
                    left_text, _enc1, _nl1 = self._read_editable_file(first)
                    right_text, _enc2, _nl2 = self._read_editable_file(second)
                    diff = list(difflib.unified_diff(
                        left_text.splitlines(), right_text.splitlines(),
                        fromfile=str(first), tofile=str(second), lineterm="",
                    ))
                    result = "\n".join(diff) if diff else "Файлы полностью совпадают по текстовому содержимому."
                else:
                    size1, size2 = first.stat().st_size, second.stat().st_size
                    hash1, hash2 = sha256_file(first), sha256_file(second)
                    result = (
                        f"Файл A: {first}\nРазмер: {format_file_size(size1)}\nSHA-256: {hash1 or 'не рассчитан (>64 МБ)'}\n\n"
                        f"Файл B: {second}\nРазмер: {format_file_size(size2)}\nSHA-256: {hash2 or 'не рассчитан (>64 МБ)'}\n\n"
                    )
                    if hash1 and hash2:
                        result += "Файлы идентичны." if hash1 == hash2 else "Файлы отличаются."
                    elif size1 == size2:
                        result += "Размер одинаковый; для полной проверки больших файлов нужен внешний SHA-256-инструмент."
                    else:
                        result += "Размер файлов различается."
            except (OSError, SettingsError) as exc:
                messagebox.showerror("Сравнение файлов", str(exc), parent=window)
                return
            compare_window = tk.Toplevel(window)
            compare_window.title(f"Сравнение — {first.name} ↔ {second.name}")
            compare_window.geometry("1000x680")
            compare_window.transient(window)
            output = tk.Text(compare_window, wrap="none", font=("Consolas", 10))
            sy = ttk.Scrollbar(compare_window, orient="vertical", command=output.yview)
            sx = ttk.Scrollbar(compare_window, orient="horizontal", command=output.xview)
            output.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
            output.grid(row=0, column=0, sticky="nsew")
            sy.grid(row=0, column=1, sticky="ns")
            sx.grid(row=1, column=0, sticky="ew")
            compare_window.rowconfigure(0, weight=1)
            compare_window.columnconfigure(0, weight=1)
            output.insert("1.0", result)
            output.configure(state="disabled")

        def copy_current_file() -> None:
            item = selected_file()
            if not item:
                messagebox.showinfo("Копирование", "Выберите один файл.", parent=window)
                return
            destination_name = filedialog.asksaveasfilename(
                parent=window, title="Сохранить копию файла", initialdir=str(item.parent),
                initialfile=f"{item.stem}_copy{item.suffix}", defaultextension=item.suffix,
                filetypes=(("Все файлы", "*.*"),),
            )
            if not destination_name:
                return
            destination = Path(destination_name).resolve()
            if destination == item.resolve():
                messagebox.showwarning("Копирование", "Путь копии совпадает с исходным файлом.", parent=window)
                return
            if destination.exists():
                if not messagebox.askyesno("Перезапись", f"Файл уже существует:\n{destination}\n\nСоздать backup и заменить?", parent=window):
                    return
                try:
                    backup = self._backup_file_before_save(destination)
                    if backup is None:
                        raise SettingsError("Не удалось создать backup целевого файла.")
                except (OSError, SettingsError) as exc:
                    messagebox.showerror("Копирование", str(exc), parent=window)
                    return
            try:
                self.atomic_copy_file(item, destination)
                self.log("Создана копия файла: %s → %s", item, destination)
                messagebox.showinfo("Копирование", f"Копия создана:\n{destination}", parent=window)
            except OSError as exc:
                messagebox.showerror("Копирование", str(exc), parent=window)

        def hex_patch_current() -> None:
            item = selected_file()
            if not item:
                messagebox.showinfo("HEX-патчер", "Выберите файл.", parent=window)
                return
            try:
                file_size = item.stat().st_size
            except OSError as exc:
                messagebox.showerror("HEX-патчер", str(exc), parent=window)
                return

            patch_window = tk.Toplevel(window)
            patch_window.title(f"HEX-патчер — {item.name}")
            patch_window.geometry("720x390")
            patch_window.minsize(620, 330)
            patch_window.transient(window)
            frame = ttk.Frame(patch_window, padding=14)
            frame.pack(fill="both", expand=True)
            ttk.Label(frame, text=f"Файл: {item}\nРазмер: {format_file_size(file_size)}", wraplength=680).pack(anchor="w")
            ttk.Label(frame, text="Смещение (0x100 или десятичное число):").pack(anchor="w", pady=(12, 3))
            offset_var = tk.StringVar(value="0x0")
            ttk.Entry(frame, textvariable=offset_var).pack(fill="x")
            ttk.Label(frame, text="Новые байты (HEX, например: 48 65 6C 6C 6F):").pack(anchor="w", pady=(10, 3))
            bytes_var = tk.StringVar()
            ttk.Entry(frame, textvariable=bytes_var).pack(fill="x")
            ttk.Label(frame, text="Было:").pack(anchor="w", pady=(10, 3))
            old_var = tk.StringVar(value="Укажите смещение и новые байты, затем нажмите «Прочитать».")
            ttk.Entry(frame, textvariable=old_var, state="readonly").pack(fill="x")
            ttk.Label(
                frame,
                text="Внимание: это низкоуровневое изменение. Длина файла не меняется; неверные байты могут повредить файл или игру. Перед записью создаётся backup.",
                foreground="#8a4b00", wraplength=680,
            ).pack(anchor="w", pady=(12, 8))

            def parse_patch() -> tuple[int, bytes]:
                raw_offset = offset_var.get().strip()
                try:
                    try:
                        offset = int(raw_offset, 0)
                    except ValueError:
                        offset = int(raw_offset, 10)
                except ValueError as exc:
                    raise SettingsError("Смещение должно быть числом, например 0x120 или 288.") from exc
                if offset < 0:
                    raise SettingsError("Смещение не может быть отрицательным.")
                raw_hex = bytes_var.get().strip()
                if not raw_hex:
                    raise SettingsError("Введите новые байты в HEX-формате.")
                try:
                    payload = bytes.fromhex(raw_hex)
                except ValueError as exc:
                    raise SettingsError("HEX-строка некорректна. Пример: 90 90 FF 00.") from exc
                if not payload:
                    raise SettingsError("Не указаны байты для записи.")
                if len(payload) > 4096:
                    raise SettingsError("За одну операцию можно изменить не более 4096 байт.")
                if offset + len(payload) > file_size:
                    raise SettingsError(f"Диапазон выходит за границы файла. Размер файла: {file_size} байт.")
                return offset, payload

            def read_old() -> None:
                try:
                    offset, payload = parse_patch()
                    with item.open("rb") as stream:
                        stream.seek(offset)
                        old = stream.read(len(payload))
                    if len(old) != len(payload):
                        raise SettingsError("Не удалось прочитать полный диапазон.")
                    old_var.set(" ".join(f"{byte:02X}" for byte in old))
                except (OSError, SettingsError) as exc:
                    messagebox.showerror("HEX-патчер", str(exc), parent=patch_window)

            def apply_patch() -> None:
                try:
                    offset, payload = parse_patch()
                    with item.open("rb") as stream:
                        stream.seek(offset)
                        old = stream.read(len(payload))
                    if len(old) != len(payload):
                        raise SettingsError("Не удалось прочитать исходные байты.")
                    old_hex = " ".join(f"{byte:02X}" for byte in old)
                    new_hex = " ".join(f"{byte:02X}" for byte in payload)
                    warning = "\n\nЭто EXE/DLL или другой исполняемый компонент." if item.suffix.lower() in PROTECTED_BINARY_EXTENSIONS else ""
                    prompt = (
                        f"Файл: {item.name}\nСмещение: 0x{offset:X} ({offset})\n\n"
                        f"Было:  {old_hex}\nСтало: {new_hex}\n\n"
                        "Создать backup и записать эти байты? Отмена оставит файл без изменений."
                        f"{warning}"
                    )
                    if not messagebox.askyesno("Применить HEX-патч", prompt, icon="warning", parent=patch_window):
                        return
                    backup = self._backup_file_before_save(item)
                    if item.exists() and backup is None:
                        raise SettingsError("Не удалось создать резервную копию — патч не применён.")
                    self.atomic_patch_bytes(item, offset, payload)
                    self.log("HEX-патч: %s offset=0x%X bytes=%s backup=%s", item, offset, new_hex, backup)
                    self.status_var.set(f"HEX-патч применён: {item.name}")
                    old_var.set(old_hex)
                    populate_files(current_folder)
                    messagebox.showinfo("HEX-патчер", f"Байты изменены. Резервная копия:\n{backup}", parent=patch_window)
                except (OSError, SettingsError) as exc:
                    messagebox.showerror("HEX-патчер", str(exc), parent=patch_window)

            buttons = ttk.Frame(frame)
            buttons.pack(fill="x", pady=(8, 0))
            ttk.Button(buttons, text="Прочитать старые байты", command=read_old).pack(side="left")
            ttk.Button(buttons, text="Применить патч", command=apply_patch).pack(side="left", padx=6)
            ttk.Button(buttons, text="Закрыть", command=patch_window.destroy).pack(side="right")

        def preview_current() -> None:
            item = selected_file()
            if not item:
                return
            try:
                stat = item.stat()
                kind = classify_game_file(item)
                info = (
                    f"Имя: {item.name}\nКатегория: {kind}\nРазмер: {format_file_size(stat.st_size)}\n"
                    f"Путь: {item}\n\n"
                )
                can_edit = False
                if item.suffix.lower() == ".zip":
                    with zipfile.ZipFile(item, "r") as archive:
                        infos = archive.infolist()
                        unsafe = []
                        for member in infos:
                            try:
                                safe_member_path(root, member.filename)
                            except ValueError:
                                unsafe.append(member.filename)
                        listing = "Содержимое ZIP:\n" + "\n".join(
                            f"{m.filename}  ({format_file_size(m.file_size)})" for m in infos[:250]
                        )
                        if len(infos) > 250:
                            listing += f"\n… ещё {len(infos) - 250} элементов"
                        if unsafe:
                            listing += "\n\nВНИМАНИЕ: архив содержит небезопасные пути. Не распаковывайте его."
                        info += listing
                elif item.suffix.lower() in EDITABLE_EXTENSIONS:
                    try:
                        content, _encoding, _newline = self._read_editable_file(item)
                        can_edit = True
                        info += "Текстовое содержимое (начало файла):\n" + content[:6000]
                        if len(content) > 6000:
                            info += "\n… предварительный просмотр ограничен"
                    except SettingsError:
                        with item.open("rb") as stream:
                            raw = stream.read(512)
                        hex_lines = []
                        for offset in range(0, len(raw), 16):
                            chunk = raw[offset:offset + 16]
                            hex_part = " ".join(f"{byte:02X}" for byte in chunk)
                            ascii_part = "".join(chr(byte) if 32 <= byte < 127 else "." for byte in chunk)
                            hex_lines.append(f"{offset:08X}  {hex_part:<47}  {ascii_part}")
                        info += "Файл похож на бинарный. Начало файла (HEX):\n" + "\n".join(hex_lines)
                        if stat.st_size > len(raw):
                            info += "\n… показаны первые 512 байт"
                else:
                    with item.open("rb") as stream:
                        raw = stream.read(512)
                    hex_lines = []
                    for offset in range(0, len(raw), 16):
                        chunk = raw[offset:offset + 16]
                        hex_part = " ".join(f"{byte:02X}" for byte in chunk)
                        ascii_part = "".join(chr(byte) if 32 <= byte < 127 else "." for byte in chunk)
                        hex_lines.append(f"{offset:08X}  {hex_part:<47}  {ascii_part}")
                    info += "Начало файла (HEX, только просмотр):\n" + "\n".join(hex_lines)
                    if stat.st_size > len(raw):
                        info += "\n… показаны первые 512 байт"
                preview = tk.Toplevel(window)
                preview.title(f"Просмотр — {item.name}")
                preview.geometry("900x650")
                preview.transient(window)
                text = tk.Text(preview, wrap="none", font=("Consolas", 10))
                sy = ttk.Scrollbar(preview, orient="vertical", command=text.yview)
                sx = ttk.Scrollbar(preview, orient="horizontal", command=text.xview)
                text.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
                text.grid(row=0, column=0, sticky="nsew")
                sy.grid(row=0, column=1, sticky="ns")
                sx.grid(row=1, column=0, sticky="ew")
                preview.rowconfigure(0, weight=1)
                preview.columnconfigure(0, weight=1)
                text.insert("1.0", info)
                text.configure(state="disabled")
                actions = ttk.Frame(preview, padding=8)
                actions.grid(row=2, column=0, columnspan=2, sticky="ew")
                if can_edit:
                    ttk.Button(actions, text="Открыть в редакторе", command=lambda: self.open_file_editor(item)).pack(side="left")
                ttk.Button(actions, text="Открыть внешней программой", command=lambda: open_path_external(item, preview)).pack(side="left", padx=6)
                ttk.Button(actions, text="Закрыть", command=preview.destroy).pack(side="right")
            except (OSError, zipfile.BadZipFile, SettingsError) as exc:
                messagebox.showerror("Просмотр файла", str(exc), parent=window)

        def open_path_external(item: Path, parent: tk.Misc) -> None:
            try:
                os.startfile(str(item))  # type: ignore[attr-defined]
            except (OSError, AttributeError) as exc:
                messagebox.showerror("Открытие файла", str(exc), parent=parent)

        def export_inventory() -> None:
            destination = filedialog.asksaveasfilename(
                parent=window, title="Сохранить инвентаризацию файлов игры",
                initialfile="FM2010_file_inventory.csv", defaultextension=".csv",
                filetypes=(("CSV", "*.csv"),),
            )
            if not destination:
                return
            try:
                import csv
                with Path(destination).open("w", newline="", encoding="utf-8-sig") as stream:
                    writer = csv.writer(stream, delimiter=";")
                    writer.writerow(("Относительный путь", "Имя", "Расширение", "Категория", "Размер (байт)", "Изменён"))
                    for item in all_files:
                        try:
                            stat = item.stat()
                            writer.writerow((str(item.relative_to(root)), item.name, item.suffix.lower(), classify_game_file(item), stat.st_size, dt.datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")))
                        except OSError:
                            continue
                self.log("Экспортирован список файлов игры: %s", destination)
                messagebox.showinfo("Отчёт CSV", f"Список файлов сохранён:\n{destination}", parent=window)
            except OSError as exc:
                messagebox.showerror("Отчёт CSV", str(exc), parent=window)

        def choose_another_root() -> None:
            selected = filedialog.askdirectory(parent=window, title="Выберите другую папку игры", initialdir=str(root))
            if not selected:
                return
            new_root = Path(selected).resolve()
            if not new_root.is_dir():
                return
            self.install_dir = new_root
            found = _find_game_executable(new_root)
            self.game_exe = found.resolve() if found else None
            self._save_settings()
            self.update_path_labels()
            # Reopen with the new root so every view has one consistent base path.
            window.destroy()
            self.open_game_file_manager(new_root)

        def on_file_double_click(_event: object = None) -> None:
            item = selected_file()
            if not item:
                return
            if item.suffix.lower() in EDITABLE_EXTENSIONS and item.suffix.lower() not in PROTECTED_BINARY_EXTENSIONS:
                try:
                    self._read_editable_file(item)
                    self.open_file_editor(item)
                except (OSError, SettingsError):
                    preview_current()
            else:
                preview_current()

        search_var.trace_add("write", lambda *_args: populate_files(current_folder))
        category_var.trace_add("write", lambda *_args: populate_files(current_folder))
        folder_tree.bind("<<TreeviewOpen>>", on_folder_open)
        folder_tree.bind("<<TreeviewSelect>>", on_folder_select)
        file_tree.bind("<<TreeviewSelect>>", show_file_details)
        file_tree.bind("<Double-1>", on_file_double_click)
        def show_context_menu(event: tk.Event) -> None:
            row = file_tree.identify_row(event.y)
            if row:
                if row not in file_tree.selection():
                    file_tree.selection_set(row)
                context_menu.tk_popup(event.x_root, event.y_root)

        file_tree.bind("<Button-3>", show_context_menu)

        context_menu = tk.Menu(window, tearoff=False)
        context_menu.add_command(label="Просмотр", command=preview_current)
        context_menu.add_command(label="Редактировать текст", command=edit_current)
        context_menu.add_command(label="Изменить байты (HEX)…", command=hex_patch_current)
        context_menu.add_separator()
        context_menu.add_command(label="Заменить файл…", command=replace_current)
        context_menu.add_command(label="Создать backup выбранных", command=backup_selected)
        context_menu.add_command(label="Сравнить два выбранных", command=compare_selected)
        context_menu.add_command(label="Создать копию…", command=copy_current_file)
        context_menu.add_separator()
        context_menu.add_command(label="Открыть папку файла", command=open_location)
        context_menu.add_command(label="Копировать полный путь", command=copy_path)
        context_menu.add_command(label="Открыть внешней программой", command=open_external)

        buttons = [
            ("Просмотр / HEX", preview_current), ("Редактировать", edit_current),
            ("HEX-патч…", hex_patch_current),
            ("Заменить файл…", replace_current), ("Backup выбранных", backup_selected),
            ("Открыть файл", open_external), ("Папка файла", open_location),
            ("Копировать путь", copy_path), ("Сравнить 2", compare_selected),
            ("Копия файла…", copy_current_file),
        ]
        for label, callback in buttons:
            ttk.Button(footer, text=label, command=callback).pack(side="right", padx=2)

        ttk.Label(header, text=f"Версия {APP_VERSION}", foreground="#666").pack(side="right", padx=(8, 0))
        scan_root()

    def _require_install_root(self) -> Path:
        root = self.install_dir
        if not root or not root.is_dir():
            raise SettingsError("Сначала выберите корневую папку установки Football Manager 2010.")
        return root.resolve()

    @staticmethod
    def _iter_files(root: Path, max_files: int = 200000):
        """Yield regular files below root without following symlinked directories."""
        emitted = 0
        for current, dirs, names in os.walk(root):
            dirs[:] = [name for name in dirs if name not in {".git", "__pycache__", BACKUP_DIR_NAME}]
            base = Path(current)
            for name in names:
                path = base / name
                try:
                    if path.is_symlink() or not path.is_file():
                        continue
                except OSError:
                    continue
                yield path
                emitted += 1
                if emitted >= max_files:
                    return

    def open_modding_suite(self) -> None:
        """Open the expanded collection of safe modding and maintenance tools."""
        try:
            root = self._require_install_root()
        except SettingsError as exc:
            messagebox.showwarning("Классические инструменты PRO", str(exc), parent=self)
            return

        window = tk.Toplevel(self)
        window.title(f"FM2010 Classic Tools — {APP_VERSION}")
        window.geometry("1160x800")
        window.minsize(980, 680)
        window.transient(self)

        top = ttk.Frame(window, padding=(14, 12, 14, 8))
        top.pack(fill="x")
        ttk.Label(top, text="FM2010 MODDING SUITE PRO", font=("Segoe UI", 19, "bold")).pack(anchor="w")
        root_var = tk.StringVar(value=f"Рабочая папка: {root}")
        ttk.Label(top, textvariable=root_var, foreground="#555", wraplength=1080).pack(anchor="w", pady=(4, 0))
        notebook = ttk.Notebook(window)
        notebook.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        status = tk.StringVar(value="Готово. Выберите инструмент.")
        ttk.Label(window, textvariable=status, relief="sunken", anchor="w", padding=6).pack(fill="x", side="bottom")

        overview = ttk.Frame(notebook, padding=14)
        finder = ttk.Frame(notebook, padding=12)
        batch = ttk.Frame(notebook, padding=12)
        integrity = ttk.Frame(notebook, padding=12)
        mods = ttk.Frame(notebook, padding=12)
        cleanup = ttk.Frame(notebook, padding=12)
        for frame, title in (
            (overview, "Обзор"), (finder, "Поиск в ресурсах"), (batch, "Пакетная замена"),
            (integrity, "Целостность и дубли"), (mods, "Профили и мод-паки"), (cleanup, "Карантин и обслуживание"),
        ):
            notebook.add(frame, text=title)

        # OVERVIEW
        ttk.Label(overview, text="Инструменты для исследования, настройки и модификации установки FM 2010.",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 12))
        stats_var = tk.StringVar(value="Нажмите «Анализ установки», чтобы получить сводку.")
        ttk.Label(overview, textvariable=stats_var, justify="left", wraplength=1050,
                  background="#f2f4f7", padding=12).pack(fill="x", pady=(0, 12))
        overview_grid = ttk.Frame(overview)
        overview_grid.pack(fill="both", expand=True)
        overview_actions = [
            ("Анализ установки", lambda: analyze_install()),
            ("Создать отчёт диагностики", lambda: diagnostics_report()),
            ("Поиск по содержимому", lambda: notebook.select(finder)),
            ("Пакетная замена текста", lambda: notebook.select(batch)),
            ("Снимок / проверка целостности", lambda: notebook.select(integrity)),
            ("Профили изменений", lambda: notebook.select(mods)),
            ("Собрать ZIP-мод", lambda: build_modpack()),
            ("Установить ZIP-мод", lambda: install_modpack()),
            ("Найти одинаковые файлы", lambda: find_duplicates()),
            ("Карантин временных файлов", lambda: notebook.select(cleanup)),
        ]
        for i, (label, callback) in enumerate(overview_actions):
            row, col = divmod(i, 2)
            ttk.Button(overview_grid, text=label, command=callback).grid(row=row, column=col, sticky="ew", padx=5, pady=5, ipady=9)
        overview_grid.columnconfigure(0, weight=1)
        overview_grid.columnconfigure(1, weight=1)
        ttk.Label(overview, text="Безопасность: все массовые изменения требуют подтверждения; перед перезаписью создаются резервные копии. "
                                 "Исполняемые файлы не редактируются как текст.", foreground="#805000", wraplength=1050).pack(anchor="w", pady=(12, 0))

        def analyze_install() -> None:
            try:
                files = list(self._iter_files(root))
                total_bytes = 0
                ext_counts: dict[str, int] = {}
                unreadable = 0
                zero_size = 0
                for item in files:
                    try:
                        size = item.stat().st_size
                        total_bytes += size
                        ext = item.suffix.lower() or "(без расширения)"
                        ext_counts[ext] = ext_counts.get(ext, 0) + 1
                        if size == 0:
                            zero_size += 1
                    except OSError:
                        unreadable += 1
                largest = sorted(((p.stat().st_size, p) for p in files if p.exists()), reverse=True)[:8]
                top_ext = sorted(ext_counts.items(), key=lambda pair: pair[1], reverse=True)[:12]
                text = (
                    f"Файлов найдено: {len(files):,}\nОбщий объём: {format_file_size(total_bytes)}\n"
                    f"Пустых файлов: {zero_size}\nНедоступных файлов: {unreadable}\n\n"
                    "Частые расширения:\n" + "\n".join(f"  {ext}: {count}" for ext, count in top_ext) +
                    "\n\nСамые большие файлы:\n" + "\n".join(f"  {format_file_size(size)} — {path.relative_to(root)}" for size, path in largest)
                )
                stats_var.set(text)
                status.set(f"Анализ завершён: {len(files)} файлов")
                self.log("Выполнен анализ установки: %d файлов, %s", len(files), format_file_size(total_bytes))
            except OSError as exc:
                messagebox.showerror("Анализ установки", str(exc), parent=window)

        def diagnostics_report() -> None:
            try:
                files = list(self._iter_files(root))
                total = sum(p.stat().st_size for p in files if p.exists())
                lines = [
                    "FOOTBALL MANAGER 2010 — DIAGNOSTICS", f"Generated: {dt.datetime.now().isoformat(timespec='seconds')}",
                    f"App version: {APP_VERSION}", f"Python: {sys.version}", f"Platform: {sys.platform}",
                    f"Install root: {root}", f"Game executable: {self.game_exe or '(not detected)'}",
                    f"Data folder: {self.game_dir or '(not detected)'}", f"File count: {len(files)}",
                    f"Total bytes: {total}", "", "Top-level entries:",
                ]
                try:
                    for item in sorted(root.iterdir(), key=lambda p: p.name.casefold()):
                        lines.append(f"{'[DIR]' if item.is_dir() else '[FILE]'} {item.name}")
                except OSError as exc:
                    lines.append(f"Unable to list root: {exc}")
                destination = filedialog.asksaveasfilename(parent=window, title="Сохранить диагностический отчёт",
                    initialfile="FM2010_diagnostics.txt", defaultextension=".txt", filetypes=(("Текст", "*.txt"),))
                if not destination:
                    return
                Path(destination).write_text("\n".join(lines), encoding="utf-8")
                status.set("Диагностический отчёт сохранён")
                messagebox.showinfo("Диагностика", f"Отчёт сохранён:\n{destination}", parent=window)
            except OSError as exc:
                messagebox.showerror("Диагностика", str(exc), parent=window)

        # CONTENT FINDER
        find_bar = ttk.Frame(finder)
        find_bar.pack(fill="x", pady=(0, 8))
        content_query = tk.StringVar()
        content_exts = tk.StringVar(value=".xml,.ini,.cfg,.txt,.json,.csv,.dat,.vdf,.sii,.lua")
        insensitive = tk.BooleanVar(value=True)
        ttk.Label(find_bar, text="Искать текст:").grid(row=0, column=0, sticky="w")
        ttk.Entry(find_bar, textvariable=content_query, width=36).grid(row=0, column=1, sticky="ew", padx=6)
        ttk.Label(find_bar, text="Расширения:").grid(row=0, column=2, sticky="w")
        ttk.Entry(find_bar, textvariable=content_exts, width=48).grid(row=0, column=3, sticky="ew", padx=6)
        ttk.Checkbutton(find_bar, text="Без учёта регистра", variable=insensitive).grid(row=1, column=1, sticky="w", pady=5)
        find_bar.columnconfigure(1, weight=1)
        find_bar.columnconfigure(3, weight=1)
        finder_tree = ttk.Treeview(finder, columns=("line", "snippet"), show="tree headings", height=22)
        finder_tree.heading("#0", text="Файл")
        finder_tree.heading("line", text="Строка")
        finder_tree.heading("snippet", text="Фрагмент")
        finder_tree.column("#0", width=380)
        finder_tree.column("line", width=75, anchor="center")
        finder_tree.column("snippet", width=560)
        finder_tree.pack(fill="both", expand=True)
        finder_paths: dict[str, Path] = {}

        def search_content() -> None:
            query = content_query.get()
            if not query:
                messagebox.showwarning("Поиск", "Введите текст для поиска.", parent=window)
                return
            extensions = {x.strip().lower() if x.strip().startswith(".") else "." + x.strip().lower()
                          for x in content_exts.get().split(",") if x.strip()}
            finder_tree.delete(*finder_tree.get_children())
            finder_paths.clear()
            matches = 0
            checked = 0
            needle = query if not insensitive.get() else query.casefold()
            for path in self._iter_files(root):
                if extensions and path.suffix.lower() not in extensions:
                    continue
                try:
                    if path.stat().st_size > 6 * 1024 * 1024:
                        continue
                    raw = path.read_bytes()
                    if b"\x00" in raw:
                        continue
                    try:
                        content = raw.decode("utf-8-sig")
                    except UnicodeDecodeError:
                        try:
                            content = raw.decode("cp1251")
                        except UnicodeDecodeError:
                            continue
                    checked += 1
                    for line_no, line in enumerate(content.splitlines(), 1):
                        haystack = line if not insensitive.get() else line.casefold()
                        if needle in haystack:
                            iid = f"r{matches}"
                            finder_paths[iid] = path
                            finder_tree.insert("", "end", iid=iid, text=str(path.relative_to(root)),
                                               values=(line_no, line.strip()[:240]))
                            matches += 1
                            if matches >= 3000:
                                break
                    if matches >= 3000:
                        break
                except OSError:
                    continue
            status.set(f"Поиск завершён: просмотрено {checked} текстовых файлов, совпадений: {matches}")
            self.log("Поиск по содержимому: %r; совпадений=%d", query, matches)

        def open_finder_result(_event: object = None) -> None:
            selected = finder_tree.selection()
            if selected and selected[0] in finder_paths:
                self.open_file_editor(finder_paths[selected[0]])

        ttk.Button(find_bar, text="Искать", command=search_content).grid(row=0, column=4, padx=5)
        ttk.Button(find_bar, text="Очистить", command=lambda: finder_tree.delete(*finder_tree.get_children())).grid(row=1, column=4, padx=5)
        finder_tree.bind("<Double-1>", open_finder_result)
        ttk.Label(finder, text="Двойной щелчок по результату открывает файл в редакторе. Поиск пропускает бинарные и крупные файлы.",
                  foreground="#666").pack(anchor="w", pady=(6, 0))

        # BATCH REPLACEMENT
        batch_form = ttk.Frame(batch)
        batch_form.pack(fill="x", pady=(0, 8))
        old_text = tk.StringVar()
        new_text = tk.StringVar()
        batch_exts = tk.StringVar(value=".xml,.ini,.cfg,.txt,.json,.csv,.vdf,.sii")
        ttk.Label(batch_form, text="Найти:").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(batch_form, textvariable=old_text).grid(row=0, column=1, sticky="ew", padx=8, pady=4)
        ttk.Label(batch_form, text="Заменить на:").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(batch_form, textvariable=new_text).grid(row=1, column=1, sticky="ew", padx=8, pady=4)
        ttk.Label(batch_form, text="Типы файлов:").grid(row=2, column=0, sticky="w", pady=4)
        ttk.Entry(batch_form, textvariable=batch_exts).grid(row=2, column=1, sticky="ew", padx=8, pady=4)
        batch_form.columnconfigure(1, weight=1)
        batch_tree = ttk.Treeview(batch, columns=("count", "path"), show="tree headings", height=18)
        batch_tree.heading("#0", text="Файл")
        batch_tree.heading("count", text="Совпадений")
        batch_tree.heading("path", text="Путь")
        batch_tree.column("#0", width=220)
        batch_tree.column("count", width=100, anchor="center")
        batch_tree.column("path", width=700)
        batch_tree.pack(fill="both", expand=True)
        batch_matches: list[tuple[Path, int]] = []

        def preview_batch_replace() -> None:
            needle = old_text.get()
            if not needle:
                messagebox.showwarning("Пакетная замена", "Поле «Найти» не может быть пустым.", parent=window)
                return
            extensions = {x.strip().lower() if x.strip().startswith(".") else "." + x.strip().lower()
                          for x in batch_exts.get().split(",") if x.strip()}
            batch_matches.clear()
            batch_tree.delete(*batch_tree.get_children())
            for path in self._iter_files(root):
                if extensions and path.suffix.lower() not in extensions:
                    continue
                try:
                    content, _enc, _nl = self._read_editable_file(path)
                except (OSError, SettingsError):
                    continue
                count = content.count(needle)
                if count:
                    batch_matches.append((path, count))
                    batch_tree.insert("", "end", text=path.name, values=(count, str(path.relative_to(root))))
                    if len(batch_matches) >= 1000:
                        break
            total = sum(count for _, count in batch_matches)
            status.set(f"Предпросмотр: файлов {len(batch_matches)}, совпадений {total}. Ничего ещё не изменено.")

        def apply_batch_replace() -> None:
            needle = old_text.get()
            if not needle or not batch_matches:
                messagebox.showwarning("Пакетная замена", "Сначала выполните предварительный просмотр.", parent=window)
                return
            total = sum(count for _, count in batch_matches)
            if not messagebox.askyesno("Подтверждение пакетной замены",
                f"Будет изменено файлов: {len(batch_matches)}\nВсего замен: {total}\n\nДля каждого файла будет создан backup. Продолжить?",
                icon="warning", parent=window):
                return
            changed = 0
            failures: list[str] = []
            for path, _count in list(batch_matches):
                try:
                    content, encoding, newline = self._read_editable_file(path)
                    if needle not in content:
                        continue
                    updated = content.replace(needle, new_text.get())
                    if path.suffix.lower() == ".xml":
                        ET.fromstring(updated)
                    elif path.suffix.lower() == ".json":
                        json.loads(updated)
                    backup = self._backup_file_before_save(path)
                    if path.exists() and backup is None:
                        raise SettingsError("резервная копия не создана")
                    normalized = updated.replace("\r\n", "\n").replace("\r", "\n")
                    if newline == "\r\n":
                        normalized = normalized.replace("\n", "\r\n")
                    self.atomic_write_bytes(path, normalized.encode(encoding))
                    changed += 1
                except Exception as exc:
                    failures.append(f"{path.relative_to(root)}: {exc}")
            batch_matches.clear()
            status.set(f"Пакетная замена завершена: изменено {changed}; ошибок {len(failures)}")
            self.log("Пакетная замена: изменено=%d ошибок=%d", changed, len(failures))
            summary = f"Изменено файлов: {changed}\nОшибок: {len(failures)}"
            if failures:
                summary += "\n\n" + "\n".join(failures[:20])
            messagebox.showinfo("Пакетная замена", summary, parent=window)
            preview_batch_replace()

        batch_buttons = ttk.Frame(batch)
        batch_buttons.pack(fill="x", pady=(8, 0))
        ttk.Button(batch_buttons, text="Предпросмотр совпадений", command=preview_batch_replace).pack(side="left")
        ttk.Button(batch_buttons, text="Применить замену с backup", command=apply_batch_replace).pack(side="left", padx=8)
        ttk.Label(batch, text="Операция ограничена текстовыми файлами. XML и JSON проверяются до записи; исполняемые файлы пропускаются.",
                  foreground="#666").pack(anchor="w", pady=(6, 0))

        # INTEGRITY AND DUPLICATES
        integrity_top = ttk.Frame(integrity)
        integrity_top.pack(fill="x", pady=(0, 8))
        full_hash = tk.BooleanVar(value=False)
        ttk.Checkbutton(integrity_top, text="Включить SHA-256 для файлов до 512 МБ (медленнее, но точнее)", variable=full_hash).pack(side="left")
        ttk.Button(integrity_top, text="Создать снимок", command=lambda: create_inventory_snapshot()).pack(side="right", padx=4)
        ttk.Button(integrity_top, text="Сравнить со снимком", command=lambda: compare_inventory_snapshot()).pack(side="right", padx=4)
        integrity_text = tk.Text(integrity, height=25, wrap="word", font=("Consolas", 9))
        integrity_text.pack(fill="both", expand=True)
        integrity_text.insert("1.0", "Снимок фиксирует структуру установки. Сравнение покажет новые, изменённые и отсутствующие файлы.\n")
        integrity_text.configure(state="disabled")
        snapshot_key = hashlib.sha256(str(root).casefold().encode("utf-8", errors="replace")).hexdigest()[:16]
        snapshot_path = self.app_data_dir / "inventory" / f"{snapshot_key}.json"

        def set_integrity_text(value: str) -> None:
            integrity_text.configure(state="normal")
            integrity_text.delete("1.0", "end")
            integrity_text.insert("1.0", value)
            integrity_text.configure(state="disabled")

        def scan_inventory() -> dict[str, dict]:
            records: dict[str, dict] = {}
            files = list(self._iter_files(root))
            for index, item in enumerate(files, 1):
                try:
                    stat = item.stat()
                    record = {"size": stat.st_size, "mtime": int(stat.st_mtime)}
                    if full_hash.get() and stat.st_size <= 512 * 1024 * 1024:
                        record["sha256"] = sha256_file(item, 512 * 1024 * 1024)
                    records[str(item.relative_to(root)).replace("\\", "/")] = record
                except OSError:
                    continue
                if index % 150 == 0:
                    status.set(f"Сканирование: {index}/{len(files)}")
                    window.update_idletasks()
            return records

        def create_inventory_snapshot() -> None:
            try:
                records = scan_inventory()
                snapshot_path.parent.mkdir(parents=True, exist_ok=True)
                payload = {"root": str(root), "created": dt.datetime.now().isoformat(timespec="seconds"),
                           "hash_mode": bool(full_hash.get()), "files": records}
                self.atomic_write_bytes(snapshot_path, json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"))
                set_integrity_text(f"Снимок создан: {payload['created']}\nФайлов зафиксировано: {len(records)}\nSHA-256: {'да' if payload['hash_mode'] else 'нет (размер + дата изменения)'}\n\nПуть: {snapshot_path}")
                status.set(f"Снимок целостности создан: {len(records)} файлов")
                self.log("Создан снимок целостности: %s (%d файлов)", snapshot_path, len(records))
            except (OSError, ValueError) as exc:
                messagebox.showerror("Снимок целостности", str(exc), parent=window)

        def compare_inventory_snapshot() -> None:
            if not snapshot_path.is_file():
                messagebox.showinfo("Целостность", "Сначала создайте снимок установки.", parent=window)
                return
            try:
                saved = json.loads(snapshot_path.read_text(encoding="utf-8"))
                current = scan_inventory()
                before = saved.get("files", {})
                before_names, current_names = set(before), set(current)
                added = sorted(current_names - before_names)
                removed = sorted(before_names - current_names)
                changed: list[str] = []
                for name in sorted(before_names & current_names):
                    old, new = before[name], current[name]
                    if "sha256" in old and "sha256" in new:
                        different = old["sha256"] != new["sha256"]
                    else:
                        different = old.get("size") != new.get("size") or old.get("mtime") != new.get("mtime")
                    if different:
                        changed.append(name)
                lines = [f"Сравнение со снимком от {saved.get('created', 'неизвестно')}",
                         f"Новые: {len(added)}", f"Изменённые: {len(changed)}", f"Отсутствуют: {len(removed)}", ""]
                for title, values in (("НОВЫЕ", added), ("ИЗМЕНЁННЫЕ", changed), ("ОТСУТСТВУЮТ", removed)):
                    lines.append(f"--- {title} ---")
                    lines.extend(values[:500] or ["(нет)"])
                    if len(values) > 500:
                        lines.append(f"… ещё {len(values)-500}")
                    lines.append("")
                set_integrity_text("\n".join(lines))
                status.set(f"Проверка: новых {len(added)}, изменённых {len(changed)}, отсутствуют {len(removed)}")
                self.log("Проверка целостности: новые=%d изменённые=%d отсутствуют=%d", len(added), len(changed), len(removed))
            except (OSError, json.JSONDecodeError, TypeError) as exc:
                messagebox.showerror("Проверка целостности", str(exc), parent=window)

        def find_duplicates() -> None:
            groups: dict[str, list[Path]] = {}
            scanned = 0
            skipped_large = 0
            for item in self._iter_files(root):
                try:
                    if item.stat().st_size > 128 * 1024 * 1024:
                        skipped_large += 1
                        continue
                    digest = sha256_file(item, 128 * 1024 * 1024)
                    if digest:
                        groups.setdefault(digest, []).append(item)
                    scanned += 1
                except OSError:
                    continue
                if scanned % 200 == 0:
                    status.set(f"Поиск дублей: {scanned} файлов")
                    window.update_idletasks()
            duplicate_groups = [(digest, paths) for digest, paths in groups.items() if len(paths) > 1]
            lines = [f"Проверено файлов: {scanned}", f"Пропущено больших (>128 МБ): {skipped_large}",
                     f"Групп одинаковых файлов: {len(duplicate_groups)}", ""]
            for digest, paths in duplicate_groups[:500]:
                lines.append(f"SHA-256: {digest}")
                lines.extend(f"  {p.relative_to(root)} ({format_file_size(p.stat().st_size)})" for p in paths)
                lines.append("")
            set_integrity_text("\n".join(lines))
            status.set(f"Найдено групп одинаковых файлов: {len(duplicate_groups)}")
            self.log("Поиск дубликатов завершён: групп=%d", len(duplicate_groups))

        ttk.Button(integrity_top, text="Поиск одинаковых файлов", command=find_duplicates).pack(side="left", padx=4)
        ttk.Button(integrity_top, text="Сохранить отчёт…", command=lambda: save_integrity_report()).pack(side="left", padx=4)

        def save_integrity_report() -> None:
            destination = filedialog.asksaveasfilename(parent=window, title="Сохранить отчёт", initialfile="FM2010_integrity.txt",
                defaultextension=".txt", filetypes=(("Текст", "*.txt"),))
            if destination:
                try:
                    Path(destination).write_text(integrity_text.get("1.0", "end-1c"), encoding="utf-8")
                    status.set("Отчёт целостности сохранён")
                except OSError as exc:
                    messagebox.showerror("Отчёт", str(exc), parent=window)

        # PROFILES AND MOD PACKS
        profile_controls = ttk.Frame(mods)
        profile_controls.pack(fill="x", pady=(0, 8))
        profile_list = tk.Listbox(mods, selectmode="extended", height=8)
        profile_list.pack(fill="x", pady=(0, 8))
        selected_profile_files: list[Path] = []
        ttk.Label(mods, text="Выбранные файлы для профиля:", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        selected_files_text = tk.Text(mods, height=7, wrap="none", font=("Consolas", 9))
        selected_files_text.pack(fill="x", pady=(4, 8))
        profiles_dir = self.app_data_dir / "profiles"
        profiles_dir.mkdir(parents=True, exist_ok=True)

        def refresh_profiles() -> None:
            profile_list.delete(0, "end")
            for file in sorted(profiles_dir.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True):
                profile_list.insert("end", file.name)

        def add_profile_files() -> None:
            selected = filedialog.askopenfilenames(parent=window, title="Добавить файлы в профиль", initialdir=str(root),
                filetypes=(("Все файлы", "*.*"),))
            for value in selected:
                path = Path(value).resolve()
                if is_within(path, root) and path.is_file() and path not in selected_profile_files:
                    selected_profile_files.append(path)
            selected_files_text.delete("1.0", "end")
            selected_files_text.insert("1.0", "\n".join(str(p.relative_to(root)) for p in selected_profile_files))
            status.set(f"Файлов в профиле: {len(selected_profile_files)}")

        def clear_profile_files() -> None:
            selected_profile_files.clear()
            selected_files_text.delete("1.0", "end")

        def save_profile() -> None:
            if not selected_profile_files:
                messagebox.showwarning("Профиль", "Сначала добавьте файлы в профиль.", parent=window)
                return
            name_window = tk.Toplevel(window)
            name_window.title("Новый профиль")
            name_window.geometry("440x150")
            name_window.transient(window)
            frame = ttk.Frame(name_window, padding=12)
            frame.pack(fill="both", expand=True)
            ttk.Label(frame, text="Название профиля:").pack(anchor="w")
            name_var = tk.StringVar(value="Мой профиль")
            entry = ttk.Entry(frame, textvariable=name_var)
            entry.pack(fill="x", pady=8)
            def make_profile() -> None:
                safe_name = re.sub(r"[^\w.-]+", "_", name_var.get().strip(), flags=re.UNICODE).strip("._")
                if not safe_name:
                    messagebox.showwarning("Профиль", "Введите название.", parent=name_window)
                    return
                destination = profiles_dir / f"{safe_name}.zip"
                if destination.exists() and not messagebox.askyesno("Перезапись профиля", "Профиль уже существует. Перезаписать?", parent=name_window):
                    return
                manifest = {"name": name_var.get().strip(), "created": dt.datetime.now().isoformat(timespec="seconds"),
                            "game_root": str(root), "files": [str(p.relative_to(root)).replace("\\", "/") for p in selected_profile_files]}
                try:
                    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
                        archive.writestr("FM2010_PROFILE.json", json.dumps(manifest, ensure_ascii=False, indent=2))
                        for item in selected_profile_files:
                            archive.write(item, item.relative_to(root).as_posix())
                    refresh_profiles()
                    self.log("Создан профиль: %s (%d файлов)", destination, len(selected_profile_files))
                    status.set(f"Профиль сохранён: {destination.name}")
                    name_window.destroy()
                except (OSError, zipfile.BadZipFile) as exc:
                    messagebox.showerror("Профиль", str(exc), parent=name_window)
            row = ttk.Frame(frame)
            row.pack(fill="x")
            ttk.Button(row, text="Создать", command=make_profile).pack(side="left")
            ttk.Button(row, text="Отмена", command=name_window.destroy).pack(side="right")
            entry.focus_set()

        def activate_profile() -> None:
            selection = profile_list.curselection()
            if not selection:
                messagebox.showinfo("Профиль", "Выберите профиль в списке.", parent=window)
                return
            archive_path = profiles_dir / profile_list.get(selection[0])
            try:
                with zipfile.ZipFile(archive_path, "r") as archive:
                    members = archive.infolist()
                    files_to_install = []
                    total_size = 0
                    for member in members:
                        if member.is_dir() or member.filename == "FM2010_PROFILE.json":
                            continue
                        target = safe_member_path(root, member.filename)
                        if target == root:
                            raise SettingsError("В профиле обнаружена запись, указывающая на корень папки игры.")
                        if member.file_size > 1024 * 1024 * 1024:
                            raise SettingsError("В профиле есть файл больше 1 ГБ. Активация остановлена.")
                        total_size += member.file_size
                        files_to_install.append((member, target))
                    if len(files_to_install) > 10000 or total_size > 2 * 1024 * 1024 * 1024:
                        raise SettingsError("Профиль превышает безопасный лимит (10 000 файлов / 2 ГБ).")
                    if not messagebox.askyesno("Активировать профиль", f"Будет восстановлено файлов: {len(files_to_install)}\nОбщий размер: {format_file_size(total_size)}\n\nСуществующие файлы будут сохранены в backup. Продолжить?", icon="warning", parent=window):
                        return
                    for member, target in files_to_install:
                        if target.exists():
                            backup = self._backup_file_before_save(target)
                            if backup is None:
                                raise SettingsError(f"Не удалось создать backup: {target}")
                    for member, target in files_to_install:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with archive.open(member, "r") as source:
                            fd, temp_name = tempfile.mkstemp(prefix="fm_profile_", suffix=".tmp", dir=target.parent)
                            try:
                                with os.fdopen(fd, "wb") as out:
                                    shutil.copyfileobj(source, out, length=1024 * 1024)
                                    out.flush(); os.fsync(out.fileno())
                                os.replace(temp_name, target)
                            finally:
                                try: os.unlink(temp_name)
                                except FileNotFoundError: pass
                status.set(f"Профиль активирован: {archive_path.name}")
                self.log("Активирован профиль %s", archive_path)
                messagebox.showinfo("Профиль", "Профиль применён. Резервные копии заменённых файлов сохранены.", parent=window)
            except (OSError, zipfile.BadZipFile, SettingsError, ValueError) as exc:
                messagebox.showerror("Активация профиля", str(exc), parent=window)

        def delete_profile() -> None:
            selection = profile_list.curselection()
            if not selection:
                return
            item = profiles_dir / profile_list.get(selection[0])
            if messagebox.askyesno("Удаление профиля", f"Удалить профиль {item.name}?", parent=window):
                try:
                    item.unlink()
                    refresh_profiles()
                    status.set(f"Профиль удалён: {item.name}")
                except OSError as exc:
                    messagebox.showerror("Профиль", str(exc), parent=window)

        profile_buttons = [
            ("Добавить файлы…", add_profile_files), ("Очистить список", clear_profile_files),
            ("Сохранить профиль", save_profile), ("Активировать выбранный", activate_profile),
            ("Удалить профиль", delete_profile), ("Обновить список", refresh_profiles),
        ]
        for label, callback in profile_buttons:
            ttk.Button(profile_controls, text=label, command=callback).pack(side="left", padx=3)
        ttk.Separator(mods).pack(fill="x", pady=12)
        pack_buttons = ttk.Frame(mods)
        pack_buttons.pack(fill="x")
        ttk.Button(pack_buttons, text="Собрать ZIP-мод из папки…", command=lambda: build_modpack()).pack(side="left", padx=3)
        ttk.Button(pack_buttons, text="Установить ZIP-мод…", command=lambda: install_modpack()).pack(side="left", padx=3)
        ttk.Label(mods, text="Профиль сохраняет выбранные файлы игры в ZIP и позволяет переключать наборы настроек/мод-изменений. "
                            "ZIP-мод содержит структуру папок для установки поверх выбранной игры.", wraplength=1000, foreground="#666").pack(anchor="w", pady=(8, 0))
        refresh_profiles()

        def build_modpack() -> None:
            source_dir = filedialog.askdirectory(parent=window, title="Выберите папку с файлами мода")
            if not source_dir:
                return
            source = Path(source_dir).resolve()
            destination = filedialog.asksaveasfilename(parent=window, title="Сохранить ZIP-мод", initialfile="FM2010_ModPack.zip",
                defaultextension=".zip", filetypes=(("ZIP", "*.zip"),))
            if not destination:
                return
            files = list(self._iter_files(source))
            if not files:
                messagebox.showwarning("Сборка мода", "В выбранной папке нет файлов.", parent=window)
                return
            manifest = {"format": "FM2010-ModPack", "version": 1, "created": dt.datetime.now().isoformat(timespec="seconds"),
                        "source_folder": source.name, "file_count": len(files)}
            try:
                with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
                    archive.writestr("FM2010_MODPACK.json", json.dumps(manifest, ensure_ascii=False, indent=2))
                    for item in files:
                        archive.write(item, item.relative_to(source).as_posix())
                status.set(f"ZIP-мод собран: {len(files)} файлов")
                self.log("Собран ZIP-мод: %s (%d файлов)", destination, len(files))
                messagebox.showinfo("Сборка мода", f"Архив создан:\n{destination}\nФайлов: {len(files)}", parent=window)
            except (OSError, zipfile.BadZipFile) as exc:
                messagebox.showerror("Сборка мода", str(exc), parent=window)

        def install_modpack() -> None:
            archive_name = filedialog.askopenfilename(parent=window, title="Выберите ZIP-мод", filetypes=(("ZIP", "*.zip"),))
            if not archive_name:
                return
            archive_path = Path(archive_name)
            try:
                with zipfile.ZipFile(archive_path, "r") as archive:
                    members = archive.infolist()
                    files_to_install = []
                    total_size = 0
                    for member in members:
                        if member.is_dir() or member.filename == "FM2010_MODPACK.json":
                            continue
                        target = safe_member_path(root, member.filename)
                        if target == root:
                            raise SettingsError("В ZIP-моде обнаружена запись, указывающая на корень папки игры.")
                        total_size += member.file_size
                        files_to_install.append((member, target))
                    if len(files_to_install) > 10000 or total_size > 2 * 1024 * 1024 * 1024:
                        raise SettingsError("Архив превышает лимит (10 000 файлов / 2 ГБ распакованных данных).")
                    corrupt = archive.testzip()
                    if corrupt:
                        raise SettingsError(f"Архив повреждён: {corrupt}")
                    conflicts = [str(target.relative_to(root)) for _m, target in files_to_install if target.exists()]
                    prompt = (f"Архив: {archive_path.name}\nФайлов: {len(files_to_install)}\nРазмер после распаковки: {format_file_size(total_size)}\n"
                              f"Файлов с заменой: {len(conflicts)}\n\nУстановка создаст резервные копии всех заменяемых файлов. Продолжить?")
                    if conflicts:
                        prompt += "\n\nПримеры замен:\n" + "\n".join(conflicts[:15])
                    if not messagebox.askyesno("Установка ZIP-мода", prompt, icon="warning", parent=window):
                        return
                    for _member, target in files_to_install:
                        if target.exists():
                            backup = self._backup_file_before_save(target)
                            if backup is None:
                                raise SettingsError(f"Не удалось создать backup: {target}")
                    for member, target in files_to_install:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        fd, temp_name = tempfile.mkstemp(prefix="fm_modpack_", suffix=".tmp", dir=target.parent)
                        try:
                            with archive.open(member, "r") as source, os.fdopen(fd, "wb") as out:
                                shutil.copyfileobj(source, out, length=1024 * 1024)
                                out.flush(); os.fsync(out.fileno())
                            os.replace(temp_name, target)
                        finally:
                            try: os.unlink(temp_name)
                            except FileNotFoundError: pass
                status.set(f"Мод установлен: {archive_path.name}")
                self.log("Установлен ZIP-мод: %s (%d файлов)", archive_path, len(files_to_install))
                messagebox.showinfo("Установка мода", "ZIP-мод установлен. Для заменённых файлов созданы резервные копии.", parent=window)
            except (OSError, zipfile.BadZipFile, SettingsError, ValueError) as exc:
                messagebox.showerror("Установка ZIP-мода", str(exc), parent=window)

        # QUARANTINE / MAINTENANCE
        cleanup_top = ttk.Frame(cleanup)
        cleanup_top.pack(fill="x", pady=(0, 8))
        ttk.Label(cleanup_top, text="Найдите остаточные временные файлы. Они не удаляются навсегда — перемещаются в карантин.",
                  wraplength=950).pack(side="left", fill="x", expand=True)
        cleanup_tree = ttk.Treeview(cleanup, columns=("size", "reason"), show="tree headings", selectmode="extended", height=22)
        cleanup_tree.heading("#0", text="Файл")
        cleanup_tree.heading("size", text="Размер")
        cleanup_tree.heading("reason", text="Почему найден")
        cleanup_tree.column("#0", width=650)
        cleanup_tree.column("size", width=110, anchor="e")
        cleanup_tree.column("reason", width=260)
        cleanup_tree.pack(fill="both", expand=True)
        cleanup_paths: dict[str, Path] = {}
        quarantine_dir = self.app_data_dir / "quarantine"

        def scan_junk() -> None:
            cleanup_tree.delete(*cleanup_tree.get_children())
            cleanup_paths.clear()
            patterns = ((".tmp", "Временный файл"), (".temp", "Временный файл"), (".old", "Старая версия"),
                        (".bak", "Резервная/старая копия"), ("~", "Временный файл редактора"))
            count = 0
            for item in self._iter_files(root):
                lower = item.name.casefold()
                reason = None
                if lower in {"thumbs.db", "desktop.ini"}:
                    reason = "Системный файл папки"
                else:
                    for suffix, label in patterns:
                        if lower.endswith(suffix) or (suffix == "~" and lower.startswith("~")):
                            reason = label
                            break
                if not reason:
                    continue
                try:
                    size = item.stat().st_size
                except OSError:
                    size = 0
                iid = f"q{count}"
                cleanup_paths[iid] = item
                cleanup_tree.insert("", "end", iid=iid, text=str(item.relative_to(root)), values=(format_file_size(size), reason))
                count += 1
            status.set(f"Найдено кандидатов в карантин: {count}. Ничего не перемещено.")

        def quarantine_selected() -> None:
            selected = cleanup_tree.selection()
            if not selected:
                messagebox.showinfo("Карантин", "Выберите файлы в списке.", parent=window)
                return
            timestamp_dir = quarantine_dir / dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            moved = 0
            errors: list[str] = []
            if not messagebox.askyesno("Перемещение в карантин", f"Переместить в отдельную папку {len(selected)} файлов?\nОригиналы будут доступны для восстановления.", parent=window):
                return
            for iid in selected:
                item = cleanup_paths.get(iid)
                if not item or not is_within(item, root) or not item.exists():
                    continue
                try:
                    relative = item.relative_to(root)
                    target = timestamp_dir / relative
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(item), str(target))
                    meta = {"original": str(item), "quarantined": str(target), "created": dt.datetime.now().isoformat(timespec="seconds"), "game_root": str(root)}
                    target.with_name(target.name + ".quarantine.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
                    moved += 1
                except OSError as exc:
                    errors.append(f"{item}: {exc}")
            scan_junk()
            status.set(f"Перемещено в карантин: {moved}; ошибок: {len(errors)}")
            if errors:
                messagebox.showwarning("Карантин", f"Перемещено: {moved}\nОшибки:\n" + "\n".join(errors[:10]), parent=window)
            else:
                messagebox.showinfo("Карантин", f"Перемещено файлов: {moved}\nПапка карантина:\n{quarantine_dir}", parent=window)

        def restore_quarantine() -> None:
            quarantine_dir.mkdir(parents=True, exist_ok=True)
            metadata_name = filedialog.askopenfilename(parent=window, title="Выберите запись карантина", initialdir=str(quarantine_dir),
                filetypes=(("Записи карантина", "*.quarantine.json"),))
            if not metadata_name:
                return
            try:
                metadata_path = Path(metadata_name).resolve()
                if not is_within(metadata_path, quarantine_dir):
                    raise SettingsError("Запись выбрана вне папки карантина.")
                meta = json.loads(metadata_path.read_text(encoding="utf-8"))
                source = Path(meta["quarantined"]).resolve()
                original = Path(meta["original"]).resolve()
                if not is_within(source, quarantine_dir) or not source.is_file():
                    raise SettingsError("Файл в карантине не найден или путь неверен.")
                if not is_within(original, root):
                    raise SettingsError("Исходный путь находится вне выбранной папки игры.")
                if original.exists() and not messagebox.askyesno("Восстановление карантина", f"Файл уже существует:\n{original}\n\nСоздать backup и заменить его?", parent=window):
                    return
                if original.exists():
                    backup = self._backup_file_before_save(original)
                    if backup is None:
                        raise SettingsError("Не удалось сохранить текущий файл в backup.")
                original.parent.mkdir(parents=True, exist_ok=True)
                self.atomic_copy_file(source, original)
                source.unlink(missing_ok=True)
                metadata_path.unlink(missing_ok=True)
                status.set(f"Восстановлено из карантина: {original.name}")
                self.log("Восстановлен из карантина: %s", original)
                scan_junk()
            except (OSError, KeyError, json.JSONDecodeError, SettingsError) as exc:
                messagebox.showerror("Восстановление карантина", str(exc), parent=window)

        cleanup_buttons = ttk.Frame(cleanup)
        cleanup_buttons.pack(fill="x", pady=(8, 0))
        ttk.Button(cleanup_buttons, text="Сканировать остаточные файлы", command=scan_junk).pack(side="left")
        ttk.Button(cleanup_buttons, text="В карантин выбранные", command=quarantine_selected).pack(side="left", padx=6)
        ttk.Button(cleanup_buttons, text="Восстановить из карантина…", command=restore_quarantine).pack(side="left", padx=6)
        def open_quarantine_folder() -> None:
            try:
                quarantine_dir.mkdir(parents=True, exist_ok=True)
                os.startfile(str(quarantine_dir))  # type: ignore[attr-defined]
            except (OSError, AttributeError) as exc:
                messagebox.showerror("Карантин", str(exc), parent=window)

        ttk.Button(cleanup_buttons, text="Открыть папку карантина", command=open_quarantine_folder).pack(side="right")

        analyze_install()
        self.log("Открыты классические инструменты PRO %s", APP_VERSION)

    @staticmethod
    def atomic_copy_file(source: Path, destination: Path) -> None:
        """Copy a potentially large binary file atomically, without loading it in RAM."""
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix="fm2010_copy_", suffix=".tmp", dir=destination.parent)
        try:
            with os.fdopen(fd, "wb") as output, source.open("rb") as input_stream:
                shutil.copyfileobj(input_stream, output, length=1024 * 1024)
                output.flush()
                os.fsync(output.fileno())
            try:
                shutil.copystat(source, temporary, follow_symlinks=True)
            except OSError:
                pass
            os.replace(temporary, destination)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

    @staticmethod
    def atomic_patch_bytes(path: Path, offset: int, replacement: bytes) -> None:
        """Apply an in-place-size binary patch using a streamed temporary copy."""
        if offset < 0 or not replacement:
            raise ValueError("Некорректное смещение или пустой патч.")
        size = path.stat().st_size
        if offset + len(replacement) > size:
            raise ValueError("Патч выходит за границы файла.")
        fd, temporary = tempfile.mkstemp(prefix="fm2010_patch_", suffix=".tmp", dir=path.parent)
        try:
            with path.open("rb") as source, os.fdopen(fd, "w+b") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)
                output.seek(offset)
                output.write(replacement)
                output.flush()
                os.fsync(output.fileno())
            try:
                shutil.copymode(path, temporary, follow_symlinks=True)
            except OSError:
                pass
            os.replace(temporary, path)
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

    def restore_file_backup(self) -> None:
        backup_root = self.app_data_dir / "file_backups"
        if not backup_root.is_dir() or not list(backup_root.glob("*.backup.json")):
            messagebox.showinfo("Backup файла", "Резервных копий отдельных файлов пока нет.")
            return
        selected = filedialog.askopenfilename(
            title="Выберите описание резервной копии файла",
            initialdir=str(backup_root),
            filetypes=(("Описания backup", "*.backup.json"),),
        )
        if not selected:
            return
        try:
            metadata_path = Path(selected).resolve()
            if not is_within(metadata_path, backup_root):
                raise SettingsError("Выбранный backup расположен вне каталога приложения.")
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            backup = Path(metadata["backup_path"]).resolve()
            original = Path(metadata["original_path"]).resolve()
            if not is_within(backup, backup_root) or not backup.is_file():
                raise SettingsError("Файл резервной копии не найден или путь некорректен.")
            if original == backup or is_within(original, backup_root):
                raise SettingsError("Нельзя восстанавливать backup поверх самого каталога резервных копий.")
            warning = "\n\nВНИМАНИЕ: это исполняемый/бинарный файл. Восстанавливайте копию только от той же версии игры." if original.suffix.lower() in PROTECTED_BINARY_EXTENSIONS else ""
            if not messagebox.askyesno("Восстановление файла", f"Заменить файл:\n{original}\n\nданными из выбранной копии?{warning}", icon="warning", parent=self):
                return
            if original.exists():
                self._backup_file_before_save(original)
            original.parent.mkdir(parents=True, exist_ok=True)
            self.atomic_copy_file(backup, original)
            self.log("Файл восстановлен из backup: %s", original)
            self.status_var.set(f"Файл восстановлен: {original.name}")
            messagebox.showinfo("Backup файла", f"Файл восстановлен:\n{original}")
        except (OSError, KeyError, json.JSONDecodeError, SettingsError) as exc:
            self.log("Ошибка восстановления файла: %s", exc, level=logging.ERROR)
            messagebox.showerror("Backup файла", str(exc))

    def choose_save_path(self) -> None:
        chosen = filedialog.askdirectory(title="Выберите папку для сохранений")
        if chosen:
            self.save_path_var.set(chosen)

    @staticmethod
    def set_matching_element(root: ET.Element, names: set[str], value: str, attributes: tuple[str, ...] = ()) -> int:
        changed = 0
        for element in root.iter():
            if local_name(element.tag) not in names:
                continue
            if attributes and any(attribute in element.attrib for attribute in attributes):
                attribute = next(attribute for attribute in attributes if attribute in element.attrib)
                element.set(attribute, value)
            elif element.text is not None or len(element) == 0:
                element.text = value
            else:
                element.set("value", value)
            changed += 1
        return changed

    def apply_presets(self) -> None:
        if not any((self.animations_var.get(), self.language_enabled_var.get(), self.save_path_enabled_var.get())):
            messagebox.showwarning("Настройки", "Выберите хотя бы одну настройку.")
            return
        if self.save_path_enabled_var.get() and not self.save_path_var.get().strip():
            messagebox.showwarning("Настройки", "Укажите путь к сохранениям.")
            return
        try:
            config = self.config_path()
            raw = config.read_text(encoding="utf-8-sig")
            root = ET.fromstring(raw)
            changes: list[str] = []
            if self.animations_var.get():
                count = self.set_matching_element(root, {"animations", "animation", "match_animation"}, "false", ("enabled", "value"))
                if count:
                    changes.append(f"анимации ({count} элемент.)")
            if self.language_enabled_var.get():
                count = self.set_matching_element(root, {"language", "locale", "game_language", "game__language"}, self.language_var.get())
                if count:
                    changes.append(f"язык ({count} элемент.)")
            if self.save_path_enabled_var.get():
                count = self.set_matching_element(root, {"save_path", "savepath", "saves_path", "savespath", "save_directory"}, self.save_path_var.get(), ("path", "value"))
                if count:
                    changes.append(f"путь сохранений ({count} элемент.)")
            if not changes:
                raise SettingsError("В config.xml не найдены подходящие элементы. Файл не изменён; используйте редактор файла.")
            if not self.create_backup(quiet=True):
                raise SettingsError("Backup не создан — файл не изменён.")
            xml_text = ET.tostring(root, encoding="unicode", short_empty_elements=True)
            self.atomic_write_bytes(config, ("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" + xml_text + "\n").encode("utf-8"))
            self.log("Применены быстрые настройки: %s", ", ".join(changes))
            self.status_var.set("Настройки применены")
            messagebox.showinfo("Готово", "Изменения применены:\n• " + "\n• ".join(changes))
        except (OSError, ET.ParseError, SettingsError) as exc:
            self.log("Настройки не применены: %s", exc, level=logging.ERROR)
            messagebox.showerror("Ошибка", str(exc))

    def restore_backup(self) -> None:
        try:
            preferences = self.require_preferences()
            backup_dir = self.backup_dir()
            backups = sorted(backup_dir.glob("preferences_*.zip"), reverse=True)
            if not backups:
                raise SettingsError("Резервные копии ещё не создавались.")
            selected = filedialog.askopenfilename(
                title="Выберите резервную копию настроек",
                initialdir=str(backup_dir),
                filetypes=(("ZIP backup", "*.zip"), ("Все файлы", "*.*")),
            )
            if not selected:
                return
            archive_path = Path(selected).resolve()
            if archive_path.parent != backup_dir.resolve():
                raise SettingsError("Можно восстановить только backup из папки приложения.")
            staging = Path(tempfile.mkdtemp(prefix="fm2010_restore_", dir=preferences.parent))
            try:
                with zipfile.ZipFile(archive_path, "r") as archive:
                    members = archive.infolist()
                    for member in members:
                        safe_member_path(staging, member.filename)
                    corrupt = archive.testzip()
                    if corrupt:
                        raise SettingsError(f"Архив повреждён: {corrupt}")
                    for member in members:
                        if member.is_dir():
                            continue
                        target = safe_member_path(staging, member.filename)
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with archive.open(member, "r") as source, target.open("wb") as destination:
                            shutil.copyfileobj(source, destination)
                if not self.create_backup(quiet=True):
                    raise SettingsError("Текущие настройки не сохранены в backup — восстановление отменено.")
                for child in preferences.iterdir():
                    if child.is_dir() and not child.is_symlink():
                        shutil.rmtree(child)
                    else:
                        child.unlink()
                for child in staging.iterdir():
                    target = preferences / child.name
                    if child.is_dir():
                        shutil.move(str(child), str(target))
                    else:
                        shutil.move(str(child), str(target))
            finally:
                shutil.rmtree(staging, ignore_errors=True)
            self.log("Настройки восстановлены из: %s", archive_path.name)
            self.status_var.set("Настройки восстановлены")
            messagebox.showinfo("Готово", "Настройки восстановлены из резервной копии.")
        except (OSError, zipfile.BadZipFile, SettingsError, ValueError) as exc:
            self.log("Ошибка восстановления: %s", exc, level=logging.ERROR)
            messagebox.showerror("Ошибка восстановления", str(exc))


if __name__ == "__main__":
    if sys.platform != "win32":
        print("Это приложение предназначено для Windows.", file=sys.stderr)
        raise SystemExit(1)
    try:
        app = FMTool()
        app.mainloop()
    except Exception as exc:
        try:
            messagebox.showerror("FM 2010 Settings Tool", f"Не удалось запустить приложение:\n{exc}")
        except Exception:
            print(f"Не удалось запустить приложение: {exc}", file=sys.stderr)
        raise
