# Changelog

## 6.0 GLOBAL RELEASE — 2026-11-06
- Added GitHub/Git panel powered by Git for Windows and official GitHub CLI: auth status/browser login, clone, local init, private repo creation, status/diff, commit, branch management, push, fast-forward-only pull, GitHub Release asset upload and Pull Request browser flow.
- Added token-free app integration: credentials are not requested or logged by Suite; GitHub CLI owns authentication.
- Added per-file encyclopedia: purpose, how to change, recommended tool, risk, confidence and a lightweight binary signature check.
- Added FM2010-specific guidance for Editor Data XML/DBC, `config.xml`, LNC and graphics mappings.
- Added user-selectable indexing of both the installed game and the separate Documents user-data folder.
- Added file-signature-aware SQLite identification and explicit unknown-format reporting.
- Added safeguards against initializing or committing Git repositories in/around the detected game installation.
- Added a deep read-only installation audit: large files, empty files, duplicate hashes and unusual extensionless files.
- Added a mod project wizard with metadata, README, `.gitignore`, folder layout and file changelog.
- Added FM Data Editor discovery, Editor Data folder shortcut and pre-flight compatibility report.
- Added global release unit and GUI workflow tests.
- Preserved all tools from RELEASE 4.0 and ULTIMATE 5.0.

## 5.0 ULTIMATE — 2026-11-05
- Added a dedicated ULTIMATE Workbench with 12 modules.
- Added a file signature inspector for common formats.
- Added ZIP patch builder/installer, per-file backups, persistent operation manifests and rollback. Partial patch failures attempt automatic rollback.
- Added copy-only media/resource organizer with CSV report.
- Added save-folder scanner, ZIP backup and safe restore.
- Added CSV/TSV table cleanup to new output files.
- Added unified text diff export.
- Added heuristic path reference scanner.
- Added reversible quarantine for manually selected temporary/empty files.
- Added read-only SQLite table browser and CSV export.
- Added key=value string catalog with duplicate-key warnings.
- Added SHA-256 installation manifest create/compare.
- Added GUI workflow tests for patch install/rollback, CSV cleanup, SQLite read-only and quarantine restore.
- Kept RELEASE 4.0 and legacy file center tools available.

## 4.0 RELEASE — 2026-11-05
- Added Project Studio, Folder Compare, Batch Rename, Text Resource Lab, Asset Library, Launch Profiles, Audit/Log Scanner, Backup Vault.

## 3.0 PRO and earlier
- Preserved file manager, text editor, HEX patcher, profiles, snapshots, batch replacement, ZIP modpack tools, backup and quarantine functions.
