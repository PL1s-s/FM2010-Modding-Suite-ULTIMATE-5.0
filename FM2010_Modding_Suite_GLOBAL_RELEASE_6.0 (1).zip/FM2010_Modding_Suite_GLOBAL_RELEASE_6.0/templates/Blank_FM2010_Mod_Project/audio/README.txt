Place audio resources here only after checking the target game format.
