@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
    echo Python launcher was not found. Install Python 3.10+ first.
    pause
    exit /b 1
)
py -3 -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo PyInstaller is not installed.
    echo Optional install command: py -3 -m pip install pyinstaller
    pause
    exit /b 1
)
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name FM2010_Modding_Suite --hidden-import fm2010_release_tools --hidden-import fm2010_advanced_tools --hidden-import fm2010_release6_tools fm2010_settings_tool.py
if errorlevel 1 (
    echo EXE build failed. Review the PyInstaller output above.
    pause
    exit /b 1
)
echo EXE created in the dist folder.
pause
endlocal
