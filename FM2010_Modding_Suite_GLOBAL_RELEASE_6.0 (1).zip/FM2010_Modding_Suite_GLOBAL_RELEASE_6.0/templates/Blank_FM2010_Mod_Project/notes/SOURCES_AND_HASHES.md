Record sources, licences, hashes, target patch version and test results here.
