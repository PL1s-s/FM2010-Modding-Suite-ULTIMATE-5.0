Place verified game-compatible images here. Subfolders: logos, faces, kits, backgrounds.
