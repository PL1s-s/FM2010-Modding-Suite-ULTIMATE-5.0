# FM2010 Modding Suite — GLOBAL RELEASE 6.0

Windows desktop toolbox for Football Manager 2010 modding workflows. Python 3.10+ with Tkinter.

New in 6.0: Git/GitHub CLI panel, per-file purpose and edit guide, file signature detection, deep audit, project wizard, FM Data Editor helper and compatibility pre-flight. The earlier 4.0/5.0 workbenches remain available.

Start with `Start FM2010 Settings.bat`. For GitHub actions install Git for Windows and GitHub CLI separately. See `GITHUB_GUIDE_RU.md` and `FILE_ENCYCLOPEDIA_RU.md`.

Use an isolated mod workspace, not the game installation folder, as a Git repository. Do not distribute original game files without permission.
