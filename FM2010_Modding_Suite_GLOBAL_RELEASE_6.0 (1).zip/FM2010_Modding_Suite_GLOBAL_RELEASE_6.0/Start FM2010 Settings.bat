@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Football Manager 2010 - Modding Suite GLOBAL RELEASE 6.0

if not exist "%~dp0fm2010_settings_tool.py" (
    echo ERROR: fm2010_settings_tool.py was not found.
    echo Extract the complete release folder before launching.
    pause
    exit /b 1
)
if not exist "%~dp0fm2010_release_tools.py" (
    echo ERROR: fm2010_release_tools.py was not found.
    echo Extract the complete release folder before launching.
    pause
    exit /b 1
)
if not exist "%~dp0fm2010_advanced_tools.py" (
    echo ERROR: fm2010_advanced_tools.py was not found.
    echo Extract the complete release folder before launching.
    pause
    exit /b 1
)
if not exist "%~dp0fm2010_release6_tools.py" (
    echo ERROR: fm2010_release6_tools.py was not found.
    echo Extract the complete release folder before launching.
    pause
    exit /b 1
)

where py >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys, tkinter; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
    if not errorlevel 1 (
        py -3 "%~dp0fm2010_settings_tool.py"
        goto :finish
    )
)
where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys, tkinter; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
    if not errorlevel 1 (
        python "%~dp0fm2010_settings_tool.py"
        goto :finish
    )
)

echo Python 3.10+ with Tkinter was not found.
echo Install Python from https://www.python.org/downloads/windows/
echo Enable Add Python to PATH and include Tcl/Tk during setup.
pause
exit /b 1

:finish
if errorlevel 1 pause
endlocal
