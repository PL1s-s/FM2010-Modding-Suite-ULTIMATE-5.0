@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "FAILED=0"
where py >nul 2>&1
if not errorlevel 1 (
    py -3 "%~dp0tests\test_release.py"
    if errorlevel 1 set "FAILED=1"
    py -3 "%~dp0tests\test_ultimate.py"
    if errorlevel 1 set "FAILED=1"
    py -3 "%~dp0tests\test_global_release.py"
    if errorlevel 1 set "FAILED=1"
    py -3 "%~dp0tests\test_global_gui.py"
    if errorlevel 1 set "FAILED=1"
    goto :finish
)
where python >nul 2>&1
if not errorlevel 1 (
    python "%~dp0tests\test_release.py"
    if errorlevel 1 set "FAILED=1"
    python "%~dp0tests\test_ultimate.py"
    if errorlevel 1 set "FAILED=1"
    python "%~dp0tests\test_global_release.py"
    if errorlevel 1 set "FAILED=1"
    python "%~dp0tests\test_global_gui.py"
    if errorlevel 1 set "FAILED=1"
    goto :finish
)
echo Python 3.10+ was not found.
pause
exit /b 1
:finish
if "%FAILED%"=="1" (
    echo One or more test suites FAILED.
    pause
    exit /b 1
) else (
    echo All legacy, ULTIMATE and GLOBAL RELEASE 6.0 checks PASSED.
)
pause
endlocal
