# -*- coding: utf-8 -*-
"""FM2010 Modding Suite ULTIMATE 5.0 — advanced standard-library tools."""
from __future__ import annotations
import csv, datetime as dt, difflib, hashlib, json, os, re, shutil, sqlite3, sys, tempfile, zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

VERSION = "5.0 ULTIMATE"
MAX_FILES = 150_000
MAX_TEXT = 8 * 1024 * 1024
MAX_ZIP_FILES = 50_000
MAX_ZIP_BYTES = 3 * 1024 * 1024 * 1024
TEXT_EXTS = {".txt", ".ini", ".cfg", ".xml", ".json", ".csv", ".tsv", ".log", ".md", ".yml", ".yaml", ".toml", ".properties", ".html", ".htm", ".css", ".js", ".lua", ".sql", ".vdf", ".acf", ".sii", ".po", ".pot"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tga", ".dds", ".webp", ".ico"}
AUDIO_EXTS = {".wav", ".mp3", ".ogg", ".flac", ".wma", ".mid", ".midi"}
VIDEO_EXTS = {".mp4", ".avi", ".wmv", ".mov", ".mkv", ".mpeg", ".mpg"}
FONT_EXTS = {".ttf", ".otf", ".fon"}
ARCHIVE_EXTS = {".zip", ".7z", ".rar", ".cab", ".pak", ".fmf"}
TEMP_EXTS = {".tmp", ".temp", ".old", ".orig", ".bak", ".backup"}


def _inside(path: Path, root: Path) -> bool:
    try: path.resolve().relative_to(root.resolve()); return True
    except (OSError, ValueError): return False


def _safe_member(root: Path, name: str) -> Path:
    if not name or "\x00" in name: raise ValueError("Пустой или некорректный путь в архиве")
    win, posix = PureWindowsPath(name), PurePosixPath(name.replace("\\", "/"))
    if win.is_absolute() or win.drive or posix.is_absolute() or ".." in posix.parts: raise ValueError(f"Небезопасный путь: {name}")
    out = (root / Path(*posix.parts)).resolve()
    if not _inside(out, root): raise ValueError(f"Путь выходит из папки назначения: {name}")
    return out


def _walk(root: Path, cap: int = MAX_FILES):
    n = 0
    for current, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "node_modules", ".fm2010_backups"}]
        for name in names:
            p = Path(current) / name
            try:
                if p.is_symlink() or not p.is_file(): continue
                yield p; n += 1
                if n >= cap: return
            except OSError: pass


def _hash(path: Path, cap: int = 512 * 1024 * 1024) -> str | None:
    try:
        if path.stat().st_size > cap: return None
        h = hashlib.sha256()
        with path.open("rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""): h.update(block)
        return h.hexdigest()
    except OSError: return None


def _decode(raw: bytes) -> str:
    if b"\x00" in raw: raise ValueError("Файл содержит нулевые байты и похож на бинарный")
    for enc in ("utf-8-sig", "utf-16", "cp1251", "cp1252"):
        try: return raw.decode(enc)
        except UnicodeError: continue
    raise ValueError("Не удалось распознать кодировку")


def _signature(path: Path) -> str:
    try:
        with path.open("rb") as f: b = f.read(32)
    except OSError: return "Недоступен"
    signatures = ((b"MZ", "Windows PE / EXE"), (b"\x89PNG\r\n\x1a\n", "PNG"), (b"\xff\xd8\xff", "JPEG"), (b"GIF87a", "GIF"), (b"GIF89a", "GIF"), (b"BM", "BMP"), (b"DDS ", "DDS"), (b"PK\x03\x04", "ZIP"), (b"SQLite format 3\x00", "SQLite"), (b"%PDF-", "PDF"), (b"OggS", "OGG"), (b"ID3", "MP3"), (b"\x1f\x8b", "GZIP"), (b"7z\xbc\xaf\x27\x1c", "7-Zip"), (b"Rar!\x1a\x07", "RAR"))
    for sig, name in signatures:
        if b.startswith(sig): return name
    if b.startswith(b"RIFF") and b[8:12] == b"WAVE": return "WAVE"
    if not b: return "Пустой"
    if b"\x00" not in b:
        try: b.decode("utf-8"); return "Текст UTF-8"
        except UnicodeError:
            if path.suffix.lower() in TEXT_EXTS: return "Текст / другая кодировка"
    return "Неизвестный бинарный"


def _backup(path: Path, backup_root: Path, prefix: str = "backup") -> Path:
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    out = backup_root / f"{prefix}_{stamp}" / path.name
    out.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(path, out)
    meta = {"source": str(path.resolve()), "backup": str(out.resolve()), "created": dt.datetime.now().isoformat(timespec="seconds"), "sha256": _hash(out)}
    (out.parent / "backup_meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return out


def _fmt_bytes(n: int) -> str:
    x = float(n)
    for unit in ("Б", "КБ", "МБ", "ГБ", "ТБ"):
        if x < 1024 or unit == "ТБ": return f"{int(x)} {unit}" if unit == "Б" else f"{x:.1f} {unit}"
        x /= 1024
    return str(n)


class AdvancedToolsMixin:
    def open_advanced_workbench(self) -> None:
        try: root = self._require_install_root()
        except Exception as exc: messagebox.showwarning("ULTIMATE 5.0", str(exc), parent=self); return
        win = tk.Toplevel(self); win.title("FM2010 Modding Suite — ULTIMATE 5.0"); win.geometry("1420x920"); win.minsize(1080, 720); win.transient(self)
        head = ttk.Frame(win, padding=12); head.pack(fill="x")
        ttk.Label(head, text="FM2010 MODDING SUITE · ULTIMATE 5.0", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(head, text=f"Игровая папка: {root}", foreground="#555", wraplength=1360).pack(anchor="w")
        nb = ttk.Notebook(win); nb.pack(fill="both", expand=True, padx=10, pady=8)
        status = tk.StringVar(value="Готово")
        ttk.Label(win, textvariable=status, relief="sunken", padding=5, anchor="w").pack(fill="x", side="bottom")
        titles = [("home", "Главная"), ("inspect", "Инспектор"), ("patch", "Патчи и откат"), ("organize", "Органайзер"), ("saves", "Сохранения"), ("csv", "CSV / TSV"), ("diff", "Diff Lab"), ("refs", "Сканер ссылок"), ("maint", "Карантин"), ("sqlite", "SQLite"), ("strings", "Каталог строк"), ("hash", "SHA-256")]
        tabs = {}
        for key, title in titles:
            tabs[key] = ttk.Frame(nb, padding=10); nb.add(tabs[key], text=title)
        data_dir = Path(getattr(self, "app_data_dir", Path.home() / ".fm2010_suite"))
        backups = data_dir / "ultimate_backups"; quarantine = data_dir / "ultimate_quarantine"
        backups.mkdir(parents=True, exist_ok=True); quarantine.mkdir(parents=True, exist_ok=True)

        def say(msg):
            status.set(msg)
            try: win.update_idletasks()
            except tk.TclError: pass
        def ask_dir(var, title):
            val = filedialog.askdirectory(parent=win, title=title)
            if val: var.set(val)
        def ask_file(var, title="Выбери файл", types=( ("Все файлы", "*.*"), )):
            val = filedialog.askopenfilename(parent=win, title=title, filetypes=types)
            if val: var.set(val)
        def reveal(path):
            try:
                if os.name == "nt": os.startfile(str(path))
                elif sys.platform == "darwin":
                    import subprocess; subprocess.Popen(["open", str(path)])
                else:
                    import subprocess; subprocess.Popen(["xdg-open", str(path)])
            except Exception as exc: messagebox.showerror("Открытие", str(exc), parent=win)
        def tree_widget(parent, cols, widths):
            holder = ttk.Frame(parent); holder.pack(fill="both", expand=True)
            tree = ttk.Treeview(holder, columns=cols, show="headings", selectmode="extended")
            for col, label, width in widths: tree.heading(col, text=label); tree.column(col, width=width, anchor="w")
            sy = ttk.Scrollbar(holder, orient="vertical", command=tree.yview); sx = ttk.Scrollbar(holder, orient="horizontal", command=tree.xview)
            tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set); tree.grid(row=0, column=0, sticky="nsew"); sy.grid(row=0, column=1, sticky="ns"); sx.grid(row=1, column=0, sticky="ew")
            holder.rowconfigure(0, weight=1); holder.columnconfigure(0, weight=1)
            return tree
        def export_tree(tree, filename):
            out = filedialog.asksaveasfilename(parent=win, defaultextension=".csv", initialfile=filename, filetypes=(("CSV", "*.csv"),))
            if not out: return
            with Path(out).open("w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f, delimiter=";"); w.writerow([tree.heading(c, "text") for c in tree["columns"]])
                for iid in tree.get_children(): w.writerow(tree.item(iid, "values"))
            say(f"Экспортировано: {out}")

        # HOME
        home = tabs["home"]
        ttk.Label(home, text="Набор из 12 дополнительных инструментов: исследование файлов, патчи, ресурсы, сохранения, таблицы, диагностика и контроль целостности.", font=("Segoe UI", 11, "bold"), wraplength=1300).pack(anchor="w", pady=(0, 10))
        home_info = tk.StringVar(value="Нажми «Быстрый анализ», чтобы получить сводку.")
        ttk.Label(home, textvariable=home_info, background="#eef2f6", padding=14, justify="left", wraplength=1300).pack(fill="x", pady=8)
        grid = ttk.Frame(home); grid.pack(fill="both", expand=True)
        shortcuts = [("Инспектор файлов", "inspect"), ("Сборка / установка патча", "patch"), ("Сортировка ресурсов", "organize"), ("Backup сохранений", "saves"), ("Работа с CSV/TSV", "csv"), ("Сравнение текстов", "diff"), ("Поиск ссылок", "refs"), ("Карантин и уборка", "maint"), ("SQLite Explorer", "sqlite"), ("Каталог строк", "strings"), ("SHA-256 манифест", "hash")]
        for i, (label, key) in enumerate(shortcuts): ttk.Button(grid, text=label, command=lambda k=key: nb.select(tabs[k])).grid(row=i//3, column=i%3, sticky="nsew", padx=5, pady=5, ipady=9)
        for c in range(3): grid.columnconfigure(c, weight=1)
        for r in range(4): grid.rowconfigure(r, weight=1)
        def quick_analysis():
            total = 0; count = 0; exts = {}
            for p in _walk(root):
                try: total += p.stat().st_size; count += 1; exts[p.suffix.lower() or "[без расширения]"] = exts.get(p.suffix.lower() or "[без расширения]", 0) + 1
                except OSError: pass
            top_ext = ", ".join(f"{k}: {v}" for k, v in sorted(exts.items(), key=lambda kv: kv[1], reverse=True)[:12])
            home_info.set(f"Файлов: {count:,}\nОбщий объём: {_fmt_bytes(total)}\nЧастые расширения: {top_ext}\nОграничение сканирования: {MAX_FILES:,} файлов")
            say("Быстрый анализ завершён")
        hb = ttk.Frame(home); hb.pack(fill="x", pady=8)
        ttk.Button(hb, text="Быстрый анализ установки", command=quick_analysis).pack(side="left")
        ttk.Button(hb, text="Открыть папку игры", command=lambda: reveal(root)).pack(side="left", padx=6)
        ttk.Button(hb, text="Открыть backups", command=lambda: reveal(backups)).pack(side="right")

        # INSPECTOR
        inspect = tabs["inspect"]; ir = ttk.Frame(inspect); ir.pack(fill="x", pady=(0, 8))
        filt = tk.StringVar(); kind = tk.StringVar(value="Все типы")
        ttk.Label(ir, text="Имя содержит:").pack(side="left"); ttk.Entry(ir, textvariable=filt, width=26).pack(side="left", padx=5)
        ttk.Combobox(ir, textvariable=kind, state="readonly", width=23, values=("Все типы", "Текст", "Изображения", "Аудио", "Видео", "Архивы", "SQLite", "Исполняемые", "Неизвестные бинарные")).pack(side="left", padx=5)
        itree = tree_widget(inspect, ("path", "ext", "sig", "size", "date"), (("path", "Путь относительно игры", 500), ("ext", "Расширение", 90), ("sig", "Сигнатура", 180), ("size", "Размер", 100), ("date", "Изменён", 150)))
        imap = {}
        def scan_inspector():
            itree.delete(*itree.get_children()); imap.clear(); n = 0
            for p in _walk(root):
                rel = p.relative_to(root).as_posix(); ext = p.suffix.lower(); sig = _signature(p)
                cat = "Текст" if ext in TEXT_EXTS or sig.startswith("Текст") else "Изображения" if ext in IMAGE_EXTS else "Аудио" if ext in AUDIO_EXTS else "Видео" if ext in VIDEO_EXTS else "Архивы" if ext in ARCHIVE_EXTS or sig in {"ZIP", "7-Zip", "RAR"} else "SQLite" if sig == "SQLite" else "Исполняемые" if sig.startswith("Windows PE") else "Неизвестные бинарные" if sig.startswith("Неизвестный") else "Другие"
                if filt.get().casefold() not in rel.casefold() or (kind.get() != "Все типы" and cat != kind.get()): continue
                try: st = p.stat()
                except OSError: continue
                iid = f"f{n}"; n += 1; imap[iid] = p
                itree.insert("", "end", iid=iid, values=(rel, ext or "—", sig, _fmt_bytes(st.st_size), dt.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")))
            say(f"Инспектор: найдено {n} файлов")
        def open_inspected():
            if itree.selection(): reveal(imap[itree.selection()[0]])
        ib = ttk.Frame(inspect); ib.pack(fill="x", pady=6)
        ttk.Button(ib, text="Сканировать", command=scan_inspector).pack(side="left"); ttk.Button(ib, text="Открыть файл", command=open_inspected).pack(side="left", padx=5); ttk.Button(ib, text="Экспорт CSV", command=lambda: export_tree(itree, "FM2010_file_inspector.csv")).pack(side="right")

        # PATCH BUILDER / INSTALLER / ROLLBACK
        patch = tabs["patch"]; stage = tk.StringVar(value=str(root / "mod_staging"))
        ttk.Label(patch, text="Создавай ZIP-патчи из staging, устанавливай их с резервными копиями и откатывай по журналу операции.", wraplength=1300).pack(anchor="w", pady=5)
        pr = ttk.Frame(patch); pr.pack(fill="x")
        ttk.Entry(pr, textvariable=stage).pack(side="left", fill="x", expand=True); ttk.Button(pr, text="Папка staging…", command=lambda: ask_dir(stage, "Папка staging для патча")).pack(side="left", padx=5)
        plog = tk.Text(patch, height=20, wrap="word"); plog.pack(fill="both", expand=True, pady=7)
        def build_patch():
            src = Path(stage.get()).expanduser()
            if not src.is_dir(): messagebox.showwarning("Патч", "Укажи существующую папку staging.", parent=win); return
            items = list(_walk(src))
            if not items: messagebox.showinfo("Патч", "В staging нет файлов.", parent=win); return
            out = filedialog.asksaveasfilename(parent=win, defaultextension=".zip", initialfile="FM2010_patch.zip", filetypes=(("ZIP", "*.zip"),))
            if not out: return
            manifest = []
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                for p in items:
                    rel = p.relative_to(src).as_posix(); z.write(p, rel); manifest.append({"path": rel, "size": p.stat().st_size, "sha256": _hash(p)})
                z.writestr("FM2010_PATCH_MANIFEST.json", json.dumps({"format": 1, "created": dt.datetime.now().isoformat(timespec="seconds"), "files": manifest}, ensure_ascii=False, indent=2))
            with zipfile.ZipFile(out) as z:
                if z.testzip(): raise ValueError("ZIP не прошёл проверку CRC")
            plog.insert("end", f"Собран: {out}\nФайлов: {len(items)}\n"); say(f"ZIP-патч собран: {len(items)} файлов")
        def install_patch():
            name = filedialog.askopenfilename(parent=win, filetypes=(("ZIP", "*.zip"),))
            if not name: return
            operation = {"created": dt.datetime.now().isoformat(timespec="seconds"), "archive": str(name), "state": "preparing", "items": []}
            opdir = data_dir / "patch_operations"; opdir.mkdir(parents=True, exist_ok=True)
            opfile = opdir / f"patch_{dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.json"
            def persist_operation():
                tmp_manifest = opfile.with_suffix(".json.tmp")
                tmp_manifest.write_text(json.dumps(operation, ensure_ascii=False, indent=2), encoding="utf-8")
                os.replace(tmp_manifest, opfile)
            try:
                with zipfile.ZipFile(name) as z:
                    if z.testzip(): raise ValueError("Архив не прошёл проверку CRC")
                    infos = [i for i in z.infolist() if not i.is_dir() and i.filename != "FM2010_PATCH_MANIFEST.json"]
                    if len(infos) > MAX_ZIP_FILES or sum(i.file_size for i in infos) > MAX_ZIP_BYTES: raise ValueError("Патч превышает ограничения количества или объёма")
                    if "FM2010_PATCH_MANIFEST.json" in z.namelist():
                        try:
                            patch_meta = json.loads(z.read("FM2010_PATCH_MANIFEST.json").decode("utf-8"))
                            expected = {x["path"]: x for x in patch_meta.get("files", [])}
                        except Exception as meta_exc:
                            raise ValueError(f"Манифест патча повреждён: {meta_exc}")
                        for info in infos:
                            record = expected.get(info.filename)
                            if record is None: raise ValueError(f"В манифесте отсутствует файл: {info.filename}")
                            if int(record.get("size", -1)) != info.file_size: raise ValueError(f"Размер не совпадает с манифестом: {info.filename}")
                            expected_hash = record.get("sha256")
                            if expected_hash:
                                digest = hashlib.sha256()
                                with z.open(info) as source:
                                    for chunk in iter(lambda: source.read(1024 * 1024), b""): digest.update(chunk)
                                if digest.hexdigest().lower() != str(expected_hash).lower(): raise ValueError(f"SHA-256 не совпадает: {info.filename}")
                    dests = []; seen = set()
                    for info in infos:
                        dest = _safe_member(root, info.filename); key = str(dest).casefold()
                        if key in seen: raise ValueError("В архиве повторяется путь: " + info.filename)
                        seen.add(key); dests.append((info, dest))
                    if not messagebox.askyesno("Установить патч", f"Файлов: {len(dests)}\nПеред заменой будут сохранены оригиналы. Продолжить?", parent=win): return
                    operation["state"] = "installing"; persist_operation()
                    for info, dest in dests:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        backup = str(_backup(dest, backups, "patch")) if dest.exists() else ""
                        item = {"path": str(dest), "backup": backup, "new": not bool(backup), "installed_hash": None}
                        operation["items"].append(item); persist_operation()
                        fd, tmp_name = tempfile.mkstemp(prefix=f".{dest.name}.fm2010-", suffix=".tmp", dir=str(dest.parent))
                        os.close(fd); tmp = Path(tmp_name)
                        try:
                            with z.open(info) as inp, tmp.open("wb") as out: shutil.copyfileobj(inp, out, 1024 * 1024)
                            os.replace(tmp, dest)
                        finally:
                            try: tmp.unlink(missing_ok=True)
                            except OSError: pass
                        item["installed_hash"] = _hash(dest); persist_operation()
                    operation["state"] = "complete"; persist_operation()
                    plog.insert("end", f"Установлен {name}\nЖурнал для отката: {opfile}\n"); say("Патч установлен; журнал операции сохранён")
            except Exception as exc:
                # Best-effort automatic rollback for partial installs.
                rollback_errors = []
                for item in reversed(operation.get("items", [])):
                    try:
                        dest = Path(item["path"]).resolve()
                        if not _inside(dest, root): raise ValueError("Недопустимый путь")
                        backup = Path(item["backup"]) if item.get("backup") else None
                        if backup and backup.is_file(): shutil.copy2(backup, dest)
                        elif item.get("new") and dest.exists():
                            expected = item.get("installed_hash")
                            if expected is not None and _hash(dest) == expected: dest.unlink()
                            else: raise ValueError("Нельзя подтвердить целостность нового файла; он оставлен на месте")
                    except Exception as rollback_exc: rollback_errors.append(str(rollback_exc))
                if operation.get("items"):
                    operation["state"] = "failed_and_rolled_back" if not rollback_errors else "rollback_incomplete"
                    operation["rollback_errors"] = rollback_errors
                    try: persist_operation()
                    except OSError: pass
                detail = f"\nАвтоматический откат: {'ошибок нет' if not rollback_errors else '; '.join(rollback_errors)}" if operation.get("items") else ""
                messagebox.showerror("Установка патча", str(exc) + detail, parent=win)
        def rollback_patch():
            name = filedialog.askopenfilename(parent=win, initialdir=str(data_dir / "patch_operations"), filetypes=(("Манифест", "*.json"),))
            if not name: return
            try:
                data = json.loads(Path(name).read_text(encoding="utf-8"))
                for item in reversed(data.get("items", [])):
                    dest = Path(item["path"]).resolve()
                    if not _inside(dest, root): raise ValueError("Манифест содержит путь вне корня игры")
                    backup = Path(item["backup"]) if item.get("backup") else None
                    if backup and backup.is_file():
                        if dest.exists(): _backup(dest, backups, "pre_rollback")
                        shutil.copy2(backup, dest)
                    elif item.get("new") and dest.exists():
                        if _hash(dest) != item.get("installed_hash"): raise ValueError(f"Файл изменён после установки; безопасный откат остановлен: {dest}")
                        dest.unlink()
                plog.insert("end", f"Откат выполнен по {name}\n"); say("Откат завершён")
            except Exception as exc: messagebox.showerror("Откат", str(exc), parent=win)
        pb = ttk.Frame(patch); pb.pack(fill="x")
        ttk.Button(pb, text="Собрать ZIP-патч", command=build_patch).pack(side="left"); ttk.Button(pb, text="Установить патч", command=install_patch).pack(side="left", padx=5); ttk.Button(pb, text="Откат по журналу…", command=rollback_patch).pack(side="left", padx=5)

        # ASSET ORGANIZER COPY-ONLY
        org = tabs["organize"]; osrc = tk.StringVar(value=str(root)); odst = tk.StringVar(value=str(root.parent / "FM2010_Asset_Export"))
        for label, var, title in (("Источник:", osrc, "Источник ресурсов"), ("Назначение:", odst, "Папка экспорта")):
            row = ttk.Frame(org); row.pack(fill="x", pady=3); ttk.Label(row, text=label, width=12).pack(side="left"); ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=5); ttk.Button(row, text="Обзор…", command=lambda v=var, t=title: ask_dir(v, t)).pack(side="left")
        olog = tk.Text(org, height=17, wrap="word"); olog.pack(fill="both", expand=True, pady=7)
        def organize_assets():
            src, dst = Path(osrc.get()).resolve(), Path(odst.get()).resolve()
            if not src.is_dir() or _inside(dst, src): messagebox.showwarning("Органайзер", "Выбери папку источника и папку назначения вне источника.", parent=win); return
            dst.mkdir(parents=True, exist_ok=True); groups = {"Images": IMAGE_EXTS, "Audio": AUDIO_EXTS, "Video": VIDEO_EXTS, "Fonts": FONT_EXTS, "Archives": ARCHIVE_EXTS}; copied = skipped = errors = 0; report = []
            for p in _walk(src):
                ext = p.suffix.lower(); group = next((k for k, exts in groups.items() if ext in exts), None)
                if group is None: continue
                outdir = dst / group; outdir.mkdir(parents=True, exist_ok=True); target = outdir / p.name
                if target.exists() and _hash(target) == _hash(p): skipped += 1; continue
                if target.exists():
                    idx = 2
                    while (outdir / f"{p.stem}_{idx}{p.suffix}").exists(): idx += 1
                    target = outdir / f"{p.stem}_{idx}{p.suffix}"
                try: shutil.copy2(p, target); copied += 1; report.append((str(p), str(target), group, p.stat().st_size))
                except OSError: errors += 1
            rep = dst / "asset_organizer_report.csv"
            with rep.open("w", encoding="utf-8-sig", newline="") as f: w = csv.writer(f, delimiter=";"); w.writerow(("source", "copy", "category", "size")); w.writerows(report)
            olog.insert("end", f"Скопировано: {copied}\nДубликаты: {skipped}\nОшибки: {errors}\nОтчёт: {rep}\nОригиналы не перемещались.")
            say(f"Органайзер: скопировано {copied}")
        ttk.Button(org, text="Скопировать и рассортировать", command=organize_assets).pack(anchor="w")

        # SAVE MANAGER
        saves = tabs["saves"]; sdir = tk.StringVar(value=str(Path.home() / "Documents"))
        ttk.Label(saves, text="Выбери каталог сохранений. Расширение не предполагается: показываются все файлы, найденные внутри папки.", wraplength=1300).pack(anchor="w", pady=4)
        sr = ttk.Frame(saves); sr.pack(fill="x"); ttk.Entry(sr, textvariable=sdir).pack(side="left", fill="x", expand=True); ttk.Button(sr, text="Выбрать папку…", command=lambda: ask_dir(sdir, "Папка сохранений")).pack(side="left", padx=5)
        stree = tree_widget(saves, ("path", "size", "date", "hash"), (("path", "Файл", 500), ("size", "Размер", 100), ("date", "Изменён", 150), ("hash", "SHA-256", 290))); smap = {}
        def scan_saves():
            stree.delete(*stree.get_children()); smap.clear(); base = Path(sdir.get()).expanduser()
            if not base.is_dir(): messagebox.showwarning("Сохранения", "Укажи существующую папку.", parent=win); return
            for i, p in enumerate(_walk(base, 30000)):
                try: st = p.stat()
                except OSError: continue
                iid = f"save{i}"; smap[iid] = p; stree.insert("", "end", iid=iid, values=(str(p.relative_to(base)), _fmt_bytes(st.st_size), dt.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M"), _hash(p) or "не рассчитан"))
            say(f"Сканирование сохранений: {len(smap)} файлов")
        def backup_saves():
            chosen = [smap[i] for i in stree.selection() if i in smap] or list(smap.values())
            if not chosen: messagebox.showinfo("Сохранения", "Сначала просканируй папку.", parent=win); return
            out = filedialog.askdirectory(parent=win, title="Куда сохранить ZIP backup")
            if not out: return
            base = Path(sdir.get()).resolve(); archive = Path(out) / f"FM2010_saves_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"; manifest = []
            with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
                for p in chosen:
                    rel = p.relative_to(base).as_posix(); z.write(p, rel); manifest.append({"path": rel, "size": p.stat().st_size, "sha256": _hash(p)})
                z.writestr("FM2010_SAVES_BACKUP.json", json.dumps({"source": str(base), "created": dt.datetime.now().isoformat(timespec="seconds"), "files": manifest}, ensure_ascii=False, indent=2))
            messagebox.showinfo("Сохранения", f"Создан архив:\n{archive}\nФайлов: {len(chosen)}", parent=win); say("Backup сохранений создан")
        def restore_saves():
            name = filedialog.askopenfilename(parent=win, filetypes=(("ZIP backup", "*.zip"),))
            if not name: return
            out = filedialog.askdirectory(parent=win, title="Куда восстановить сохранения")
            if not out: return
            destroot = Path(out).resolve()
            try:
                with zipfile.ZipFile(name) as z:
                    if z.testzip(): raise ValueError("Архив backup не прошёл проверку CRC")
                    infos = [x for x in z.infolist() if not x.is_dir() and x.filename != "FM2010_SAVES_BACKUP.json"]
                    if len(infos) > MAX_ZIP_FILES or sum(x.file_size for x in infos) > MAX_ZIP_BYTES: raise ValueError("Архив превышает лимиты")
                    targets = []; seen = set()
                    for info in infos:
                        dest = _safe_member(destroot, info.filename); key = str(dest).casefold()
                        if key in seen: raise ValueError("Повтор пути в архиве")
                        seen.add(key); targets.append((info, dest))
                    if not messagebox.askyesno("Восстановление", f"Восстановить {len(targets)} файлов? Существующие будут зарезервированы.", parent=win): return
                    for info, dest in targets:
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        if dest.exists(): _backup(dest, backups, "pre_save_restore")
                        with z.open(info) as inp, dest.open("wb") as outstream: shutil.copyfileobj(inp, outstream, 1024*1024)
                say("Сохранения восстановлены")
            except Exception as exc: messagebox.showerror("Восстановление", str(exc), parent=win)
        sb = ttk.Frame(saves); sb.pack(fill="x", pady=6); ttk.Button(sb, text="Сканировать", command=scan_saves).pack(side="left"); ttk.Button(sb, text="Создать ZIP backup выбранных / всех", command=backup_saves).pack(side="left", padx=5); ttk.Button(sb, text="Восстановить из ZIP…", command=restore_saves).pack(side="left", padx=5)

        # CSV TABLE LAB — exports new files, never overwrites source
        csvtab = tabs["csv"]; csvpath = tk.StringVar(); crow = ttk.Frame(csvtab); crow.pack(fill="x")
        ttk.Entry(crow, textvariable=csvpath).pack(side="left", fill="x", expand=True); ttk.Button(crow, text="Выбрать CSV/TSV…", command=lambda: ask_file(csvpath, "CSV / TSV", (("CSV и TSV", "*.csv *.tsv"), ("Все файлы", "*.*")))).pack(side="left", padx=5)
        cinfo = tk.StringVar(value="Файл не выбран"); ttk.Label(csvtab, textvariable=cinfo).pack(anchor="w", pady=5)
        ctree = tree_widget(csvtab, tuple(f"c{i}" for i in range(6)), tuple((f"c{i}", f"Колонка {i+1}", 170) for i in range(6))); cstate = {"rows": [], "delimiter": ";"}
        def load_csv():
            p = Path(csvpath.get())
            try:
                raw = p.read_bytes()
                if len(raw) > MAX_TEXT: raise ValueError("Лимит лаборатории — 8 МБ")
                text = _decode(raw)
                try: delimiter = csv.Sniffer().sniff(text[:8192], delimiters=",;\t|").delimiter
                except csv.Error: delimiter = "\t" if p.suffix.lower() == ".tsv" else ";"
                rows = list(csv.reader(text.splitlines(), delimiter=delimiter)); cstate.update(rows=rows, delimiter=delimiter); ctree.delete(*ctree.get_children())
                for i in range(6): ctree.heading(f"c{i}", text=rows[0][i] if rows and len(rows[0]) > i else f"Колонка {i+1}")
                for row in rows[1:101]: ctree.insert("", "end", values=tuple((row[:6] + [""]*6)[:6]))
                cinfo.set(f"Строк: {max(0,len(rows)-1)} · Колонок: {max((len(r) for r in rows), default=0)} · Разделитель: {repr(delimiter)} · показаны первые 100 строк"); say("Таблица загружена")
            except Exception as exc: messagebox.showerror("CSV", str(exc), parent=win)
        def transform_csv(mode):
            rows = cstate["rows"]
            if not rows: messagebox.showinfo("CSV", "Сначала загрузи таблицу.", parent=win); return
            header, data = rows[0], rows[1:]
            if mode == "trim": data = [[x.strip() for x in r] for r in data]
            elif mode == "dedupe":
                seen = set(); new = []
                for r in data:
                    key = tuple(r)
                    if key not in seen: seen.add(key); new.append(r)
                data = new
            elif mode == "empty": data = [r for r in data if any(x.strip() for x in r)]
            elif mode == "sort": data = sorted(data, key=lambda r: r[0].casefold() if r else "")
            out = filedialog.asksaveasfilename(parent=win, defaultextension=".csv", initialfile=Path(csvpath.get()).stem + "_cleaned.csv", filetypes=(("CSV", "*.csv"), ("TSV", "*.tsv")))
            if not out: return
            delim = "\t" if Path(out).suffix.lower() == ".tsv" else cstate["delimiter"]
            with Path(out).open("w", encoding="utf-8-sig", newline="") as f: w = csv.writer(f, delimiter=delim); w.writerows([header] + data)
            say(f"Сохранена новая таблица: {out}"); messagebox.showinfo("CSV", f"Готово. Строк данных: {len(data)}\nИсходный файл не менялся.\n{out}", parent=win)
        cb = ttk.Frame(csvtab); cb.pack(fill="x", pady=6)
        ttk.Button(cb, text="Загрузить / обновить", command=load_csv).pack(side="left")
        for label, mode in (("Обрезать пробелы", "trim"), ("Удалить дубли", "dedupe"), ("Убрать пустые строки", "empty"), ("Сортировать по 1-й колонке", "sort")): ttk.Button(cb, text=label, command=lambda m=mode: transform_csv(m)).pack(side="left", padx=4)

        # TEXT DIFF
        diff = tabs["diff"]; da = tk.StringVar(); db = tk.StringVar()
        for label, var in (("Файл A:", da), ("Файл B:", db)):
            row = ttk.Frame(diff); row.pack(fill="x", pady=3); ttk.Label(row, text=label, width=9).pack(side="left"); ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=5); ttk.Button(row, text="Обзор…", command=lambda v=var: ask_file(v, "Текстовый файл")).pack(side="left")
        diffbox = tk.Text(diff, wrap="none", font=("Consolas", 9)); diffbox.pack(fill="both", expand=True, pady=6)
        def run_diff():
            try:
                a, b = Path(da.get()), Path(db.get())
                if a.stat().st_size > MAX_TEXT or b.stat().st_size > MAX_TEXT: raise ValueError("Diff Lab ограничен файлами до 8 МБ")
                ta, tb = _decode(a.read_bytes()), _decode(b.read_bytes()); lines = list(difflib.unified_diff(ta.splitlines(True), tb.splitlines(True), fromfile=str(a), tofile=str(b)))
                diffbox.delete("1.0", "end"); diffbox.insert("1.0", "".join(lines) or "Файлы текстуально совпадают."); say(f"Diff готов: строк изменений {len(lines)}")
            except Exception as exc: messagebox.showerror("Diff Lab", str(exc), parent=win)
        def save_diff():
            text = diffbox.get("1.0", "end-1c")
            if not text: return
            out = filedialog.asksaveasfilename(parent=win, defaultextension=".diff", initialfile="FM2010_changes.diff")
            if out: Path(out).write_text(text, encoding="utf-8")
        dfb = ttk.Frame(diff); dfb.pack(fill="x"); ttk.Button(dfb, text="Сравнить", command=run_diff).pack(side="left"); ttk.Button(dfb, text="Сохранить diff…", command=save_diff).pack(side="left", padx=5)

        # REFERENCE CHECKER — heuristic, no false claim of actual broken game refs
        refs = tabs["refs"]; rex = tk.StringVar(value=", ".join(sorted(TEXT_EXTS))); rrow = ttk.Frame(refs); rrow.pack(fill="x")
        ttk.Label(rrow, text="Расширения:").pack(side="left"); ttk.Entry(rrow, textvariable=rex).pack(side="left", fill="x", expand=True, padx=5)
        rtree = tree_widget(refs, ("file", "line", "ref", "state"), (("file", "Файл-источник", 350), ("line", "Строка", 70), ("ref", "Возможный путь", 540), ("state", "Результат", 160))); rrows = []
        path_re = re.compile(r"(?i)(?:[\w .()\-]+[/\\][\w .()\\/-]+\.[a-z0-9]{2,6}|[\w .()\-]+\.(?:png|jpg|jpeg|bmp|gif|dds|tga|wav|ogg|mp3|xml|ini|cfg|dat|fmf))")
        def scan_refs():
            rtree.delete(*rtree.get_children()); rrows.clear(); exts = {x.strip().lower() if x.strip().startswith(".") else "."+x.strip().lower() for x in rex.get().split(",") if x.strip()}; n = 0
            for p in _walk(root):
                if p.suffix.lower() not in exts: continue
                try:
                    raw = p.read_bytes()
                    if len(raw) > MAX_TEXT: continue
                    text = _decode(raw)
                except Exception: continue
                for lineno, line in enumerate(text.splitlines(), 1):
                    for m in path_re.findall(line):
                        ref = m.strip(" \t\"'<>[]{}(),;")
                        rel = Path(ref.replace("\\", os.sep)); exists = (p.parent / rel).exists() or (root / rel).exists()
                        row = (str(p.relative_to(root)), lineno, ref, "Найдено" if exists else "Не обнаружено")
                        rrows.append(row); n += 1
                        if n <= 5000: rtree.insert("", "end", values=row)
            say(f"Найдено потенциальных ссылок: {n}. Проверка эвристическая, не гарантия ошибки игры.")
        def export_refs():
            if not rrows: messagebox.showinfo("Ссылки", "Сначала запусти сканирование.", parent=win); return
            out = filedialog.asksaveasfilename(parent=win, defaultextension=".csv", initialfile="FM2010_references.csv")
            if out:
                with Path(out).open("w", encoding="utf-8-sig", newline="") as f: w=csv.writer(f, delimiter=";"); w.writerow(("file","line","reference","state")); w.writerows(rrows)
        rb = ttk.Frame(refs); rb.pack(fill="x", pady=5); ttk.Button(rb, text="Сканировать пути", command=scan_refs).pack(side="left"); ttk.Button(rb, text="Экспорт CSV", command=export_refs).pack(side="left", padx=5)

        # QUARANTINE
        maint = tabs["maint"]; ttk.Label(maint, text="Поиск временных, резервных и нулевых файлов. Перемещение обратимое: исходники не удаляются безвозвратно.", wraplength=1300).pack(anchor="w", pady=5)
        mtree = tree_widget(maint, ("path","reason","size"), (("path","Путь",720),("reason","Причина",220),("size","Размер",100))); mmap = {}
        def scan_maint():
            mtree.delete(*mtree.get_children()); mmap.clear(); n=0
            for p in _walk(root):
                try: st=p.stat()
                except OSError: continue
                reason = "Временный / старый суффикс" if p.suffix.lower() in TEMP_EXTS or p.name.endswith("~") else "Пустой файл" if st.st_size == 0 else ""
                if not reason: continue
                iid=f"m{n}"; n+=1; mmap[iid]=(p,reason); mtree.insert("","end",iid=iid,values=(str(p.relative_to(root)),reason,_fmt_bytes(st.st_size)))
            say(f"Найдено кандидатов в карантин: {n}. Проверь список перед перемещением.")
        def quarantine_selected():
            chosen=[mmap[i] for i in mtree.selection() if i in mmap]
            if not chosen: messagebox.showinfo("Карантин","Выдели файлы.",parent=win); return
            if not messagebox.askyesno("Карантин",f"Переместить {len(chosen)} файлов в карантин?",parent=win): return
            batch=quarantine/dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f"); items=[]
            for p,reason in chosen:
                try: rel=p.relative_to(root); dest=batch/rel; dest.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(p),str(dest)); items.append({"original":str(p),"stored":str(dest),"reason":reason})
                except OSError: pass
            batch.mkdir(parents=True,exist_ok=True); (batch/"quarantine_manifest.json").write_text(json.dumps({"root":str(root),"items":items},ensure_ascii=False,indent=2),encoding="utf-8")
            scan_maint(); say(f"Перемещено в карантин: {len(items)}")
        def restore_quarantine():
            name=filedialog.askopenfilename(parent=win,initialdir=str(quarantine),filetypes=(("Манифест карантина","quarantine_manifest.json"),("JSON","*.json")))
            if not name:return
            try:
                data=json.loads(Path(name).read_text(encoding="utf-8"))
                if Path(data.get("root","")).resolve()!=root: raise ValueError("Манифест относится к другой установке")
                for item in data.get("items",[]):
                    original=Path(item["original"]).resolve(); stored=Path(item["stored"]).resolve()
                    if not _inside(original,root) or not _inside(stored,quarantine): raise ValueError("Недопустимый путь восстановления")
                    if stored.is_file():
                        if original.exists(): _backup(original,backups,"pre_quarantine_restore")
                        original.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(stored),str(original))
                say("Карантин восстановлен")
            except Exception as exc: messagebox.showerror("Карантин",str(exc),parent=win)
        mb=ttk.Frame(maint); mb.pack(fill="x",pady=5); ttk.Button(mb,text="Найти кандидатов",command=scan_maint).pack(side="left"); ttk.Button(mb,text="В карантин выбранное",command=quarantine_selected).pack(side="left",padx=5); ttk.Button(mb,text="Восстановить по манифесту…",command=restore_quarantine).pack(side="left",padx=5); ttk.Button(mb,text="Открыть карантин",command=lambda:reveal(quarantine)).pack(side="right")

        # SQLITE READ-ONLY BROWSER
        sql= tabs["sqlite"]; sqlpath=tk.StringVar(); sqr=ttk.Frame(sql); sqr.pack(fill="x"); ttk.Entry(sqr,textvariable=sqlpath).pack(side="left",fill="x",expand=True); ttk.Button(sqr,text="Выбрать файл БД…",command=lambda:ask_file(sqlpath,"SQLite database")).pack(side="left",padx=5)
        pane=ttk.PanedWindow(sql,orient="horizontal"); pane.pack(fill="both",expand=True,pady=6); left=ttk.Frame(pane); right=ttk.Frame(pane); pane.add(left,weight=1); pane.add(right,weight=3)
        slist=tk.Listbox(left); slist.pack(fill="both",expand=True); sview=tk.Text(right,wrap="none"); sview.pack(fill="both",expand=True); sqlstate={"tables":[]}
        def sqlite_load():
            p=Path(sqlpath.get())
            if not p.is_file(): messagebox.showerror("SQLite","Файл не найден.",parent=win); return
            with p.open("rb") as probe: magic = probe.read(16)
            if magic != b"SQLite format 3\x00": messagebox.showerror("SQLite","Выбранный файл не распознан как SQLite.",parent=win); return
            try:
                uri=p.resolve().as_uri()+"?mode=ro"
                with sqlite3.connect(uri,uri=True) as con: tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
                sqlstate["tables"]=tables; slist.delete(0,"end")
                for t in tables:slist.insert("end",t)
                sview.delete("1.0","end");sview.insert("1.0",f"Таблиц: {len(tables)}. Подключение — только для чтения. Выбери таблицу.");say(f"SQLite: {len(tables)} таблиц")
            except Exception as exc: messagebox.showerror("SQLite",str(exc),parent=win)
        def sqlite_preview(_event=None):
            sel=slist.curselection()
            if not sel:return
            table=sqlstate["tables"][sel[0]]
            try:
                uri=Path(sqlpath.get()).resolve().as_uri()+"?mode=ro"
                with sqlite3.connect(uri,uri=True) as con:
                    q='"'+table.replace('"','""')+'"'; cur=con.execute(f"SELECT * FROM {q} LIMIT 100"); cols=[d[0] for d in cur.description or []]; rows=cur.fetchall()
                lines=[" | ".join(cols),"-"*80]+[" | ".join(str(x)[:140] for x in r) for r in rows]
                sview.delete("1.0","end");sview.insert("1.0","\n".join(lines))
            except Exception as exc: messagebox.showerror("SQLite",str(exc),parent=win)
        def sqlite_export():
            sel=slist.curselection()
            if not sel:return
            table=sqlstate["tables"][sel[0]]; out=filedialog.asksaveasfilename(parent=win,defaultextension=".csv",initialfile=f"{table}.csv")
            if not out:return
            try:
                uri=Path(sqlpath.get()).resolve().as_uri()+"?mode=ro"
                with sqlite3.connect(uri,uri=True) as con:
                    q='"'+table.replace('"','""')+'"'; cur=con.execute(f"SELECT * FROM {q}")
                    with Path(out).open("w",encoding="utf-8-sig",newline="") as f:w=csv.writer(f,delimiter=";");w.writerow([d[0] for d in cur.description or []]);w.writerows(cur)
                say(f"SQLite экспортирован: {out}")
            except Exception as exc:messagebox.showerror("SQLite",str(exc),parent=win)
        slist.bind("<<ListboxSelect>>",sqlite_preview); sqb=ttk.Frame(sql);sqb.pack(fill="x");ttk.Button(sqb,text="Открыть только для чтения",command=sqlite_load).pack(side="left");ttk.Button(sqb,text="Экспорт таблицы CSV",command=sqlite_export).pack(side="left",padx=5)

        # STRING CATALOG key=value
        strings=tabs["strings"]; ttk.Label(strings,text="Ищет строки вида key=value в текстовых ресурсах. Повтор ключей и пустые значения отмечаются для проверки.",wraplength=1300).pack(anchor="w",pady=5)
        strtree=tree_widget(strings,("file","line","key","value","state"),(("file","Файл",320),("line","Строка",65),("key","Ключ",240),("value","Значение",460),("state","Статус",150))); strrows=[]
        def scan_strings():
            strtree.delete(*strtree.get_children());strrows.clear();counts={}
            for p in _walk(root):
                if p.suffix.lower() not in TEXT_EXTS:continue
                try:
                    raw=p.read_bytes()
                    if len(raw)>MAX_TEXT:continue
                    content=_decode(raw)
                except Exception:continue
                for lineno,line in enumerate(content.splitlines(),1):
                    if not line.strip() or line.lstrip().startswith(("#",";","//","[","<!--")):continue
                    m=re.match(r"^\s*([A-Za-z0-9_.:/ -]{2,100})\s*=\s*(.*?)\s*$",line)
                    if m:
                        key,value=m.groups();counts[key.casefold()]=counts.get(key.casefold(),0)+1;strrows.append([str(p.relative_to(root)),lineno,key,value,""])
            for row in strrows:
                row[4]="Повтор ключа" if counts[row[2].casefold()]>1 else "Пустое значение" if not row[3] else "OK"
                if len(strtree.get_children())<5000:strtree.insert("","end",values=row)
            say(f"Каталог строк: {len(strrows)}; повторов: {sum(r[4]=='Повтор ключа' for r in strrows)}")
        def export_strings():
            if not strrows:return
            out=filedialog.asksaveasfilename(parent=win,defaultextension=".csv",initialfile="FM2010_string_catalog.csv")
            if out:
                with Path(out).open("w",encoding="utf-8-sig",newline="") as f:w=csv.writer(f,delimiter=";");w.writerow(("file","line","key","value","state"));w.writerows(strrows)
        ssb=ttk.Frame(strings);ssb.pack(fill="x",pady=5);ttk.Button(ssb,text="Собрать каталог",command=scan_strings).pack(side="left");ttk.Button(ssb,text="Экспорт CSV",command=export_strings).pack(side="left",padx=5)

        # SHA-256 MANIFEST
        hashtab=tabs["hash"];ttk.Label(hashtab,text="Создаёт внешний манифест контрольных сумм, чтобы сравнить установку до и после модификаций.",wraplength=1300).pack(anchor="w",pady=5)
        hview=tk.Text(hashtab,wrap="none",font=("Consolas",9));hview.pack(fill="both",expand=True,pady=6)
        def create_hash_manifest():
            out=filedialog.asksaveasfilename(parent=win,defaultextension=".json",initialfile="FM2010_SHA256_manifest.json",filetypes=(("JSON","*.json"),))
            if not out:return
            entries=[];skipped=0
            for p in _walk(root):
                try:
                    st=p.stat();digest=_hash(p)
                    if digest is None:skipped+=1;continue
                    entries.append({"path":p.relative_to(root).as_posix(),"size":st.st_size,"mtime":int(st.st_mtime),"sha256":digest})
                except OSError:skipped+=1
            data={"format":1,"root":str(root),"created":dt.datetime.now().isoformat(timespec="seconds"),"files":entries,"skipped_large_or_unreadable":skipped}
            Path(out).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8");hview.delete("1.0","end");hview.insert("1.0",f"Манифест: {out}\nХешировано: {len(entries)}\nПропущено: {skipped}");say(f"SHA-256 манифест создан: {len(entries)} файлов")
        def compare_hash_manifest():
            name=filedialog.askopenfilename(parent=win,filetypes=(("JSON manifest","*.json"),))
            if not name:return
            try:
                data=json.loads(Path(name).read_text(encoding="utf-8"));old={x["path"]:x for x in data.get("files",[])};current={p.relative_to(root).as_posix():p for p in _walk(root)};lines=[]
                for rel in sorted(set(old)|set(current)):
                    if rel not in old:lines.append("NEW      "+rel)
                    elif rel not in current:lines.append("MISSING  "+rel)
                    else:
                        digest=_hash(current[rel])
                        if digest is None:lines.append("SKIPPED  "+rel)
                        elif digest!=old[rel].get("sha256"):lines.append("CHANGED  "+rel)
                report="\n".join(lines) if lines else "Различий не обнаружено."
                hview.delete("1.0","end");hview.insert("1.0",report);out=filedialog.asksaveasfilename(parent=win,defaultextension=".txt",initialfile="FM2010_manifest_diff.txt")
                if out:Path(out).write_text(report,encoding="utf-8")
                say("Сравнение манифеста завершено")
            except Exception as exc:messagebox.showerror("Манифест",str(exc),parent=win)
        hbtn=ttk.Frame(hashtab);hbtn.pack(fill="x");ttk.Button(hbtn,text="Создать манифест…",command=create_hash_manifest).pack(side="left");ttk.Button(hbtn,text="Сравнить с манифестом…",command=compare_hash_manifest).pack(side="left",padx=5)

        ttk.Label(win,text="Защитные ограничения: неизвестные проприетарные базы не декодируются автоматически; оригиналы не удаляются; ZIP-пути проверяются; SQLite открывается только для чтения.",foreground="#805000",wraplength=1370).pack(side="bottom",pady=(0,5))
        say("ULTIMATE 5.0 загружен. Сканирование запускается вручную отдельными кнопками.")
        try:self.log("Открыта ULTIMATE Workbench %s",VERSION)
        except Exception:pass
