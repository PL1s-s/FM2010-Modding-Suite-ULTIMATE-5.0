Store copies and notes here. No automatic proprietary database editing is provided.
