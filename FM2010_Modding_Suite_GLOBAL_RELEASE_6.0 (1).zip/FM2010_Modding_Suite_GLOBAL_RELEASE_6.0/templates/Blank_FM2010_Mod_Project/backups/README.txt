Temporary project backup location. Keep a separate backup outside the project too.
