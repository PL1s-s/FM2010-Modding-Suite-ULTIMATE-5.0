"""Release smoke + workflow tests. Run on Windows with Python 3.10+ and Tkinter."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path
import tkinter as tk
import tkinter.ttk as ttk

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fm2010_release_tools import _decode_text, _image_dimensions, _zip_target  # noqa: E402
from fm2010_settings_tool import FMTool  # noqa: E402
import fm2010_release_tools as release_module  # noqa: E402


def walk(widget):
    for child in widget.winfo_children():
        yield child
        yield from walk(child)


def find_button(parent, label: str) -> ttk.Button:
    for widget in walk(parent):
        if isinstance(widget, ttk.Button) and widget.cget("text") == label:
            return widget
    raise AssertionError(f"Button not found: {label}")


def set_entry(parent, index: int, value: str) -> None:
    entries = [w for w in walk(parent) if isinstance(w, ttk.Entry)]
    entry = entries[index]
    variable = entry.cget("textvariable")
    parent.setvar(variable, value)


def main() -> None:
    # Core safety and format probes.
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "root"
        root.mkdir()
        assert _zip_target(root, "data/config.xml") == (root / "data/config.xml").resolve()
        for bad in ("../outside", "/absolute/path", r"C:\evil.txt", r"..\escape"):
            try:
                _zip_target(root, bad)
            except ValueError:
                pass
            else:
                raise AssertionError(f"Unsafe ZIP path accepted: {bad}")
        assert _decode_text(b"hello\r\nworld\r\n") == ("hello\r\nworld\r\n", "utf-8", "CRLF")
        assert _decode_text("Привет".encode("cp1251"))[0] == "Привет"
        png_bytes = (b"\x89PNG\r\n\x1a\n" + (13).to_bytes(4, "big") + b"IHDR" +
                     (120).to_bytes(4, "big") + (80).to_bytes(4, "big"))
        png = root / "probe.png"
        png.write_bytes(png_bytes)
        assert _image_dimensions(png) == (120, 80)
    print("CORE: ZIP path safety, encoding/newline detection and PNG metadata PASS")

    # Full GUI workflow tests use a temporary game folder and temporary app data.
    with tempfile.TemporaryDirectory() as td:
        os.environ["LOCALAPPDATA"] = td
        temp = Path(td)
        game = temp / "game"
        game.mkdir()
        (game / "fm.exe").write_bytes(b"MZ" + b"\x00" * 128)
        (game / "settings.ini").write_text("[video]\nquality=high\n", encoding="utf-8")
        (game / "news.json").write_text('{"version":1,"name":"FM2010"}', encoding="utf-8")
        (game / "graphics").mkdir()
        (game / "graphics" / "logo.png").write_bytes(png_bytes)

        app = FMTool()
        app.install_dir = game
        app.game_exe = game / "fm.exe"
        # Keep dialog calls deterministic and non-blocking in automated smoke tests.
        release_module.messagebox.showinfo = lambda *a, **k: None
        release_module.messagebox.showwarning = lambda *a, **k: None
        release_module.messagebox.showerror = lambda *a, **k: (_ for _ in ()).throw(AssertionError(str(a)))
        release_module.messagebox.askyesno = lambda *a, **k: True
        app.open_release_workbench()
        app.update()
        top_levels = [w for w in app.winfo_children() if isinstance(w, tk.Toplevel)]
        assert top_levels, "RELEASE workbench did not open"
        hub = top_levels[-1]
        notebooks = [w for w in walk(hub) if isinstance(w, ttk.Notebook)]
        assert notebooks and len(notebooks[0].tabs()) >= 8
        nb = notebooks[0]
        tab_names = [nb.tab(tab, "text") for tab in nb.tabs()]
        required = ["Студия модов", "Сравнение папок", "Пакетное переименование", "Лаборатория ресурсов",
                    "Медиатека", "Профили запуска", "Аудит и журналы", "Хранилище копий"]
        for name in required:
            assert name in tab_names, name
        print("GUI: RELEASE Workbench opens with all eight modules PASS")

        # Project pack builder.
        workspace = temp / "workspace"
        (workspace / "config").mkdir(parents=True)
        (workspace / "config" / "test.ini").write_text("[test]\nvalue=1\n", encoding="utf-8")
        built_pack = temp / "workspace_mod.zip"
        original_askdir = release_module.filedialog.askdirectory
        original_saveas = release_module.filedialog.asksaveasfilename
        release_module.filedialog.askdirectory = lambda *a, **k: str(workspace)
        release_module.filedialog.asksaveasfilename = lambda *a, **k: str(built_pack)
        nb.select(tab_names.index("Студия модов"))
        find_button(hub, "Собрать ZIP из папки…").invoke()
        app.update()
        with zipfile.ZipFile(built_pack) as archive:
            assert archive.testzip() is None
            assert "FM2010_MODPACK.json" in archive.namelist()
            assert "config/test.ini" in archive.namelist()
        print("WORKFLOW: project ZIP build + archive verification PASS")

        # ZIP installer: one replacement and one new file.
        install_pack = temp / "install_test.zip"
        with zipfile.ZipFile(install_pack, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("FM2010_MODPACK.json", json.dumps({"mod_name": "smoke"}))
            archive.writestr("settings.ini", "[video]\nquality=ultra\n")
            archive.writestr("new_resource.txt", "created by smoke test")
        release_module.filedialog.askopenfilename = lambda *a, **k: str(install_pack)
        find_button(hub, "Установить ZIP-мод…").invoke()
        app.update()
        assert "ultra" in (game / "settings.ini").read_text(encoding="utf-8")
        assert (game / "new_resource.txt").is_file()
        assert list((temp / "FM2010SettingsTool" / "file_backups").glob("*.bak"))
        print("WORKFLOW: ZIP mod install + backup-before-replace PASS")

        # Folder comparison.
        second = temp / "second"
        second.mkdir()
        (second / "settings.ini").write_text("different", encoding="utf-8")
        compare_tab = nb.nametowidget(nb.tabs()[tab_names.index("Сравнение папок")])
        set_entry(compare_tab, 1, str(second))
        find_button(hub, "Сравнить папки").invoke()
        app.update()
        assert any("Изменён" in str(w.item(item, "values")) for w in walk(hub)
                   if isinstance(w, ttk.Treeview) for item in w.get_children())
        print("WORKFLOW: two-folder comparison PASS")

        # Batch rename and manifest undo.
        rename_tab = nb.nametowidget(nb.tabs()[tab_names.index("Пакетное переименование")])
        set_entry(rename_tab, 0, ".ini")
        set_entry(rename_tab, 3, "renamed_")
        find_button(hub, "Построить предпросмотр").invoke()
        find_button(hub, "Применить переименование").invoke()
        app.update()
        renamed = game / "renamed_settings.ini"
        assert renamed.is_file() and not (game / "settings.ini").exists()
        manifest_dir = temp / "FM2010SettingsTool" / "rename_manifests"
        manifest = sorted(manifest_dir.glob("rename_*.json"))[-1]
        release_module.filedialog.askopenfilename = lambda *a, **k: str(manifest)
        find_button(hub, "Отменить по манифесту…").invoke()
        app.update()
        assert (game / "settings.ini").is_file() and not renamed.exists()
        print("WORKFLOW: batch rename + manifest undo PASS")

        # Text resource validation, pretty format and safe save.
        text_tab = nb.nametowidget(nb.tabs()[tab_names.index("Лаборатория ресурсов")])
        release_module.filedialog.askopenfilename = lambda *a, **k: str(game / "news.json")
        find_button(hub, "Выбрать файл…").invoke()
        find_button(hub, "Проверить").invoke()
        find_button(hub, "JSON красиво").invoke()
        find_button(hub, "Сохранить + backup").invoke()
        app.update()
        saved_json = json.loads((game / "news.json").read_text(encoding="utf-8"))
        assert saved_json["version"] == 1
        print("WORKFLOW: JSON validate/format/save + backup PASS")

        # Asset scan, audit and backup vault refresh.
        nb.select(tab_names.index("Медиатека"))
        find_button(hub, "Сканировать медиатеку").invoke()
        nb.select(tab_names.index("Аудит и журналы"))
        find_button(hub, "Полный аудит установки").invoke()
        nb.select(tab_names.index("Хранилище копий"))
        find_button(hub, "Обновить список").invoke()
        app.update()
        print("WORKFLOW: asset catalog, installation audit and backup vault refresh PASS")

        # Restore monkeypatches and close cleanly.
        release_module.filedialog.askdirectory = original_askdir
        release_module.filedialog.asksaveasfilename = original_saveas
        app.destroy()

    print("ALL RELEASE CHECKS PASSED")


if __name__ == "__main__":
    main()
